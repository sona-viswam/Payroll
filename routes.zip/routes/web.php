<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\DashController;
use App\Http\Controllers\MailController;


use App\Http\Controllers\ProfileController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\LeaveController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\DesignationController;
use App\Http\Controllers\HolidayController;
use App\Http\Controllers\ShiftController;
use App\Http\Controllers\SalaryController;
use App\Http\Controllers\IncentiveController;
use App\Http\Controllers\DeductionController;
use App\Http\Controllers\DeviceController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\ClientProjectController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\ModuleController;
use App\Http\Controllers\ActivityController;
use App\Http\Controllers\JobCardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//
Route::get('/', function () {
    return view('login');
});

Route::get('login', [LoginController::class, 'login'])->name('login');
Route::post('doLogin', [LoginController::class, 'doLogin'])->name('doLogin');

Route::get('/doLogout', function(){
    Session::flush();
    Auth::logout();
    return Redirect::to('/login');
});

Route::get('dashboard', [DashController::class, 'dashboard'])->name('dashboard');

Route::get('myprofile', [ProfileController::class, 'myprofile'])->name('myprofile');
Route::get('myprofile_edit', [ProfileController::class, 'myprofile_edit'])->name('myprofile_edit');
Route::post('myprofile_update', [ProfileController::class, 'myprofile_update'])->name('myprofile_update');
Route::get('myattendance', [ProfileController::class, 'myattendance'])->name('myattendance');
Route::get('mysalary', [ProfileController::class, 'mysalary'])->name('mysalary');
Route::get('mysalary_slip/{id}', [ProfileController::class, 'mysalary_slip'])->name('mysalary_slip');
Route::get('myleave', [ProfileController::class, 'myleave'])->name('myleave');
Route::get('myleave_add', [ProfileController::class, 'myleave_add'])->name('myleave_add');
Route::post('sendEmail', [MailController::class, 'sendEmail'])->name('sendEmail');
Route::get('myleave_edit/{id}', [ProfileController::class, 'myleave_edit'])->name('myleave_edit');
Route::post('myleave_update/{id}', [ProfileController::class, 'myleave_update'])->name('myleave_update');
Route::get('myleave_delete/{id}', [ProfileController::class, 'myleave_delete'])->name('myleave_delete');
Route::get('myleave_view/{id}', [ProfileController::class, 'myleave_view'])->name('myleave_view');
Route::get('myrequest', [ProfileController::class, 'myrequest'])->name('myrequest');
Route::get('myrequest_action/{id}', [ProfileController::class, 'myrequest_action'])->name('myrequest_action');
Route::post('myrequest_update/{id}', [ProfileController::class, 'myrequest_update'])->name('myrequest_update');
Route::get('myshift_details', [ProfileController::class, 'myshift_details'])->name('myshift_details');



Route::get('employees', [EmployeeController::class, 'employees'])->name('employeess');
Route::get('employees_add', [EmployeeController::class, 'employees_add'])->name('employees_add');
Route::post('createEmployee', [EmployeeController::class, 'createEmployee'])->name('createEmployee');
Route::get('editEmployee/{id}', [EmployeeController::class, 'editEmployee'])->name('editEmployee');
Route::post('updateEmployee/{id}', [EmployeeController::class, 'updateEmployee'])->name('updateEmployee');
Route::get('employees_delete/{id}', [EmployeeController::class, 'employees_delete'])->name('employees_delete');

Route::get('employeedesignation/{id}', [EmployeeController::class, 'employeedesignation'])->name('employeedesignation');
Route::get('addEmployeedesignation/{id}', [EmployeeController::class, 'addEmployeedesignation'])->name('addEmployeedesignation');
Route::post('createEmployeedesignation', [EmployeeController::class, 'createEmployeedesignation'])->name('createEmployeedesignation');
Route::get('editEmployeedesignation/{id}', [EmployeeController::class, 'editEmployeedesignation'])->name('editEmployeedesignation');
Route::post('upddateEmployeedesignation/{id}', [EmployeeController::class, 'upddateEmployeedesignation'])->name('upddateEmployeedesignation');

Route::get('employeeShift', [EmployeeController::class, 'employeeShift'])->name('employeeShift');
Route::get('addEmployeeShift', [EmployeeController::class, 'addEmployeeShift'])->name('addEmployeeShift');
Route::post('createEmployeeShift', [EmployeeController::class, 'createEmployeeShift'])->name('createEmployeeShift');
Route::get('editEmployeeShift', [EmployeeController::class, 'editEmployeeShift'])->name('editEmployeeShift');
Route::post('updateEmployeeShift/{id}', [EmployeeController::class, 'updateEmployeeShift'])->name('updateEmployeeShift');

Route::get('employeeSalary', [EmployeeController::class, 'employeeSalary'])->name('employeeSalary');
Route::get('addEmployeesalary', [EmployeeController::class, 'addEmployeesalary'])->name('addEmployeesalary');
Route::post('createEmployeesalary', [EmployeeController::class, 'createEmployeesalary'])->name('createEmployeesalary');
Route::get('editEmployeesalary', [EmployeeController::class, 'editEmployeesalary'])->name('editEmployeesalary');
Route::post('updateEmployeesalary/{id}', [EmployeeController::class, 'updateEmployeesalary'])->name('updateEmployeesalary');
Route::get('viewEmployee/{id}', [EmployeeController::class, 'viewEmployee'])->name('viewEmployee');
Route::get('employeesSuspend', [EmployeeController::class, 'employeesSuspend']);

Route::get('attendance', [AttendanceController::class, 'attendance'])->name('attendance');
Route::get('attendance_monthly/{id}', [AttendanceController::class, 'attendance_monthly'])->name('attendance_monthly');
Route::get('attendance_daily/{id}', [AttendanceController::class, 'attendance_daily'])->name('attendance_daily');
Route::get('attendance_add', [AttendanceController::class, 'attendance_add'])->name('attendance_add');
Route::post('attendance_create', [AttendanceController::class, 'attendance_create'])->name('attendance_create');
Route::get('attendance_edit/{id}', [AttendanceController::class, 'attendance_edit'])->name('attendance_edit');
Route::post('attendance_update/{id}', [AttendanceController::class, 'attendance_update'])->name('attendance_update');
Route::get('attendance_delete/{id}', [AttendanceController::class, 'attendance_delete'])->name('attendance_delete');
Route::get('absent', [AttendanceController::class, 'absent'])->name('absent');
Route::get('attendance_bymonth/{id}/{sdate}', [AttendanceController::class, 'attendance_bymonth'])->name('attendance_bymonth');


Route::get('leave', [LeaveController::class, 'leave'])->name('leave');
Route::get('casualleave_add', [LeaveController::class, 'casualleave_add'])->name('casualleave_add');
Route::post('casualleave_create', [LeaveController::class, 'casualleave_create'])->name('casualleave_create');
Route::get('casualleave_edit/{id}', [LeaveController::class, 'casualleave_edit'])->name('casualleave_edit');
Route::post('casualleave_update/{id}', [LeaveController::class, 'casualleave_update'])->name('casualleave_update');
Route::get('casualleave_delete/{id}', [LeaveController::class, 'casualleave_delete'])->name('casualleave_delete');
Route::get('leave_view/{id}', [LeaveController::class, 'leave_view'])->name('leave_view');
Route::get('absent_view/{id}', [LeaveController::class, 'absent_view'])->name('absent_view');

Route::get('request', [LeaveController::class, 'request'])->name('request');
Route::get('request_action/{id}', [LeaveController::class, 'request_action'])->name('request_action');
Route::post('request_update/{id}', [LeaveController::class, 'request_update'])->name('request_update');



Route::get('department', [DepartmentController::class, 'department'])->name('department');
Route::get('department_add', [DepartmentController::class, 'department_add'])->name('department_add');
Route::post('department_create', [DepartmentController::class, 'department_create'])->name('department_create');
Route::get('department_edit/{id}', [DepartmentController::class, 'department_edit'])->name('department_edit');
Route::post('department_update/{id}', [DepartmentController::class, 'department_update'])->name('department_update');
Route::get('department_delete/{id}', [DepartmentController::class, 'department_delete'])->name('department_delete');

Route::get('designation', [DesignationController::class, 'designation'])->name('designation');
Route::get('designation_add', [DesignationController::class, 'designation_add'])->name('designation_add');
Route::post('designation_create', [DesignationController::class, 'designation_create'])->name('designation_create');
Route::get('designation_edit/{id}', [DesignationController::class, 'designation_edit'])->name('designation_edit');
Route::post('designation_update/{id}', [DesignationController::class, 'designation_update'])->name('designation_update');
Route::get('designation_delete/{id}', [DesignationController::class, 'designation_delete'])->name('designation_delete');

Route::get('holiday', [HolidayController::class, 'holiday'])->name('holiday');
Route::get('holiday_add', [HolidayController::class, 'holiday_add'])->name('holiday_add');
Route::post('holiday_create', [HolidayController::class, 'holiday_create'])->name('holiday_create');
Route::get('holiday_edit/{id}', [HolidayController::class, 'holiday_edit'])->name('holiday_edit');
Route::post('holiday_update/{id}', [HolidayController::class, 'holiday_update'])->name('holiday_update');
Route::get('holiday_delete/{id}', [HolidayController::class, 'holiday_delete'])->name('holiday_delete');

Route::get('shift', [ShiftController::class, 'shift'])->name('shift');
Route::get('shift_add', [ShiftController::class, 'shift_add'])->name('shift_add');
Route::post('shift_create', [ShiftController::class, 'shift_create'])->name('shift_create');
Route::get('shift_edit/{id}', [ShiftController::class, 'shift_edit'])->name('shift_edit');
Route::post('shift_update/{id}', [ShiftController::class, 'shift_update'])->name('shift_update');
Route::get('shift_delete/{id}', [ShiftController::class, 'shift_delete'])->name('shift_delete');
Route::get('shiftstars/{id}', [ShiftController::class, 'shiftstars'])->name('shiftstars');
Route::get('shiftstars_edit/{id}', [ShiftController::class, 'shiftstars_edit'])->name('shiftstars_edit');
Route::post('shiftstar_update/{id}', [ShiftController::class, 'shiftstar_update'])->name('shiftstar_update');

Route::get('salary', [SalaryController::class, 'salary'])->name('salary');
Route::get('salary_detailed/{id}', [SalaryController::class, 'salary_detailed'])->name('salary_detailed');
Route::get('salary_calculate', [SalaryController::class, 'salary_calculate'])->name('salary_calculate');
Route::post('salary_calculation', [SalaryController::class, 'salary_calculation'])->name('salary_calculation');
Route::get('salary_calculation_view', [SalaryController::class, 'salary_calculation_view'])->name('salary_calculation_view');
Route::get('salary_calculation_detailed/{id}', [SalaryController::class, 'salary_calculation_detailed'])->name('salary_calculation_detailed');
Route::get('salary_calculated_edit/{id}', [SalaryController::class, 'salary_calculated_edit'])->name('salary_calculated_edit');
Route::post('calculated_salary_update/{id}', [SalaryController::class, 'calculated_salary_update'])->name('calculated_salary_update');
Route::get('salary_save', [SalaryController::class, 'salary_save'])->name('salary_save');

Route::get('incentive', [IncentiveController::class, 'incentive'])->name('incentive');
Route::get('incentive_add', [IncentiveController::class, 'incentive_add'])->name('incentive_add');
Route::post('incentive_create', [IncentiveController::class, 'incentive_create'])->name('incentive_create');
Route::get('incentive_edit/{id}', [IncentiveController::class, 'incentive_edit'])->name('incentive_edit');
Route::post('incentive_update/{id}', [IncentiveController::class, 'incentive_update'])->name('incentive_update');
Route::get('incentive_delete/{id}', [IncentiveController::class, 'incentive_delete'])->name('incentive_delete');
Route::get('incentive_view/{id}', [IncentiveController::class, 'incentive_view'])->name('incentive_view');

Route::get('deduction', [DeductionController::class, 'deduction'])->name('deduction');
Route::get('deduction_add', [DeductionController::class, 'deduction_add'])->name('deduction_add');
Route::post('deduction_create', [DeductionController::class, 'deduction_create'])->name('deduction_create');
Route::get('deduction_edit/{id}', [DeductionController::class, 'deduction_edit'])->name('deduction_edit');
Route::post('deduction_update/{id}', [DeductionController::class, 'deduction_update'])->name('deduction_update');
Route::get('deduction_delete/{id}', [DeductionController::class, 'deduction_delete'])->name('deduction_delete');
Route::get('deduction_view/{id}', [DeductionController::class, 'deduction_view'])->name('deduction_view');

Route::get('device', [DeviceController::class, 'device'])->name('device');
Route::get('device_add', [DeviceController::class, 'device_add'])->name('device_add');
Route::post('device_create', [DeviceController::class, 'device_create'])->name('device_create');
Route::get('device_edit/{id}', [DeviceController::class, 'device_edit'])->name('device_edit');
Route::post('device_update/{id}', [DeviceController::class, 'device_update'])->name('device_update');
Route::get('device_delete/{id}', [DeviceController::class, 'device_delete'])->name('device_delete');

Route::get('settings', [SettingsController::class, 'settings'])->name('settings');
Route::get('settings_add', [SettingsController::class, 'settings_add'])->name('settings_add');
Route::post('settings_create', [SettingsController::class, 'settings_create'])->name('settings_create');
Route::get('settings_edit/{id}', [SettingsController::class, 'settings_edit'])->name('settings_edit');
Route::post('settings_update/{id}', [SettingsController::class, 'settings_update'])->name('settings_update');
Route::get('settings_delete/{id}', [SettingsController::class, 'settings_delete'])->name('settings_delete');


Route::get('client', [ClientController::class, 'client'])->name('client');
Route::get('client_add', [ClientController::class, 'client_add'])->name('client_add');
Route::post('client_create', [ClientController::class, 'client_create'])->name('client_create');
Route::get('client_edit/{id}', [ClientController::class, 'client_edit'])->name('client_edit');
Route::post('client_update/{id}', [ClientController::class, 'client_update'])->name('client_update');
Route::get('client_delete/{id}', [ClientController::class, 'client_delete'])->name('client_delete');

Route::get('project', [ProjectController::class, 'project'])->name('project');
Route::get('project_add', [ProjectController::class, 'project_add'])->name('project_add');
Route::post('project_create', [ProjectController::class, 'project_create'])->name('project_create');
Route::get('project_edit/{id}', [ProjectController::class, 'project_edit'])->name('project_edit');
Route::post('project_update/{id}', [ProjectController::class, 'project_update'])->name('project_update');
Route::get('project_delete/{id}', [ProjectController::class, 'project_delete'])->name('project_delete');
Route::post('fetch_project', [ProjectController::class, 'fetch_project'])->name('fetch_project');

Route::get('module/{id}', [ModuleController::class, 'module'])->name('module');
Route::get('module_add/{id}', [ModuleController::class, 'module_add'])->name('module_add');
Route::post('module_create', [ModuleController::class, 'module_create'])->name('module_create');
Route::get('module_edit/{id}', [ModuleController::class, 'module_edit'])->name('module_edit');
Route::post('module_update/{id}', [ModuleController::class, 'module_update'])->name('module_update');
Route::get('module_delete/{id}', [ModuleController::class, 'module_delete'])->name('module_delete');
Route::post('fetch_module', [ModuleController::class, 'fetch_module'])->name('fetch_module');
Route::post('fetch_submodule', [ModuleController::class, 'fetch_submodule'])->name('fetch_submodule');

Route::get('clientproject/{id}', [ClientProjectController::class, 'clientproject'])->name('clientproject');
Route::get('clientproject_add/{id}', [ClientProjectController::class, 'clientproject_add'])->name('clientproject_add');
Route::post('clientproject_create', [ClientProjectController::class, 'clientproject_create'])->name('clientproject_create');
Route::get('clientproject_edit/{id}', [ClientProjectController::class, 'clientproject_edit'])->name('clientproject_edit');
Route::post('clientproject_update/{id}', [ClientProjectController::class, 'clientproject_update'])->name('clientproject_update');
Route::get('clientproject_delete/{id}', [ClientProjectController::class, 'clientproject_delete'])->name('clientproject_delete');
Route::post('fetch_clientproject', [ClientProjectController::class, 'fetch_clientproject'])->name('fetch_clientproject');


Route::get('activity', [ActivityController::class, 'activity'])->name('activity');
Route::get('activity_add', [ActivityController::class, 'activity_add'])->name('activity_add');
Route::post('activity_create', [ActivityController::class, 'activity_create'])->name('activity_create');
Route::get('activity_edit/{id}', [ActivityController::class, 'activity_edit'])->name('activity_edit');
Route::post('activity_update/{id}', [ActivityController::class, 'activity_update'])->name('activity_update');
Route::get('activity_delete/{id}', [ActivityController::class, 'activity_delete'])->name('activity_delete');

Route::get('jobcard', [JobCardController::class, 'jobcard'])->name('jobcard');
Route::get('jobcard_add', [JobCardController::class, 'jobcard_add'])->name('jobcard_add');
Route::post('jobcard_create', [JobCardController::class, 'jobcard_create'])->name('jobcard_create');
Route::get('jobcard_edit/{id}', [JobCardController::class, 'jobcard_edit'])->name('jobcard_edit');
Route::post('jobcard_update/{id}', [JobCardController::class, 'jobcard_update'])->name('jobcard_update');
Route::get('jobcard_delete/{id}', [JobCardController::class, 'jobcard_delete'])->name('jobcard_delete');
Route::get('jobcard_view/{id}', [JobCardController::class, 'jobcard_view'])->name('jobcard_view');
Route::get('works/{id}', [JobCardController::class, 'works'])->name('works');
Route::get('work_view/{id}', [JobCardController::class, 'work_view'])->name('work_view');
Route::get('work_edit/{id}', [JobCardController::class, 'work_edit'])->name('work_edit');
Route::post('work_update/{id}', [JobCardController::class, 'work_update'])->name('work_update');
Route::get('work_delete/{id}', [JobCardController::class, 'work_delete'])->name('work_delete');

Route::get('job_calculate', [JobCardController::class, 'job_calculate'])->name('job_calculate');
Route::post('job_calculation', [JobCardController::class, 'job_calculation'])->name('job_calculation');
Route::get('job_calculation_detailed/{id}', [JobCardController::class, 'job_calculation_detailed'])->name('job_calculation_detailed');

Route::get('myjobcard', [ProfileController::class, 'myjobcard'])->name('myjobcard');
Route::get('myjobcard_view/{id}', [ProfileController::class, 'myjobcard_view'])->name('myjobcard_view');
Route::post('myjobcard_update/{id}', [ProfileController::class, 'myjobcard_update'])->name('myjobcard_update');
Route::get('myjobcard_delete/{id}', [ProfileController::class, 'myjobcard_delete'])->name('myjobcard_delete');

Route::get('myworks/{id}', [ProfileController::class, 'myworks'])->name('myworks');
Route::get('mywork_view/{id}', [ProfileController::class, 'mywork_view'])->name('mywork_view');
Route::get('mywork_add/{id}', [ProfileController::class, 'mywork_add'])->name('mywork_add');
Route::post('mywork_create', [ProfileController::class, 'mywork_create'])->name('mywork_create');
Route::get('mywork_edit/{id}', [ProfileController::class, 'mywork_edit'])->name('mywork_edit');
Route::post('mywork_update/{id}', [ProfileController::class, 'mywork_update'])->name('mywork_update');
Route::get('mywork_delete/{id}', [ProfileController::class, 'mywork_delete'])->name('mywork_delete');
