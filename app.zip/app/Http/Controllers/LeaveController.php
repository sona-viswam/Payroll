<?php

namespace App\Http\Controllers;

use App\Models\Configuration;
use App\Models\Leaves;
use App\Models\SalaryRecord;
use App\Models\Usermaster;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LeaveController extends Controller
{
    public $head = "LEAVE";
    public $icon = "mdi mdi-account-convert";

    public function leave()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        DB::statement("SET SQL_MODE=''");
        $data = Leaves::with('remployee', 'rbemployee')
                ->groupBy('batch')
                ->orderBy('id','DESC')
                ->paginate($this->pageno);
//        dd($data->toArray());
        return view('leave', compact('heading', 'icon', 'name', 'data'));
    }

    public function casualleave_add()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add CL";
        $user = Usermaster::where('status', '1')
            ->where('role', '<>', 'admin')
            ->get(["id", "firstname", "secondname"]);
        return view('casualleave_add', compact('heading', 'icon', 'name', 'user'));
    }

    public function casualleave_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'ldate' => 'required|date|unique:leaves,ldate,NULL,employee,employee,'.$request->employee,
            'type' => '1',
            'employee' => 'required',
            'daytype' => 'required',
        ]);
        $validatedData['status'] = '2';
        $data = Leaves::create($validatedData);
        $batch = $data->id;
        $data->update(['batch' => $batch]);
        return back()->with('success', 'Congratulations, You have created a new Leave successfully.');
    }
    public function casualleave_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Leave";
        $user = Usermaster::where('status', '1')
            ->where('role', '<>', 'admin')
            ->get(["id", "firstname", "secondname"]);
        $data = Leaves::where('id', $id)->get();
        return view('casualleave_edit', compact('heading', 'icon', 'name', 'user', 'data'));
    }

    public function casualleave_update(Request $request, $id)
    {
        $status = $request->input('status');
        $updateData = $this->validate($request, [
            'ldate' => 'required',
            'employee' => 'required',
            'daytype' => 'required',
            'status' => 'required',
        ]);
        if($status == '5'){
            $updateData['daytype'] =0.0;
        }
        Leaves::whereId($id)->update($updateData);
        $batch = Leaves::find($id)->batch;
        Leaves::where('batch', $batch)->update(['status'=>$status]);
        return back()->with('success', 'Congratulations, You have updated a leave successfully.');
    }

    public function casualleave_delete($id)
    {
        Leaves::where('batch', $id)->delete();
        return redirect('/leave')
            ->with('success', 'Congratulations, You have deleted a leave successfully');

    }
    public function leave_view($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Leave";
        $data = Leaves::where('id', $id)->get();
        /*-----Same function is using in admin dashboard. That's why fetched employee id in this way*/
        $employee = $data[0]['employee'];
        $now = Carbon::now();
        $sdate = $now->startOfMonth()->format('Y-m-d');
        $edate = $now->endOfMonth()->format('Y-m-d');
//        $user = Usermaster::where('status', '1')
//            ->where('role', '<>', 'admin')
//            ->get(["id", "firstname", "secondname"]);
        $el_limit = $el = $cl = $cf_cl = $cf_el = $takenCl = $takenEl = 0;
        $array = Configuration::where('caption','EL_apply_limit')
            ->orWhere('caption','EL')
            ->orWhere('caption','CL')->get();
        if(($data->count()) >0){
            foreach ($array as $key=>$value ) {
                switch($value->caption) {
                    case('CL'):
                        $cl = $value->value;
                        break;
                    case('EL'):
                        $el = $value->value;
                        break;
                    case('EL_apply_limit'):
                        $el_limit = $value->value;
                        break;
                    default:
                }
            }
        }
        $carryforwards = SalaryRecord::where('employee', $employee)->orderBy('id', 'desc')->first();
        if($carryforwards != null){
            if(($carryforwards->count()) >0){
                $cf_cl = $carryforwards->cf_cl;
                $cf_el = $carryforwards->cf_el;
            }
        }
        $leavetook = Leaves::where('employee', $employee)
            ->where('status', '2')
            ->whereBetween('ldate',[$sdate, $edate])->get();
        if(($leavetook->count()) > 0){
            $takenCl = $leavetook->where('type', '1')->sum('daytype');
            $takenEl = $leavetook->where('type', '2')->sum('daytype');
        }
        $balanceCL = ($cl + $cf_cl) - $takenCl;
        $balanceEL = ($el + $cf_el) - $takenEl;
        if($balanceCL < 0){
            $balanceCL = 0;
        }
        if($balanceEL < 0){
            $balanceEL = 0;
        }
        return view('leave_view',
            compact('heading', 'icon', 'name', 'data', 'balanceCL', 'balanceEL'));
    }
    public function absent_view($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Balance Leaves";
        $now = Carbon::now();
        $sdate = $now->startOfMonth()->format('Y-m-d');
        $edate = $now->endOfMonth()->format('Y-m-d');
        $el_limit = $el = $cl = $cf_cl = $cf_el = $takenCl = $takenEl = 0;
        $array = Configuration::where('caption','EL_apply_limit')
            ->orWhere('caption','EL')
            ->orWhere('caption','CL')->get();
        DB::statement("SET SQL_MODE=''");
        $data = Leaves::whereBetween('ldate', [$sdate, $edate])->where('employee', $id)->groupby('batch')->get();
//        dd($data->toArray());
        if(($data->count()) >0){
            foreach ($array as $key=>$value ) {
                switch($value->caption) {
                    case('CL'):
                        $cl = $value->value;
                        break;
                    case('EL'):
                        $el = $value->value;
                        break;
                    case('EL_apply_limit'):
                        $el_limit = $value->value;
                        break;
                    default:
                }
            }
        }
        $carryforwards = SalaryRecord::where('employee', $id)->orderBy('id', 'desc')->first();
        if($carryforwards != null){
            if(($carryforwards->count()) >0){
                $cf_cl = $carryforwards->cf_cl;
                $cf_el = $carryforwards->cf_el;
            }
        }
        $leavetook = Leaves::where('employee', $id)
            ->where('status', '2')
            ->whereBetween('ldate',[$sdate, $edate])->get();
        if(($leavetook->count()) > 0){
            $takenCl = $leavetook->where('type', '1')->sum('daytype');
            $takenEl = $leavetook->where('type', '2')->sum('daytype');
        }
        $balanceCL = ($cl + $cf_cl) - $takenCl;
        $balanceEL = ($el + $cf_el) - $takenEl;
        if($balanceCL < 0){
            $balanceCL = 0;
        }
        if($balanceEL < 0){
            $balanceEL = 0;
        }
        return view('absent_view',
            compact('heading', 'icon', 'name',  'balanceCL', 'balanceEL'));
    }
    public function request()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Requests";
        DB::statement("SET SQL_MODE=''");
        $data = Leaves::with('remployee', 'rbemployee')
            ->where('status', '<', 2)
            ->groupBy('batch')
            ->orderBy('id', 'desc')
            ->paginate($this->pageno);
        return view('request', compact('heading', 'icon', 'name', 'data'));
    }

    public function request_action($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Request";
        $data = Leaves::with('remployee')->where('id', $id)->get();
        return view('request_action', compact('heading', 'name', 'data'));
    }

    public function request_update(Request $request, $id)
    {
        $status = $request->input('status');
        $updateData = $this->validate($request, [
            'status' => 'required',
        ]);
        Leaves::whereId($id)->update($updateData);
        $batch = Leaves::find($id)->batch;
        Leaves::where('batch', $batch)->update(['status'=>$status]);
        return redirect('/request')
            ->with('success', 'You have deleted a leave successfully');
    }


}
