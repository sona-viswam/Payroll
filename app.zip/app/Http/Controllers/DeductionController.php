<?php

namespace App\Http\Controllers;

use App\Models\Deduction;
use App\Models\Usermaster;
use Illuminate\Http\Request;

class DeductionController extends Controller
{
    public $head = "DEDUCTION";
    public $icon = "mdi mdi-playlist-minus";

    public function deduction()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $data = Deduction::with('remployee')->orderBy('id', 'desc')->paginate($this->pageno);
        return view('deduction', compact('heading', 'icon', 'name', 'data'));
    }

    public function deduction_add()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Deduction";
        $user = Usermaster::where('status', '1')
                ->where('role', '<>', 'admin')->get(["id", "firstname", "secondname"]);
        return view('deduction_add', compact('heading', 'icon', 'name', 'user'));
    }

    public function deduction_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'employee' => 'required',
            'amount' => 'required',
            'title' => 'required',
            'ddate' => 'required',
        ]);
        Deduction::create($validatedData);
        return back()->with('success', 'Congratulations, You have created a new Deduction successfully.');
    }
    public function deduction_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Deduction";
        $user = Usermaster::where('status', '1')->where('role', '<>', 'admin')
                ->get(["id", "firstname", "secondname"]);
        $data = Deduction::where('id', $id)->get();
        return view('deduction_edit', compact('heading', 'icon', 'name', 'user', 'data'));
    }

    public function deduction_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'employee' => 'required',
            'amount' => 'required',
            'title' => 'required',
            'ddate' => 'required',
        ]);
        Deduction::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a Deduction successfully.');
    }

    public function deduction_view($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Details";
        $data = Deduction::where('id', $id)->get();
        return view('deduction_view', compact('heading', 'icon', 'name', 'data'));
    }

    public function deduction_delete($id)
    {
        $record = Deduction::findOrFail($id);
        $record->delete();
        return redirect('/deduction')
            ->with('success', 'Congratulations, You have deleted a Deduction successfully');

    }
}
