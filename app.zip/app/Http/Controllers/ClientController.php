<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\ClientProject;
use App\Models\JobCard;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    public $head = "CLIENT";
    public $icon = "mdi mdi-account-box-outline";

    public function client()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $start = Carbon::now()->startOfMonth();
        $data = Client::orderBy('id')->paginate($this->pageno);
        return view('client', compact('heading', 'icon', 'name', 'data'));
    }

    public function client_add()
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Add Client";
        return view('client_add', compact('heading','icon', 'name'));
    }

    public function client_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'client' => 'required|unique:client',
        ]);
        Client::create($validatedData);
        return back()->with('success', 'Congratulations, You have created a new Client successfully.');
    }

    public function client_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Client";
        $data = Client::where('id', $id)->get();
        return view('client_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function client_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'client' => 'required|unique:client,client,' . $id,
        ]);
        Client::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a Client successfully.');
    }

    public function client_delete($id)
    {
        if( (ClientProject::where('client', '=', $id)->exists()) || (JobCard::where('client', '=', $id)->exists()) ) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';
        }else{
            $data = Client::findOrFail($id);
            $data->delete();
            $msg = 'Congratulations, You have deleted a Client successfully';
            $msgType='warning';
        }
        return redirect('/client')
            ->with($msgType, $msg);
    }
}
