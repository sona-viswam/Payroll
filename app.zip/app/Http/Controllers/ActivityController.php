<?php

namespace App\Http\Controllers;

use App\Models\Activity;

use App\Models\JobCard;
use Illuminate\Http\Request;


class ActivityController extends Controller
{
    public $head = "ACTIVITY";
    public $icon = "mdi mdi-wunderlist";

    public function activity()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $data = Activity::paginate($this->pageno);
        return view('activity', compact('heading', 'icon', 'name', 'data'));
    }

    public function activity_add()
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Add Activity";
       return view('activity_add', compact('heading', 'icon', 'name'));
    }

    public function activity_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'activity' => 'required|unique:activity',
        ]);
        Activity::create($validatedData);
        return back()->with('success', 'You have created a new Activity successfully.');
    }

    public function activity_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Activity";
        $data = Activity::where('id', $id)->get();
        return view('activity_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function activity_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'activity' => 'required|unique:activity,activity,' . $id,
        ]);
        Activity::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a Activity successfully.');
    }

    public function activity_delete($id)
    {
        if(JobCard::where('activity', '=', $id)->exists())  {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType ='error';
        }else{
            $data = Activity::findOrFail($id);
            $data->delete();
            $msg = 'Congratulations, You have deleted a Activity successfully';
            $msgType ='warning';
        }
        return redirect('/activity')
            ->with($msgType, $msg);
    }
}
