<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\ClientProject;
use App\Models\Project;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ClientProjectController extends Controller
{
    public $head = "CLIENT'S PROJECT";
    public $icon = "mdi mdi-book-multiple";

    public function clientproject($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $data = ClientProject::where('client', $id)->with('aproject')->
                orderBy('id')->get();
        $name = Client::find($id)->client;
        return view('clientproject', compact('heading', 'icon', 'name', 'data', 'id'));
    }

    public function clientproject_add($id)
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Add Project";
       $client = Client::get(["id","client"]);
       $project = Project::get(["id","project"]);
       return view('clientproject_add', compact('heading', 'icon', 'name', 'client', 'project', 'id'));
    }

    public function clientproject_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'client' => 'required',
            'project' => 'required|unique:clientproject,project,NULL,client,client,'.$request->client,
        ]);
        ClientProject::create($validatedData);
        return back()->with('success', 'Congratulations, You have created a new Client s Project successfully.');
    }

    public function clientproject_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Project";
        $data = ClientProject::where('id', $id)->get();
        $client = Client::get(["id","client"]);
        $project = Project::get(["id","project"]);
        return view('clientproject_edit', compact('heading', 'icon', 'name', 'data', 'client', 'project'));
    }

    public function clientproject_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'client' => 'required',
            'project' => 'required|unique:clientproject,project,NULL,client,client,'.$request->client.',id,id'.$id,
        ]);
        ClientProject::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a Client s Project successfully.');
    }

    public function client_delete($id)
    {
        $client = Client::findOrFail($id);
        $client->delete();
        return redirect('/client')
            ->with('success', 'Congratulations, You have deleted a Client s Project successfully');

    }
    public function fetch_clientproject(Request $request)
    {
        $data['module'] = ClientProject::where('client', $request->input)->with('aproject')
                            ->get()->pluck('aproject');
        return response()->json($data);
    }

}
