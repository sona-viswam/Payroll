<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\Client;
use App\Models\JobCard;
use App\Models\Module;
use App\Models\Project;
use App\Models\Userlog;
use App\Models\Usermaster;
use App\Models\Work;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use MongoDB\Driver\Session;

class JobCardController extends Controller
{
    public $head = "JOBCARD";
    public $icon = "mdi mdi-account-network";

    public function jobcard()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = 'JobCard';
        $data = JobCard::with('remployee')->where('status', '>=', '2')
                    ->orderBy('id','desc')
                    ->paginate($this->pageno);
        return view('jobcard', compact('heading', 'icon', 'name', 'data'));
    }
    public function jobcard_add()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add JobCard";
        $user = Usermaster::where('status', '1')
            ->where('role', '<>', 'admin')
            ->get(["id", "firstname", "secondname"]);
        return view('jobcard_add', compact('heading', 'icon', 'name', 'user'));
    }
    public function jobcard_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'employee' => 'required',
            'jobdate' => 'required|date|unique:jobcard,jobdate,NULL,employee,employee,'.$request->employee,
            'status' => '1',
        ]);
        JobCard::create($validatedData);
        return back()->with('success', 'You have created a new jobcard successfully.');
    }
    public function works($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $jobcard = JobCard::where('id', $id)->get();
        $aDate =$jobcard[0]->jobdate;
        $user = $jobcard[0]->employee;
        $username = $jobcard[0]->remployee->fullname;
        $data = Work::where('jobcardid', $id)->get();
        $name = "Works of ".$username.' on '.$aDate;
        $log = Userlog::select(
                DB::raw('MIN(CASE WHEN status = 1 THEN logtime END) AS firstlogin'),
                DB::raw('MAX(CASE WHEN status = 2 THEN logtime END) AS lastlogout'))
                ->where('employee',  $user)->whereDate('logtime', $aDate)
                ->groupBy('employee')->get();
        if(count($log)>0){
            $login = $log[0]->firstlogin;
            $logout = $log[0]->lastlogout;
            $to = Carbon::parse($login);
            $from = Carbon::parse($logout);
            $workmin = $to->diffInMinutes($from);
        }else{
            $workmin = $login = $logout = 0;
        }
        return view('works',
            compact('heading', 'icon', 'name',  'data', 'login', 'logout', 'workmin'));
    }
    public function work_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Work";
        $data = Work::where('id', $id)->get();
        $activity = Activity::get(["id","activity"]);
        $client = Client::get(["id","client"]);
        $project = Project::where('status', '1')->get(["id","project"]);
        $currntProject = $data[0]->type1;
        $currntModule = $data[0]->type2;

        if($currntProject >0){
            $module = Module::where('product',$currntProject)->whereNull('parent')->
            get(["modulename", 'id']);
        }else{
            $module = array();
        }
        if($currntModule >0){
            $submodule = Module::where('parent',$currntModule)->whereNotNull('parent')->
            get(["modulename", 'id']);
        }else{
            $currntModule = '';
            $submodule = array();
        }
        return view('mywork_edit',
            compact('heading', 'icon', 'name', 'activity', 'client', 'project', 'data', 'module', 'submodule'));
    }

    public function work_update(Request $request, $id)
    {
        $timetaken = $request->input('timetaken');
        $oldtimetaken = $request->input('oldtimetaken');
        $jobcardid = $request->input('jobcardid');

        $validatedData = $this->validate($request, [
            'employee' => 'nullable',
            'activity' => 'required',
            'client' => 'nullable',
            'type1' => 'nullable',
            'type2' => 'nullable',
            'type3' => 'nullable',
            'description' => 'required',
            'timetaken' => 'required|numeric|gt:0',
            'cost' => 'nullable',
            'starttime' => 'required',
            'endtime' => 'required|after:starttime',
        ]);
        $validatedData['employee'] = $myid = auth()->id();
        if($timetaken != $oldtimetaken){
            $hours = $timetaken / 60;
            $unit = DB::select("SELECT unitSalary($myid) as myunitsalary");
            $unitSalary = $unit[0]->myunitsalary;
            $validatedData['cost'] = $hours * $unitSalary;
        }
        Work::whereId($id)->update($validatedData);

        return redirect('/works/'.$jobcardid)
            ->with('success', 'Congratulations, You have updated a JobCard successfully.');
    }
    public function work_delete($id)
    {
        $data = Work::findOrFail($id);
        $jobcardid = $data->jobcardid;
        $status = JobCard::find($jobcardid)->status;
        if($status == '3' ) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';
        }else{
            $data->delete();
            $msg = 'Congratulations, You have deleted a JobCard successfully';
            $msgType='warning';
        }
        return redirect('/works/'.$jobcardid)
            ->with($msgType, $msg);
    }
//    public function jobcard_edit($id)
//    {
//        $heading = $this->head;
//        $icon = $this->icon;
//        $name = "Edit JobCard";
//        $data = JobCard::where('id', $id)->get();
//        return view('jobcard_edit',
//            compact('heading', 'icon', 'name', 'data'));
//    }
    public function jobcard_update(Request $request, $id)
    {
        $validatedData = $this->validate($request, [
            'status' => 'required',
        ]);
        JobCard::whereId($id)->update($validatedData);
        return redirect('/jobcard')
            ->with('success', 'Congratulations, You have updated a new JobCard successfully.');
    }

    public function jobcard_delete($id)
    {
        $data = JobCard::findOrFail($id);
        $status = $data->status;
        if($status == '3' ) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';
        }else{
            $data->delete();
            $msg = 'Congratulations, You have deleted a JobCard successfully';
            $msgType='warning';
        }
        return redirect('/jobcard')->with($msgType, $msg);
    }
    public function job_calculate()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Calculate Time";
        $today = Carbon::today()->format('Y-m-d');
        $user = Usermaster::where('status', '1')
            ->where('role', '<>', 'admin')
            ->get(["id", "firstname", "secondname"]);
        $project = Project::get(["id","project"]);
        return view('job_calculate', compact('heading', 'icon', 'name',  'user',
            'project', 'today'));
    }
    public function job_calculation(Request $request)
    {
        $validatedData = $this->validate($request, [
            "date1" => "nullable|date|required_with:date2",
            'date2' => 'nullable|date|after_or_equal:date1',
        ]);
        $employee = $request->input('employee');
        $project = $request->input('project');
        $type = $request->input('radio');
        $date1 = $request->input('date1');
        $date2 = $request->input('date2');

        $job = ['employee'=>$employee, 'project'=>$project, 'type'=>$type,
                'date1'=>$date1, 'date2'=>$date2];
        $request->session()->put('job', $job);
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Job time  ";


        DB::statement("SET SQL_MODE=''");

//        DB::enableQueryLog();
        $query = Work::with('ractivity', 'rproject')
            ->selectRaw("type1, activity, SUM(timetaken) as total_time, SUM(cost) as total_cost");
        if($employee>0){
            $query = $query->where('employee', $employee);
            $user = Usermaster::find($employee);
            $name = $name." of  ".$user->full_name;
        }
        if($project>0){
            $query = $query->where('type1', $project);
            $projectname = Project::find($project);
            $name = $name." on  ".$projectname->project;
        }
        if($date1) {
            if(!$date2){
                $name.= " on ". $date1;
                $query->whereDate('starttime',  $date1);
            }else{
                $query->whereDate('starttime', '>=', $date1);
            }
        }
        if($date2) {
            $query->whereDate('starttime', '<=', $date2);
            if($date1)
                $name.= " from ". $date1. " to ".$date2;
        }
        if($type=='type1'){
            $query->whereNotNull('type1');
        }
        $query->groupBy($type);
        $data = $query->get();
//        $query1 = DB::getQueryLog();
//        dd($data->toArray());
        return view('job_calculated', compact('heading', 'icon', 'name',  'data'));
    }
    public function job_calculation_detailed($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Info";
        if(session('job'))
//        dd(session('job'));
        $job = session('job');
        $employee = $job['employee'];
        $project = $job['project'];
        $type = $job['type'];
        $date1 = $job['date1'];
        $date2 = $job['date2'];
        DB::statement("SET SQL_MODE=''");
//        $data = Work::selectRaw("employee, activity, type1, SUM(timetaken) as total_time, SUM(cost) as total_cost")
//            ->where('activity', $id)->where('type1', $project)
//            ->groupBy('employee')->get();
        $query = Work::with('ractivity', 'rproject')
            ->selectRaw("employee, type1, activity, SUM(timetaken) as total_time, SUM(cost) as total_cost");

        if($id ==0)
            $id=null;
        if($type == 'Activity'){
            $query = $query->where('activity', $id);
        }else{
            $query = $query->where('type1', $id);
        }
        if($employee>0){
            $query = $query->where('employee', $employee);
        }
        if($project>0){
            $query = $query->where('type1', $project);
        }
        if($date1) {
            $query->whereDate('starttime', '>=', $date1);
        }
        if($date2) {
            $query->whereDate('starttime', '<=', $date2);
        }
        $query->groupBy('employee');
        $data= $query->get();

        return view('job_calculation', compact('heading', 'icon', 'name', 'data', 'type'));
    }
}
