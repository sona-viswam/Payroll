<?php

namespace App\Http\Controllers;

use App\Models\ClientProject;
use App\Models\JobCard;
use App\Models\Module;
use App\Models\Project;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public $head = "PROJECT";
    public $icon = "mdi mdi-laptop-chromebook";

    public function project()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $data = Project::orderBy('id')->paginate($this->pageno);
        return view('project', compact('heading', 'icon', 'name', 'data'));
    }

    public function project_add()
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Add Project";
        return view('project_add', compact('heading','icon', 'name'));
    }

    public function project_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'project' => 'required|unique:project',
            'status' => 'required',
        ]);
        Project::create($validatedData);
        return back()->with('success', 'Congratulations, You have created a new Project successfully.');
    }

    public function project_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Project";
        $data = Project::where('id', $id)->get();
        return view('project_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function project_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'project' => 'required|unique:project,project,' . $id,
            'status' => 'required',
        ]);
        Project::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a Project successfully.');
    }


    public function project_delete($id)
    {
        if( (ClientProject::where('project', '=', $id)->exists()) || (JobCard::where('type1', '=', $id)->exists()) ) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';
        }else{
            $data = Project::findOrFail($id);
            $data->delete();
            $msg = 'Congratulations, You have deleted a Project successfully';
            $msgType='warning';
        }
        return redirect('/project')
            ->with($msgType, $msg);
    }
    public function fetch_project()
    {
        $data['module'] = Project::get();
        return response()->json($data);
    }


}
