<?php

namespace App\Http\Controllers;
use App\Models\Leaves;
use App\Models\Usermaster;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Mail;
use App\Mail\EmailDemo;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Validation\Rule;
use App\Rules\CheckEmployeeLeaveRule;
use Closure;


class MailController extends Controller {

    public function sendEmail(Request $request)
    {
        $ldate = $request->input('ldate');
        $eldate = Carbon::now()->addDay(3);
        $validatedData = $this->validate($request, [
//            'ldate' => 'required|date|unique:leaves,ldate,NULL,employee,employee,'.auth()->id(),
            'ldate' => ['required','date','unique:leaves,ldate,NULL,employee,employee,'.auth()->id(), function (string $attribute, mixed $value, Closure $fail) use ($request, $eldate) {
                if ($request->type==2 && $eldate->gt($value)) {
                    $fail("The {$attribute} is invalid.");
                }
            }],
            'ldate2'      => 'nullable|date|after_or_equal:ldate',
            'type' => 'required',
            'daytype' => 'required',
            'employee' => [
                'required',
                new CheckEmployeeLeaveRule($ldate)
            ],
            'bemployee' => 'required_if:employee, ==, 2|different:employee',
            'subject' => 'required',
            'content' => 'required',
        ]);
        $leave = $ldate;
        $type = $request->input('type');
        $subject = $request->input('subject');
        $content = $request->input('content');
        $be_name = $email = null;
        if($type != 1){
            $bemployee = $request->input('bemployee');
            $data = Usermaster::find($bemployee);
            $be_name = $data->fullname;
            $email = $data->email;
        }

        $ldate2 = $request->input('ldate2');
        $interval = 0;
        if($ldate2 != null){
            $leave.= ' - '. $ldate2;
            $startdate = Carbon::createFromFormat('Y-m-d', $ldate);
            $enddate = Carbon::createFromFormat('Y-m-d', $ldate2);
            $interval = $enddate->diffInDays($startdate);
            $nextdate = $startdate->addDays(1);
//            $validatedData['daytype'] = $interval;
            $validatedData['daytype'] = 1;
//            echo 'start date:'.$startdate.'<br>';
//            echo 'next date:'.$nextdate.'<br>';
//            echo 'end date:'.$enddate.'<br>';
        }

        $data = Leaves::create($validatedData);
        $batch = $data->id;
        $data->update(['batch' => $batch]);

        if($interval >0){
            $period = CarbonPeriod::create($nextdate, $enddate);
// Iterate over the period
            foreach ($period as $date) {
//                echo $date->format('Y-m-d').'<br>';
//                $newdate = $date->format('Y-m-d');
                $validatedData['ldate'] = $date->format('Y-m-d');
                $validatedData['ldate2'] = $validatedData['subject'] = $validatedData['content'] = null;
                $validatedData['batch'] = $batch;
                Leaves::create($validatedData);
//                dd($validatedData);
            }
        }



        $mailData = [
            'title' => 'Milestone',
            'url' => 'https://www.positronx.io',
            'bemployee' => $be_name,
            'subject' => $subject,
            'leavedate' => $leave,
            'content' => $content,
        ];
//        $email ='sona.viswam@gmail.com';
        $adminemail ='hr@milestoneit.net';
        if(isset($email)){
            Mail::to($email)->send(new EmailDemo($mailData));
        }

        Mail::to($adminemail)->send(new EmailDemo($mailData));

        return redirect()->route('myleave');
//        return response()->json([
//            'message' => 'Email has been sent.'
//        ], Response::HTTP_OK);
    }

}
