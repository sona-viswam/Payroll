<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\Designation;
use App\Models\Userdesignation;
use Illuminate\Http\Request;
use Session;

class DepartmentController extends Controller
{
    public $head = "DEPARTMENT";
    public $icon = "mdi mdi-apps-box";

    public function department()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $data = Department::paginate($this->pageno);
        return view('department', compact('heading', 'icon', 'name', 'data'));
    }

    public function department_add()
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Add Department";
       return view('department_add', compact('heading', 'icon', 'name'));
    }

    public function department_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'department' => 'required|unique:department',
        ]);
        Department::create($validatedData);
        return back()->with('success', 'You have created a new Department successfully.');
    }

    public function department_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Department";
        $data = Department::where('id', $id)->get();
        return view('department_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function department_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'department' => 'required|unique:department,department,' . $id,
        ]);
        Department::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a Department successfully.');
    }

    public function department_delete($id)
    {
        if( (Userdesignation::where('department', '=', $id)->exists()) || (Designation::where('department', '=', $id)->exists()) ) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';
        }else{
            $data = Department::findOrFail($id);
            $data->delete();
            $msg = 'Congratulations, You have deleted a Designation successfully';
            $msgType='warning';
        }
        return redirect('/department')
            ->with($msgType, $msg);
    }
}
