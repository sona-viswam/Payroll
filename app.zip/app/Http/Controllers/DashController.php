<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use App\Models\Holiday;
use App\Models\JobCard;
use App\Models\Leaves;
use App\Models\Userlog;
use App\Models\Usermaster;
use App\Models\Work;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class DashController extends Controller
{
    public $head = "DASHBOARD";
    public $icon = "mdi mdi-home";

    public function dashboard(Request $request)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name ='Absent Today';
//        ----------data1 = Total Empoyees and their present and Absent----------
        $data = Usermaster::select('id','firstname', 'secondname', 'photo')
                ->where('status', '1')
                ->where('role', '<>', 'admin')
                ->whereNotIn('id',
                    Userlog::where(DB::raw('DATE(logtime)'), '=', Carbon::today()->toDateString())
                        ->pluck('employee'))
                ->whereNotIn('id', Leaves::where('ldate', '=', Carbon::today()->toDateString())->pluck('employee'))
                ->get();
        $absent= $data->count();
        DB::statement("SET SQL_MODE=''");
        $data4 = Leaves::with('remployee', 'rbemployee')
            ->where('ldate', '=', Carbon::today()->toDateString())
            ->groupBy('batch')
            ->orderBy('ldate','ASC')->get();
//        dd($data4->toArray());
//        $data4 = Usermaster::select('id','firstname', 'secondname', 'photo')
//            ->where('status', '1')
//            ->where('role', '<>', 'admin')
//            ->whereNotIn('id',
//                Userlog::where(DB::raw('DATE(logtime)'), '=', Carbon::today()->toDateString())
//                    ->pluck('employee'))
//            ->whereIn('id', Leaves::where('ldate', '=', Carbon::today()->toDateString())->pluck('employee'))
//            ->get();

        $absent= $data->count() + $data4->count();
        $firstday = Carbon::now()->addDays(1)->format('Y-m-d');
        $nextday = Carbon::now()->addDays(10)->format('Y-m-d');
        DB::statement("SET SQL_MODE=''");
        $data5 = Leaves::whereBetween('ldate', [$firstday, $nextday])
                ->groupBy('batch')
                ->orderBy('ldate','ASC')->get();
        DB::statement("SET SQL_MODE=''");
        $arr = Userlog::whereDate('logtime', Carbon::today())
               ->groupBy('employee')->get();
        $present = $arr->count();
        $total = Usermaster::where('status', '1')->where('role', 'user')->count();
//        ----------data1 ends----------

//        ----------data2 = Holidays----------
        $array = Holiday::whereYear('hdate', date('Y'))
            ->orderBy('hdate')->paginate($this->pageno);
//        ----------data2 ends----------
//        ----------data3 = My attendance for graph----------
        $now = Carbon::now();
        $tot_daysofmonth = $now->daysInMonth;
        $day_today = $now->format('d');
        $month_today = $now->format('m');
        $year_today = $now->format('Y');
        $balancedays = $tot_daysofmonth - $day_today;
        $month_percentage = round(($day_today/$tot_daysofmonth) *  100);
        $tot_sundays = $this->total_sun($month_today, $year_today);
        $attendance = Userlog::where('employee', auth()->id())
            ->whereMonth(DB::raw('logtime'), $month_today)
            ->whereYear(DB::raw('logtime'),  $year_today)
            ->select(DB::raw('DATE(logtime) as logdate'))
            ->groupBy('logdate')->get();
        $attendance_count = $attendance->count();
//        $myDate = '2021-12-31';
//        $date = Carbon::createFromFormat('Y-m-d', $myDate)->format('l');
//        dd($date);

        $endDate = $now->format('Y-m-d');
        $startDate = $now->startOfMonth()->format('Y-m-d');
        $sundays = $this->sundays($startDate, $endDate);

        $attSun = $attendance_count+$sundays;
        $present_percentage = round(($attSun/$tot_daysofmonth) *  100);
        $absent_count = $day_today - $attSun;
        $absent_percentage = round(($absent_count/$tot_daysofmonth) *  100);
        $data6 = $data7 = [];
        $yesterday_totaltime = $lastweek_totaltime = $yesterday_pending =$lastweek_pending=0;
        if ( Auth::user()->isAdmin() ){
//            $lastRecordDate = Work::all('created_at')->max('created_at')->toArray();//
//            dd( $lastRecordDate["formatted"]);
            $yesterday = Carbon::yesterday()->format('Y-m-d');
            $day = Carbon::yesterday()->format('l');
            if($day == 'Sunday'){
                $yesterday = Carbon::now()->subDays(2);
            }

            DB::statement("SET SQL_MODE=''");
            $data6 = Work::selectRaw("type1,  SUM(timetaken) as total_time")
                ->whereDate('starttime', $yesterday)
//                ->where('activity', 1)
                ->whereNotNull('type1')
                ->groupBy('type1')
                ->get();
//            DB::enableQueryLog();
//            $array6 = Work::whereIn('jobcardid',JobCard::whereDate('jobdate', $yesterday)->where('status', 1)->get('id'))
//                ->whereDate('starttime', $yesterday)
//                ->where('activity', 1)
//                ->whereNotNull('type1')
//                ->groupBy('type1')->get('type1');
//            dd(DB::getQueryLog());
//            $arr6 =JobCard::whereDate('jobdate', $yesterday)
//                ->where('status','<>', 1)->get('id') ;
            $yesterday_pending = JobCard::whereDate('jobdate', $yesterday)->where('status', '<>',3)->count();
            $yesterday_totaltime = $data6->sum->total_time;
            $data7 = Work::selectRaw("type1, SUM(timetaken) as total_time")
                ->whereDate('starttime','>', Carbon::now()->subDays(7))
                ->whereNotNull('type1')
                ->groupBy('type1')->get();
            $lastweek_totaltime = $data7->sum->total_time;
            $lastweek_pending = JobCard::whereBetween('jobdate', [Carbon::now()->subDays(7), $yesterday])->where('status', '<>',3)->count();
        }

        return view('dashboard', compact('heading', 'icon', 'name', 'data', 'total',
            'present', 'absent','array', 'month_percentage', 'present_percentage', 'absent_percentage',
            'data4', 'data5', 'data6', 'yesterday_totaltime', 'yesterday_pending',
            'data7','lastweek_totaltime', 'lastweek_pending'));
    }

    public function total_sun($month,$year)
    {
        $sundays=0;
        $total_days=cal_days_in_month(CAL_GREGORIAN, $month, $year);
        for($i=1;$i<=$total_days;$i++)
            if(date('N',strtotime($year.'-'.$month.'-'.$i))==7)
                $sundays++;
        return $sundays;
    }

    public function sundays($startDate,$endDate)
    {
        $sundays=0;
        while ($startDate <= $endDate) {
            $checkdate = Carbon::createFromFormat('Y-m-d', $startDate);
            $checkday = $checkdate->format('l');
            if ($checkday == 'Sunday') {
                $sundays++;
            }
            $startDate = $checkdate->addDays(1)->format('Y-m-d');;
        }
        return $sundays;
    }


}

