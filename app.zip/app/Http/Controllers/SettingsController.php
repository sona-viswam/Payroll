<?php

namespace App\Http\Controllers;


use App\Models\Configuration;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public $head = "SETTINGS";
    public $icon = "mdi mdi-settings";

    public function settings()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $data = Configuration::orderBy('id')->paginate($this->pageno);
        return view('settings', compact('heading', 'icon', 'name', 'data'));
    }

    public function settings_add()
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Add Settings";
        return view('settings_add', compact('heading', 'icon', 'name'));
    }

    public function settings_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'caption' => 'required|unique:configuration',
            'value' => 'required',
        ]);
        Configuration::create($validatedData);
        return back()->with('success', 'You have created a new Settings successfully.');
    }

    public function settings_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Settings";
        $data = Configuration::where('id', $id)->get();
        return view('settings_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function settings_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'caption' => 'required',
            'caption' => 'required|unique:configuration,caption,' . $id,
            'value' => 'required',
        ]);
        Configuration::whereId($id)->update($updateData);
        return back()->with('success', 'You have updated a Settings successfully.');
    }

    public function settings_delete($id)
    {
        $data = Configuration::findOrFail($id);
        $data->delete();
        return redirect('/settings')
            ->with('success', 'You have deleted a Settings successfully');

    }
}
