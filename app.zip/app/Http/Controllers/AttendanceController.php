<?php

namespace App\Http\Controllers;

use App\Models\Holiday;
use App\Models\Leaves;
use App\Models\Userlog;
use App\Models\Usermaster;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AttendanceController extends Controller
{
    public $head = "ATTENDANCE";
    public $icon = "mdi mdi-human-greeting";

    public function attendance()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Today's Attendance";
//        DB::enableQueryLog();
        DB::statement("SET SQL_MODE=''");
        $data = Usermaster::rightJoin('userlog', 'usermaster.id', '=', 'userlog.employee')
            ->select('usermaster.id','usermaster.firstname', 'usermaster.secondname','usermaster.photo',
                DB::raw('MIN(CASE WHEN userlog.status = 1  THEN logtime END) AS firstlogin, source AS firstsource'),
                DB::raw('MAX(CASE WHEN userlog.status = 1  THEN logtime END) AS loggedin'),
                DB::raw('MAX(CASE WHEN userlog.status = 2  THEN logtime END) AS loggedout, source AS lastsource'))
            ->where(DB::raw('DATE(userlog.logtime)'), '=', Carbon::today()->toDateString())
            ->groupBy('usermaster.id')->get();
//        dd($data->toArray());
//        dd(DB::getQueryLog());
        $today = Carbon::now()->format('d-M-Y');
        return view('attendance', compact('heading', 'icon', 'name', 'data', 'today'));
    }

    public function attendance_monthly($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Monthly Attendance";
        DB::statement("SET SQL_MODE=''");
        $data = Userlog::with('remployee')->where('employee', $id)
            ->whereMonth(DB::raw('logtime'), '=', Carbon::now()->month)
            ->whereYear(DB::raw('logtime'), '=', Carbon::now()->year)
            ->select('employee', DB::raw('DATE(logtime) as logdate'),
                DB::raw('MIN(CASE WHEN userlog.status = 1  THEN logtime END) AS firstlogin'),
                DB::raw('calcstar(employee, 0, DATE(logtime), MIN(CASE WHEN userlog.status = 1  THEN logtime END)) AS latestar'),
                DB::raw('MAX(CASE WHEN userlog.status = 2  THEN logtime END) AS lastlogout'),
                DB::raw('calcstar(employee, 1, DATE(logtime), MAX(CASE WHEN userlog.status = 2  THEN logtime END)) AS earlystar'))
            ->groupBy('logdate')->get();
        $today = Carbon::now()->format('M-Y');
//        dd($data->toArray());
        if($data->count() >0){
            $empname = $data[0]->remployee->fullname;
            $name = $name.' of '.$empname;
        }
        return view('attendance_monthly', compact('heading', 'icon', 'name', 'data', 'today'));
    }

    public function attendance_bymonth($id, $sdate)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Attendance";
        $lastDayofMonth =  Carbon::parse($sdate)->endOfMonth()->format('d');
//        dd($lastDayofMonth);
        $theMonth = Carbon::parse($sdate)->month;
        $theYear = Carbon::parse($sdate)->year;
        if($theMonth<10){
            $theMonth = '0'.$theMonth;
        }else{
            $theMonth = $theMonth;
        }
        $collection = Leaves::where('employee', $id)
            ->whereMonth('ldate', $theMonth)
            ->whereYear('ldate', $theYear)
            ->get('ldate');
        $leave = $collection->keyBy('ldate');
//        dd($leave->toArray());
        $collect = Holiday::whereMonth('hdate', $theMonth)
                    ->whereYear('hdate', $theYear)
                    ->get('hdate');
        $holiday = $collect->keyBy('hdate');
//        dd($holiday->toArray());

        DB::enableQueryLog();
        DB::statement("SET SQL_MODE=''");
        $data = Userlog::with('remployee')->where('employee', $id)
            ->whereMonth(DB::raw('logtime'), '=', Carbon::parse($sdate)->month)
            ->whereYear(DB::raw('logtime'), '=', Carbon::parse($sdate)->year)
            ->select('employee', DB::raw('DATE(logtime) as logdate'),
                DB::raw('MIN(CASE WHEN userlog.status = 1  THEN logtime END) AS firstlogin'),
                DB::raw('calcstar(employee, 0, DATE(logtime), MIN(CASE WHEN userlog.status = 1  THEN logtime END)) AS latestar'),
                DB::raw('MAX(CASE WHEN userlog.status = 2  THEN logtime END) AS lastlogout'),
                DB::raw('calcstar(employee, 1, DATE(logtime), MAX(CASE WHEN userlog.status = 2  THEN logtime END)) AS earlystar'))
            ->groupBy('logdate')->get();
//                dd(DB::getQueryLog());
        $logs = $data->keyBy('logdate');
//        dd($logs->toArray());
        $today = Carbon::parse($sdate)->format('M-Y');
        if($data->count() >0){
            $empname = $data[0]->remployee->fullname;
            $name = $name.' of '.$empname;
        }
        return view('attendance_bymonth', compact('heading', 'icon', 'name', 'data', 'today', 'leave', 'holiday', 'logs', 'lastDayofMonth', 'theMonth', 'theYear'));
    }

    public function attendance_daily($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Daily Attendance";
        DB::statement("SET SQL_MODE=''");
        $data = Userlog::where('employee', $id)
            ->whereDate(DB::raw('logtime'), '=', Carbon::today()->toDateString())
            ->get();
        if($data->count() >0){
            $empname = $data[0]->remployee->fullname;
            $name = $name.' of '.$empname;
        }
        $today = Carbon::now()->format('d-M-Y');
        return view('attendance_daily', compact('heading', 'icon', 'name', 'data', 'today'));
    }

    public function attendance_add()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Attendancce";
        $user = Usermaster::where('status', '1')
                ->where('role', '<>', 'admin')
                ->get(["id", "firstname", "secondname"]);
        return view('attendance_add', compact('heading', 'icon', 'name', 'user'));
    }

    public function attendance_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'logtime' => 'required',
            'employee' => 'required',
            'status' => 'required',
            'source' => 'required',
        ]);
        Userlog::create($validatedData);
        return back()->with('success', 'Congratulations, You have created a new Attendance successfully.');
    }

    public function attendance_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Attendance";
        $data = Userlog::where('id', $id)->get();
        return view('attendance_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function attendance_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'logtime' => 'required',
            'status' => 'required',
        ]);
        Userlog::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a attendance successfully.');
    }

    public function attendance_delete($id)
    {
        $data = Userlog::findOrFail($id);
        $data->delete();
        return back()->with('success', 'Congratulations, You have deleted a record successfully.');
    }

    public function absent()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Today's Absent";
//        DB::enableQueryLog();
        DB::statement("SET SQL_MODE=''");
        $data = Usermaster::select('id','firstname', 'secondname')
            ->where('status', '1')
            ->where('role', '<>', 'admin')
            ->whereNotIn('id',
                Userlog::where(DB::raw('DATE(logtime)'), '=', Carbon::today()->toDateString())
            ->pluck('employee'))
            ->get();
//        dd(DB::getQueryLog());
        $today = Carbon::now()->format('d-M-Y');
        return view('absent', compact('heading', 'icon', 'name', 'data', 'today'));
    }

}
