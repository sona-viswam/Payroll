<?php

namespace App\Http\Controllers;

use App\Models\Shift;
use App\Models\Shiftstars;
use App\Models\Usershift;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ShiftController extends Controller
{
    public $head = "SHIFT";
    public $icon = "mdi mdi-timetable";

    public function shift()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $data = Shift::paginate($this->pageno);
        return view('shift', compact('heading', 'icon', 'name', 'data'));
    }

    public function shift_add()
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Add Shift";
        return view('shift_add', compact('heading', 'icon', 'name'));
    }

    public function shift_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'shiftname' => 'required|unique:shift',
            'starttime' => 'required',
            'endtime' => 'required',
            'breakstart' => 'required',
            'breakend' => 'required',
        ]);
        $shift = Shift::create($validatedData);
        $shift->stars()->createMany([
            [
                'startype' => 0, 'lstarmin'=>11, 'lstarpoints'=>6,
            ],
            [
                'startype' => 0, 'lstarmin'=>60, 'lstarpoints'=>9,
            ],
            [
                'startype' => 0, 'lstarmin'=>120, 'lstarpoints'=> 10,
            ],
            [
                'startype' => 0, 'lstarmin'=>180, 'lstarpoints'=>11,
            ],
            [
                'startype' => 0, 'lstarmin'=>240, 'lstarpoints'=>0,
            ],
            [
                'startype' => 1, 'lstarmin'=>120, 'lstarpoints'=>2,
            ],
            [
                'startype' => 1, 'lstarmin'=>60, 'lstarpoints'=>1,
            ],
            [
                'startype' => 1, 'lstarmin'=>0, 'lstarpoints'=>0,
            ],
        ]);
        $shiftid = $shift->id;
        return redirect('/shiftstars/'.$shiftid)
            ->with('success', 'You have created a new Shift successfully.');
    }

    public function shift_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Shift";
        $data = Shift::where('id', $id)->get();
        return view('shift_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function shift_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'shiftname' => 'required',
            'shiftname' => 'required|unique:shift,shiftname,' . $id,
            'starttime' => 'required',
            'endtime' => 'required',
            'breakstart' => 'required',
            'breakend' => 'required',
        ]);
        Shift::whereId($id)->update($updateData);
        return back()->with('success', 'You have updated a Shift successfully.');
    }

    public function shift_delete($id)
    {
        if(Usershift::where('sid', '=', $id)->exists()) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';
        }else{
            Shift::where('id',$id)->delete();
            Shiftstars::where('sid',$id)->delete();
            $msg = 'You have deleted a Shift successfully';
            $msgType='info';
        }
        return redirect('/shift')
            ->with($msgType, $msg);
    }

    public function shiftstars($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "ShiftStars";
        $data = Shiftstars::where('sid', $id)->get();
        return view('shiftstars', compact('heading', 'icon', 'name', 'data'));
    }
    public function shiftstars_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit ShiftStar";
        $data = Shiftstars::where('id', $id)->get();
        return view('shiftstars_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function shiftstar_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'sid' => 'required',
            'lstarmin' => 'required',
            'lstarpoints' => 'required',
        ]);
        $sid = $request->input('sid');
        Shiftstars::whereId($id)->update($updateData);

        return redirect('/shiftstars/'.$sid)
            ->with('success', 'You have updated a Shift successfully');
    }
}
