<?php

namespace App\Http\Controllers;


use App\Models\Holiday;
use App\Models\SalaryRecord;
use App\Models\Salaryrecordtmp;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class  SalaryController extends Controller
{
    public $head = "SALARY";
    public $icon = "mdi mdi-cash-usd";

    public function salary ()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $start = Carbon::now()->startOfMonth();
        $data = SalaryRecord::with('remployee')->orderBy('id', 'desc')->paginate($this->pageno);
        $count = Salaryrecordtmp::all()->count();
        return view('salary', compact('heading', 'icon', 'name', 'data', 'count'));
    }

    public function salary_detailed($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Detailed Salary";
        $data = Salaryrecord::with('remployee')->where('id', $id)->get();
        return view('salary_calculation_detailed', compact('heading', 'icon', 'name', 'data'));
    }

    public function salary_calculate()
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Calculate Salary";
       $lastSalaryDate = SalaryRecord::select('salary_date')->orderBy('salary_date', 'desc')->first();
       if(empty($lastSalaryDate))
       {
           $salarymonth = Carbon::now()->subMonth()->month;
           $salaryyear = Carbon::now()->subMonth()->year;
       }else{
           $lastdate = $lastSalaryDate->salary_date;
           $salarymonth = Carbon::parse($lastdate)->month +1;
           $salaryyear = Carbon::parse($lastdate)->year;
           if($salarymonth>12) {
               $salarymonth = 1;
               $salaryyear = Carbon::now()->year;
           }
       }
       return view('salary_calculate', compact('heading', 'icon', 'name', 'salarymonth', 'salaryyear'));
    }

    public function salary_calculation(Request $request)
    {
        $validatedData = $this->validate($request, [
            'salarymonth' => 'required',
            'salaryyear' => 'required',
        ]);
        $amonth = $request->salarymonth;
        $ayear = $request->salaryyear;
        $getPost = DB::select(
            'CALL SP_salaryCalculation('.$amonth.', '.$ayear.')'
        );
//        dd($getPost);
        return redirect()->route('salary_calculation_view');
    }

    public function salary_calculation_view()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Salary Calculation";
        $data = Salaryrecordtmp::with('remployee')->paginate($this->pageno);
//        dd($data->toArray());
        return view('salary_calculation_view', compact('heading', 'icon', 'name', 'data'));
    }

    public function salary_calculation_detailed($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Detailed Salary Calculation";
        $data = Salaryrecordtmp::with('remployee')->where('id', $id)->get();
        return view('salary_calculation_detailed', compact('heading', 'icon', 'name', 'data'));
    }

    public function salary_calculated_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Calculated Salary";
        $data = Salaryrecordtmp::with('remployee')->where('id', $id)->get();
        return view('salary_calculated_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function calculated_salary_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'employee' => 'required',
            'basic_salary' => 'required',
            'holiday' => 'required',
            'monthly_allowed_leave' => 'required',
            'carryforward_leave' => 'required',
            'total_leave' => 'required',
            'leave_taken' => 'required',
            'used_casualleave' => 'required',
            'blackstar' => 'required',
            'blackstar_lop' => 'required',
            'leave_lop' => 'required',
            'total_lop_days' => 'required',
            'lop_amount' => 'required',
            'salary' => 'required',
            'other' => 'required',
            'net_salary' => 'required',
          ]);
        Salaryrecordtmp::whereId($id)->update($updateData);
        return redirect()->route('salary_calculation_view');
    }

    public function salary_save()
    {
        $getPost = DB::select(
            'CALL SP_insertSalary()'
        );
        return redirect()->route('salary');
    }



}
