<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\Designation;
use App\Models\Userdesignation;
use Illuminate\Http\Request;

class DesignationController extends Controller
{
    public $head = "DESIGNATION";
    public $icon = "mdi mdi-apps";

    public function designation()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $data = Designation::paginate($this->pageno);
        return view('designation', compact('heading', 'icon', 'name', 'data'));
    }

    public function designation_add()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Designation";
        $department = Department::get(["id","department"]);
        return view('designation_add', compact('heading', 'icon', 'name', 'department'));
    }

    public function designation_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'designation' => 'required|unique:designation',
            'department' => 'required',
        ]);
        Designation::create($validatedData);
        return redirect('/designation')
            ->with('success', 'You have created a new Designation successfully');
    }

    public function designation_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Designation";
        $department = Department::get(["id","department"]);
        $data = Designation::where('id', $id)->get();
        return view('designation_edit', compact('heading', 'icon', 'name', 'department', 'data'));
    }

    public function designation_update(Request $request, $id)
    {
            'designation' => 'required|unique:designation,designation,' . $id,
            'department' => 'required',
        ]);
        Designation::whereId($id)->update($updateData);
        return redirect('/designation')
            ->with('success', 'You have updated a  Designation successfully');
    }

    public function designation_delete($id)
    {
        if(Userdesignation::where('designation', '=', $id)->exists()) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';

        }else{
            $data = Designation::findOrFail($id);
            $data->delete();
            $msg = 'Congratulations, You have deleted a Designation successfully';
            $msgType='warning';
        }
        return redirect('/designation')
            ->with($msgType, $msg);
    }

}
