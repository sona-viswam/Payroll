<?php

namespace App\Http\Controllers;

use App\Models\Holiday;
use Carbon\Carbon;
use Illuminate\Http\Request;

class HolidayController extends Controller
{
    public $head = "HOLIDAY";
    public $icon = "mdi mdi-emoticon-happy";

    public function holiday()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $start = Carbon::now()->startOfMonth();
        $data = Holiday::whereYear('hdate', date('Y'))
            ->orderBy('hdate')->paginate($this->pageno);
        return view('holiday', compact('heading', 'icon', 'name', 'data'));
    }

    public function holiday_add()
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Add Holiday";
        return view('holiday_add', compact('heading','icon', 'name'));
    }

    public function holiday_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'hname' => 'required',
            'hdate' => 'date|required',
        ]);
        Holiday::create($validatedData);
        return back()->with('success', 'Congratulations, You have created a new Holiday successfully.');
    }

    public function holiday_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Holiday";
        $data = Holiday::where('id', $id)->get();
        return view('holiday_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function holiday_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'hname' => 'required',
            'hdate' => 'date|required',
        ]);
        Holiday::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a Holiday successfully.');
    }

    public function holiday_delete($id)
    {
        $holiday = Holiday::findOrFail($id);
        $holiday->delete();
        return redirect('/holiday')
            ->with('success', 'Congratulations, You have deleted a holiday successfully');

    }
}
