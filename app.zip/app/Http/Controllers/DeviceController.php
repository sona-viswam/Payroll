<?php

namespace App\Http\Controllers;

use App\Models\Devicemaster;
use Illuminate\Http\Request;

class DeviceController extends Controller
{
    public $head = "DEVICES";
    public $icon = "mdi mdi-settings-box";

    public function device()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $data = Devicemaster::orderBy('id')->paginate($this->pageno);
        return view('device', compact('heading', 'icon', 'name', 'data'));
    }

    public function device_add()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Device";
        return view('device_add', compact('heading', 'icon', 'name'));
    }

    public function device_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'name' => 'required|unique:devicemaster',
            'serialno' => 'nullable',
            'ip' => 'required',
            'port' => 'required',
            'status' => 'required',
            'type' => 'required',
        ]);
        Devicemaster::create($validatedData);
        return back()->with('success', 'You have created a new Settings successfully.');
    }

    public function device_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Device";
        $data = Devicemaster::where('id', $id)->get();
        return view('device_edit', compact('heading', 'icon', 'name', 'data'));
    }

    public function device_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'name' => 'required',
            'name' => 'required|unique:devicemaster,name,' . $id,
            'serialno' => 'nullable',
            'ip' => 'required',
            'port' => 'required',
            'status' => 'required',
            'type' => 'required',
        ]);
        Devicemaster::whereId($id)->update($updateData);
        return back()->with('success', 'You have updated a Device successfully.');
    }

    public function device_delete($id)
    {
        $data = Devicemaster::findOrFail($id);
        $data->delete();
        return redirect('/device')
            ->with('success', 'You have deleted a Settings successfully');

    }
}
