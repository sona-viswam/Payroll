<?php

namespace App\Http\Controllers;

use App\Models\Incentive;
use App\Models\Usermaster;
use Illuminate\Http\Request;

class IncentiveController extends Controller
{
    public $head = "INCENTIVE";
    public $icon = "mdi mdi-currency-usd";

    public function incentive()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "List";
        $data = Incentive::with('remployee')->orderBy('id', 'desc')->paginate($this->pageno);
        return view('incentive', compact('heading', 'icon', 'name', 'data'));
    }

    public function incentive_add()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Incentive";
        $user = Usermaster::where('status', '1')
                ->where('role', '<>', 'admin')
                ->get(["id", "firstname", "secondname"]);
        return view('incentive_add', compact('heading', 'icon', 'name', 'user'));
    }

    public function incentive_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'employee' => 'required',
            'amount' => 'required',
            'title' => 'required',
            'idate' => 'required',
        ]);
        Incentive::create($validatedData);
        return back()->with('success', 'Congratulations, You have created a new Incentive successfully.');
    }
    public function incentive_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Incentive";
        $user = Usermaster::where('status', '1')
                ->where('role', '<>', 'admin')->get(["id", "firstname", "secondname"]);
        $data = Incentive::where('id', $id)->get();
        return view('incentive_edit', compact('heading', 'icon', 'name', 'user', 'data'));
    }

    public function incentive_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'employee' => 'required',
            'amount' => 'required',
            'title' => 'required',
            'idate' => 'required',
        ]);
        Incentive::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a Incentive successfully.');
    }
    public function incentive_view($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Details";
        $data = Incentive::where('id', $id)->get();
        return view('incentive_view', compact('heading', 'icon', 'name', 'data'));
    }

    public function incentive_delete($id)
    {
        $record = Incentive::findOrFail($id);
        $record->delete();
        return redirect('/incentive')
            ->with('success', 'Congratulations, You have deleted a Incentive successfully');

    }
}
