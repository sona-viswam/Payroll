<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Configuration;
use App\Models\Country;
use App\Models\Department;
use App\Models\Designation;
use App\Models\JobCard;
use App\Models\Leaves;
use App\Models\Module;
use App\Models\Project;
use App\Models\Salary;
use App\Models\SalaryRecord;
use App\Models\Salaryrecordtmp;
use App\Models\Shift;
use App\Models\Userdesignation;
use App\Models\Userlog;
use App\Models\Usermaster;
use App\Models\Usershift;
use App\Models\Client;
use App\Models\Work;
use Carbon\Carbon;
use Dotenv\Validator;
//use http\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Session;
use File;
use PDF;


class ProfileController extends Controller
{
    public $head = "PROFILE";
    public $icon = "mdi mdi-account";

    public function myprofile()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "My Details";
        $id = auth()->id();
        $data = Usermaster::where('id', $id)->get();
        return view('myprofile', compact('heading', 'icon', 'name', 'data'));
    }

    public function myprofile_edit()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Details";
        $countries = Country::get(["name","id"]);
        $data = Usermaster::where('id', auth()->id())->get();
        return view('myprofile_edit', compact('heading', 'icon', 'name', 'countries','data'));
    }

    public function myprofile_update(Request $request)
    {
        $updateData = $this->validate($request, [
            'firstname' => 'required',
            'secondname' => 'nullable',
            'username' => 'required|min:6|unique:usermaster,username,' . auth()->id(),
            'password'=>'required|min:6',
            'email' => 'required|email|unique:usermaster,email,' . auth()->id(),
            'gender' => 'required',
            'dob' => 'nullable',
            'qualification' => 'nullable',
            'permanentaddress' => 'nullable',
            'temporaryaddress' => 'nullable',
            'city' => 'nullable',
            'country' => 'nullable',
            'pin' => 'nullable',
            'phone' => 'nullable',
            'mobile' => 'nullable',
            'photo' => 'nullable',
            'identityno' => 'nullable',
            'identityimage' => 'nullable',
            'photo' => 'nullable|file|mimes:jpg,jpeg,bmp,png',
            'identityimage' => 'nullable|file|mimes:jpg,jpeg,bmp,png',
        ]);
        $password = $request->input('password');
        $oldpassword = $request->input('oldpassword');
        if($oldpassword !== $password){
            $updateData['password'] = bcrypt($updateData['password']);
        }
        if ($request->has('photo')) {
            $fileName = time().'.'.$request->photo->extension();
            $request->photo->move(public_path('upload'), $fileName);
            $updateData['photo'] = $fileName;
            $old_photo = $request->input('old_photo');
            if($old_photo){
                $image_path = public_path('upload').'/'.$old_photo;
                if (file_exists($image_path)) {
                     File::delete($image_path);
                }
            }
        }
        if ($request->has('identityimage')) {
            $fileName = time().'_im.'.$request->identityimage->extension();
            $request->identityimage->move(public_path('upload'), $fileName);
            $updateData['identityimage'] = $fileName;
            $old_identityimage = $request->input('old_identityimage');
            if($old_identityimage){
                $image_path = public_path('upload').'/'.$old_identityimage;
                if (file_exists($image_path)) {
                    File::delete($image_path);
                }
            }
        }
        Usermaster::whereId(auth()->id())->update($updateData);
        return redirect()->route('myprofile');
    }


    public function myattendance()
    {
        $heading = $this->head;
        $icon = "mdi mdi-human-greeting";
        $name = "Attendance";
        DB::statement("SET SQL_MODE=''");
        $data = Userlog::where('employee', auth()->id())
            ->whereMonth(DB::raw('logtime'), '=', Carbon::now()->month)
            ->whereYear(DB::raw('logtime'), '=', Carbon::now()->year)
            ->select('employee', DB::raw('DATE(logtime) as logdate'),
                DB::raw('MIN(CASE WHEN userlog.status = 1  THEN logtime END) AS firstlogin'),
                DB::raw('calcstar(employee, 0, DATE(logtime), MIN(CASE WHEN userlog.status = 1  THEN logtime END)) AS latestar'),
                DB::raw('MAX(CASE WHEN userlog.status = 2  THEN logtime END) AS lastlogout'),
                DB::raw('calcstar(employee, 1, DATE(logtime), MAX(CASE WHEN userlog.status = 2  THEN logtime END)) AS earlystar'))
            ->groupBy('logdate')->get();
//        dd($data->toArray());
        $today = Carbon::now()->format('M-Y');
        return view('myattendance', compact('heading', 'icon', 'name', 'data', 'today'));
    }

    public function mysalary()
    {
        $heading = $this->head;
        $icon = "mdi mdi-currency-usd";
        $name = "Salary";
        $data = SalaryRecord::where('employee', auth()->id())->orderBy('id', 'desc')
                ->paginate($this->pageno);
        return view('mysalary', compact('heading', 'icon', 'name', 'data'));
    }

    public function mysalary_slip($id)
    {
        $data = SalaryRecord::with('remployee')->where('id', $id)->get();
//        return view('mysalary_slip', compact('data'));
        view()->share('mysalary_slip',$data);
        $pdf = PDF::loadView('mysalary_slip', ['data' => $data]);
        return $pdf->download('salary_slip.pdf');
    }

    public function myleave()
    {
        $heading = $this->head;
        $icon = "mdi mdi-account-key";
        $name = "My Leaves";
        DB::statement("SET SQL_MODE=''");//this is the trick use it just before your query to remove error
        $data = Leaves::with('rbemployee')
            ->where('employee', auth()->id())
            ->orderBy('id', 'desc')
            ->groupBy('batch')
                ->paginate($this->pageno);
        return view('myleave', compact('heading', 'icon', 'name', 'data'));
    }

    public function myleave_add()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Leave";
        $myid = auth()->id();
        $now = Carbon::now();
        $sdate = $now->startOfMonth()->format('Y-m-d');
        $edate = $now->endOfMonth()->format('Y-m-d');
        $user = Usermaster::where('status', '1')
                ->where('role', '<>', 'admin')
                ->get(["id", "firstname", "secondname"]);
        $el_limit = $el = $cl = $cf_cl = $cf_el = $takenCl = $takenEl = 0;
        $data = Configuration::where('caption','EL_apply_limit')
                ->orWhere('caption','EL')
                ->orWhere('caption','CL')->get();
        if(($data->count()) >0){
            foreach ($data as $key=>$value ) {
                switch($value->caption) {
                    case('CL'):
                        $cl = $value->value;
                    break;
                    case('EL'):
                        $el = $value->value;
                        break;
                    case('EL_apply_limit'):
                        $el_limit = $value->value;
                        break;
                    default:
                }
            }
        }
        $carryforwards = SalaryRecord::where('employee', auth()->id())->orderBy('id', 'desc')->first();
        if($carryforwards != null){
            if(($carryforwards->count()) >0){
                $cf_cl = $carryforwards->cf_cl;
                $cf_el = $carryforwards->cf_el;
            }
        }
        $leavetook = Leaves::where('employee', auth()->id())
                    ->where('status', '2')
                    ->whereBetween('ldate',[$sdate, $edate])->get();
        if(($leavetook->count()) > 0){
            $takenCl = $leavetook->where('type', '1')->sum('daytype');
            $takenEl = $leavetook->where('type', '2')->sum('daytype');
        }
        $balanceCL = ($cl + $cf_cl) - $takenCl;
        $balanceEL = ($el + $cf_el) - $takenEl;
        if($balanceCL < 0){
            $balanceCL = 0;
        }
        if($balanceEL < 0){
            $balanceEL = 0;
        }
        return view('myleave_add',
            compact('heading', 'icon',  'name', 'user', 'el_limit', 'balanceCL', 'balanceEL'));
    }
    public function myleave_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Leave";
        $user = Usermaster::where('status', '1')
            ->where('role', '<>', 'admin')
            ->get(["id", "firstname", "secondname"]);
        $data = Leaves::with('rbemployee')->where('id', $id)->get();
        return view('myleave_edit', compact('heading', 'icon', 'name', 'user', 'data'));
    }

    public function myleave_update(Request $request, $id)
    {

        $updateData = $this->validate($request, [
            'daytype' => 'required',
            'employee' => 'required',
            'subject' => 'required',
            'content' => 'required',
        ]);
        Leaves::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a leave successfully.');
    }
    public function myleave_view($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "My Leave";
        $data = Leaves::where('id', $id)->get();
        return view('leave_view',
            compact('heading', 'icon', 'name', 'data'));
    }
    public function myleave_delete($id)
    {
        Leaves::where('batch', $id)->delete();
        $msg = 'Congratulations, You have deleted a leave successfully';
        $msgType='warning';
        return redirect('/myleave')
            ->with($msgType, $msg);
    }
    public function myrequest()
    {
        $heading = $this->head;
        $icon = "mdi mdi-email-lock";
        $name = "Requests";
        DB::statement("SET SQL_MODE=''");//this is the trick use it just before your query to remove errors
        $data = Leaves::with('remployee')
            ->where('bemployee', auth()->id())
            ->groupBy('batch')
            ->orderBy('id', 'desc')
            ->paginate($this->pageno);
        return view('myrequest', compact('heading', 'icon', 'name', 'data'));
    }
    public function myrequest_action($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Requests";
        $data = Leaves::with('remployee')->where('id', $id)->get();
        return view('myrequest_action', compact('heading', 'name', 'data'));
    }

    public function myrequest_update(Request $request, $id)
    {
        $status = $request->input('status');
        $updateData = $this->validate($request, [
            'status' => 'required',
            'reason' => 'required_if:status,5',
        ],
        [
            'reason.required_if' => 'The Reason field is required',
        ]);
        Leaves::whereId($id)->update($updateData);
        $batch = Leaves::find($id)->batch;
        Leaves::where('batch', $batch)->update(['status'=>$status]);
        return redirect('/myrequest')
            ->with('success', 'Congratulations, You have deleted a leave successfully');
    }
    public function myshift_details()
    {
        $heading = $this->head;
        $icon = "mdi mdi-timetable";
        $name = "Shift";
        $data = Usermaster::where('id', auth()->id())->get();
        return view('myshift_details', compact('heading', 'icon', 'name', 'data'));
    }

    public function myjobcard()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = 'My JobCard';
        $data = JobCard::where('employee', auth()->id())
                ->orderBy('id','desc')
                ->paginate($this->pageno);
        return view('myjobcard', compact('heading', 'icon', 'name', 'data'));
    }

    public function myjobcard_delete($id)
    {
        $data = JobCard::findOrFail($id);
        $status = $data->status;
        if($status == '3' ) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';
        }else{
            $data->delete();
            Work::where('jobcardid', $id)->delete();
            $msg = 'Congratulations, You have deleted a JobCard successfully';
            $msgType='warning';
        }
        return redirect('/myjobcard')
            ->with($msgType, $msg);
    }

    public function myworks($jobcardid)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = 'My Works';
        $jobcard = JobCard::find($jobcardid);
        $status = $jobcard->status;
        $data = Work::where('jobcardid', $jobcardid)
                ->orderBy('id','ASC')->get();

        if(count($data) >0){
            $aDatetime = $data[0]->starttime;
            $name.=' on '.Carbon::parse($aDatetime)->format('M d, Y');
            $aDate = Carbon::parse($aDatetime)->format('Y-m-d');
        }else{
            $aDate ='0000-00-00';
        }
        $log =  Userlog::select(
            DB::raw('MIN(CASE WHEN status = 1 THEN logtime END) AS firstlogin'),
            DB::raw('MAX(CASE WHEN status = 2 THEN logtime END) AS lastlogout'))
            ->where('employee',  auth()->id())->whereDate('logtime', $aDate)
            ->groupBy('employee')->get();
        $login = $logout = 0;
        if((count($log)) >0){
            $firstlogin =$log[0]->firstlogin;
            if($firstlogin){
                $login =  Carbon::parse($firstlogin)->format('Y-m-d h:i A');
            }
            $lastlogout =$log[0]->lastlogout;
            if($lastlogout){
                $logout = Carbon::parse($lastlogout)->format('Y-m-d h:i A');
            }
        }
        $array = Usershift::with('rshift')->where('eid',  auth()->id())
            ->orderBy('id', 'desc')->get();
        $starttime = $endtime = 0;
        if((count($array)) >0){
            $starttime = $array[0]->rshift->starttime;
            $endtime = $array[0]->rshift->endtime;
        }

//        $today = Carbon::today()->format('Y-m-d');  lastlogout
//        $shiftstarttime = $today.' '.$starttime;
//        $shiftendtime = $today.' '.$endtime;
        $shiftstarttime = $aDate.' '.$starttime;
        $shiftendtime = $aDate.' '.$endtime;
//        @dd($login.'---'.$logout);
         return view('myworks',
            compact('heading', 'icon', 'name', 'data', 'status','login',
                'logout','jobcardid', 'shiftstarttime','shiftendtime'));
    }

    public function mywork_view($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "My Work";
        $data = Work::where('id', $id)->get();
        $jobid = $data[0]->jobcardid;
        $status = JobCard::find($jobid)->status;
        return view('mywork_view',
            compact('heading', 'icon', 'name', 'data', 'status'));
    }

    public function mywork_add($jobcardid)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Work";
        $endtime = $login = $logout = 0;

        if($jobcardid>0){
            $jobdate = JobCard::find($jobcardid)->jobdate;
//            $endtime = Work::where('jobcardid', $jobcardid)->orderBy('endtime', 'desc')->value('endtime');

        }else{
            $jobdate = Carbon::now()->format('Y-m-d');
//            $endtime = Work::whereDate('endtime', $jobdate)->orderBy('endtime', 'desc')->value('endtime');
        }
        $endtime = Work::where('employee',  auth()->id())
                    ->whereDate('endtime', $jobdate)->orderBy('endtime', 'desc')->value('endtime');
        if(empty($endtime)){
            $firstcheck = 0;
        }else{
            $firstcheck = 1;
        }

        $log =  Userlog::select(
            DB::raw('MIN(CASE WHEN status = 1 THEN logtime END) AS firstlogin'),
            DB::raw('MAX(CASE WHEN status = 2 THEN logtime END) AS lastlogout'))
            ->where('employee',  auth()->id())->whereDate('logtime', $jobdate)
            ->groupBy('employee')->get();
        if((count($log)) >0){
            $login = $log[0]->firstlogin;
            $logout = $log[0]->lastlogout;
        }
        if($endtime ==0){
            if($login == 0){
                $array = Usershift::with('rshift')->where('eid',  auth()->id())
                    ->orderBy('id', 'desc')->get();
                $shifttime = $array[0]->rshift->starttime;
                $today = Carbon::today()->format('Y-m-d');
                $endtime = $today.' '.$shifttime;
            }else{
                $endtime =  $login;
            }
        }
//        dd($endtime);
        $activity = Activity::get(["id","activity"]);
        $client = Client::get(["id","client"]);
        $project = Project::where('status', '1')->get(["id","project"]);
        return view('mywork_add',
            compact('heading', 'icon', 'name', 'activity', 'client', 'project',
                'jobdate', 'login', 'logout','endtime', 'firstcheck'));
    }
    public function mywork_create(Request $request)
    {
        $timetaken = $request->input('timetaken');
        $starttime = $request->input('starttime');
        $workDate = Carbon::parse($starttime)->format('Y-m-d');

        $validatedData = $this->validate($request, [
            'employee' => 'nullable',
            'activity' => 'required',
            'client' => 'nullable',
            'type1' => 'nullable',
            'type2' => 'nullable',
            'type3' => 'nullable',
            'description' => 'required',
            'timetaken' => 'required|numeric|gt:0',
            'cost' => 'nullable',
            'starttime' => 'required',
            'endtime' => 'required|after:starttime',
        ]);
        $validatedData['employee'] = $myid = auth()->id();
        $hours = $timetaken / 60;

        $unit = DB::select("SELECT unitSalary($myid) as myunitsalary");
        $unitSalary = $unit[0]->myunitsalary;

        $validatedData['cost'] = $hours * $unitSalary;

        $jobcard = JobCard::where('employee', $myid)->whereDate('jobdate', $workDate)->first();

        if(!$jobcard){
            $jobcard = JobCard::create([
                'employee' => $myid,
                'jobdate' => $workDate,
                'status' => 1
            ]);

        }
        $validatedData['jobcardid'] = $jobcardid = $jobcard->id;

        Work::create($validatedData);
        return redirect('/myworks/'.$jobcardid)
            ->with('success', 'Congratulations, You have created a new JobCard successfully.');
    }

    public function mywork_delete($id)
    {
        $data = Work::findOrFail($id);
        $jobcardid = $data->jobcardid;
        $status = JobCard::find($jobcardid)->status;
        if($status == '3' ) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';
        }else{
            $data->delete();
            $msg = 'Congratulations, You have deleted a JobCard successfully';
            $msgType='warning';
        }
        return redirect('/myworks/'.$jobcardid)
            ->with($msgType, $msg);
    }

    public function mywork_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Work";
        $data = Work::where('id', $id)->get();
        $jobdate = Carbon::parse($data[0]->starttime)->format('Y-m-d');
        $activity = Activity::get(["id","activity"]);
        $client = Client::get(["id","client"]);
        $project = Project::where('status', '1')->get(["id","project"]);
        $currntProject = $data[0]->type1;
        $currntModule = $data[0]->type2;

        if($currntProject >0){
            $module = Module::where('product',$currntProject)->whereNull('parent')->
                        get(["modulename", 'id']);
        }else{
            $module = array();
        }
        if($currntModule >0){
            $submodule = Module::where('parent',$currntModule)->whereNotNull('parent')->
                            get(["modulename", 'id']);
        }else{
            $currntModule = '';
            $submodule = array();
        }
        $login = $logout = 0;
        $log =  Userlog::select(
            DB::raw('MIN(CASE WHEN status = 1 THEN logtime END) AS firstlogin'),
            DB::raw('MAX(CASE WHEN status = 2 THEN logtime END) AS lastlogout'))
            ->where('employee',  auth()->id())->whereDate('logtime', $jobdate)
            ->groupBy('employee')->get();
        if((count($log)) >0){
            $login = $log[0]->firstlogin;
            $logout = $log[0]->lastlogout;
        }
        return view('mywork_edit',
            compact('heading', 'icon', 'name', 'activity', 'client', 'project', 'data',
                'module', 'submodule', 'login', 'logout'));
    }

    public function mywork_update(Request $request, $id)
    {
        $timetaken = $request->input('timetaken');
        $oldtimetaken = $request->input('oldtimetaken');
        $jobcardid = $request->input('jobcardid');

        $validatedData = $this->validate($request, [
            'employee' => 'nullable',
            'activity' => 'required',
            'client' => 'nullable',
            'type1' => 'nullable',
            'type2' => 'nullable',
            'type3' => 'nullable',
            'description' => 'required',
            'timetaken' => 'required|numeric|gt:0',
            'cost' => 'nullable',
            'starttime' => 'required',
            'endtime' => 'required|after:starttime',
        ]);
        $validatedData['employee'] = $myid = auth()->id();
        if($timetaken != $oldtimetaken){
            $hours = $timetaken / 60;
            $unit = DB::select("SELECT unitSalary($myid) as myunitsalary");
            $unitSalary = $unit[0]->myunitsalary;
            $validatedData['cost'] = $hours * $unitSalary;
        }
        Work::whereId($id)->update($validatedData);

        return redirect('/myworks/'.$jobcardid)
            ->with('success', 'Congratulations, You have updated a JobCard successfully.');
    }
    public function myjobcard_update(Request $request, $id)
    {
        $validatedData = $this->validate($request, [
            'status' => 'required',
        ]);
        JobCard::whereId($id)->update($validatedData);
        return back()->with('success', 'Congratulations, You have updated a new JobCard successfully.');
    }

}
