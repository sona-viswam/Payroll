<?php

namespace App\Http\Controllers;

use App\Models\Module;
use App\Models\Project;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ModuleController extends Controller
{
    public $head = "MODULE";
    public $icon = "mdi mdi-view-module";

    public function module($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = Project::find($id)->project;
        $data = Module::where('product', $id)->whereNull('parent')->with('children')-> get();
        return view('module', compact('heading', 'icon', 'name', 'data', 'id'));
    }

    public function module_add($id)
    {
       $heading = $this->head;
       $icon = $this->icon;
       $name = "Add";
       $project = Project::get(["id","project"]);
       return view('module_add', compact('heading', 'icon', 'name', 'project', 'id'));
    }

    public function module_create(Request $request)
    {
        $validatedData = $this->validate($request, [
            'modulename' => 'required|unique:module,modulename,NULL,product,product,'.$request->product,
            'product' => 'required',
            'type' => 'required',
            'parent'=>'required_if:type,<>,null'
        ]);
        Module::create($validatedData);
        return back()->with('success', 'Congratulations, You have created a new Holiday successfully.');
    }

    public function module_edit($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit";
        $data = Module::where('id', $id)->get();
        $myproject = $data[0]->product;
        $project = Project::get(["id","project"]);
        $module = Module::where('product',$myproject)->
                            whereNull('parent')->
                            get(["modulename", 'id']);
        return view('module_edit', compact('heading', 'icon', 'name', 'project', 'data', 'module'));
    }

    public function module_update(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'modulename' => 'required|unique:module,modulename,NULL,product,product,'.$request->product.',id,id'.$id,
            'product' => 'required',
            'type' => 'required',
            'parent'=>'required_if:type,<>,null'
        ]);
        Module::whereId($id)->update($updateData);
        return back()->with('success', 'Congratulations, You have updated a Module successfully.');
    }

    public function module_delete($id)
    {
        $data= Module::findOrFail($id);
        $data->delete();
        return redirect('/module')
            ->with('success', 'Congratulations, You have deleted a Module successfully');

    }

    public function fetch_module(Request $request)
    {
        $data['module'] = Module::where('product', $request->input)
                            ->whereNull('parent')->where('type', '0')
                            ->get(["id", 'modulename']);
        return response()->json($data);
    }

    public function fetch_submodule(Request $request)
    {
        $data['module'] = Module::where('parent', $request->input)
                            ->whereNotNull('parent')->where('type', '1')
                            ->get(["id", 'modulename']);
        return response()->json($data);
    }
}
