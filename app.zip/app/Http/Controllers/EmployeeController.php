<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Models\Department;
use App\Models\Designation;
use App\Models\Salary;
use App\Models\Shift;
use App\Models\Userdesignation;
use App\Models\Userlog;
use App\Models\Usermaster;
use App\Models\Usershift;
use Dotenv\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Session;
use File;


class EmployeeController extends Controller
{
    public $head = "EMPLOYEE";
    public $icon = "mdi mdi-account-multiple";

    public function employees()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Employee List";
        $data = Usermaster::where('status', '1')->where('role', 'user')
            ->select('id', 'firstname', 'secondname', 'email', 'hiredate', 'photo')
            ->paginate($this->pageno);
        return view('employees', compact('heading', 'icon', 'name', 'data'));
    }

    public function employees_add()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Employee";
        $countries = Country::get(["name","id"]);
        return view('employees_add', compact('heading', 'icon', 'name', 'countries'));
    }

    public function createEmployee(Request $request)
    {
        $validatedData = $this->validate($request, [
            'firstname' => 'required',
            'secondname' => 'nullable',
            'username'=>'required|min:6|unique:usermaster',
            'password'=>'required|min:6',
            'email' => 'required|email|unique:usermaster',
            'gender' => 'required',
            'dob' => 'nullable',
            'qualification' => 'nullable',
            'permanentaddress' => 'nullable',
            'temporaryaddress' => 'nullable',
            'city' => 'nullable',
            'country' => 'nullable',
            'pin' => 'nullable',
            'phone' => 'nullable',
            'mobile' => 'nullable',
            'photo' => 'nullable',
            'identityno' => 'nullable',
            'identityimage' => 'nullable',
            'hiredate' => 'date|required',
            'lastdate' => 'nullable',
            'status' => 'required',
            'photo' => 'nullable|file|mimes:jpg,jpeg,bmp,png',
            'identityimage' => 'nullable|file|mimes:jpg,jpeg,bmp,png',
        ]);
        if ($request->has('photo')) {
            $fileName = time().'.'.$request->photo->extension();
            $request->photo->move(public_path('upload'), $fileName);
            $validatedData['photo'] = $fileName;
        }
        if ($request->has('identityimage')) {
            $fileName = time().'_im.'.$request->identityimage->extension();
            $request->identityimage->move(public_path('upload'), $fileName);
            $validatedData['identityimage'] = $fileName;
        }
        $validatedData['password'] = bcrypt($validatedData['password']);
        $user = Usermaster::create($validatedData);
        $userid = $user ->id;
//        $request->session()->put('employee', $userid);
        Session(['employee' => $userid]);
        return redirect()->route('addEmployeedesignation',['id'=>$userid]);
      }

    public function editEmployee($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Employee";
        $countries = Country::get(["name","id"]);
        $data = Usermaster::where('id', $id)->get();
        Session(['employee' => $id]);
        return view('employees_edit', compact('heading', 'icon', 'name', 'countries','data'));
    }

    public function updateEmployee(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'firstname' => 'required|min:4',
            'secondname' => 'nullable',
            'username' => 'required|min:6|unique:usermaster,username,' . $id,
            'password'=>'required|min:6',
            'email' => 'required|email|unique:usermaster,email,' . $id,
            'gender' => 'required',
            'dob' => 'nullable',
            'qualification' => 'nullable',
            'permanentaddress' => 'nullable',
            'temporaryaddress' => 'nullable',
            'city' => 'nullable',
            'country' => 'nullable',
            'pin' => 'nullable',
            'phone' => 'nullable',
            'mobile' => 'nullable',
            'photo' => 'nullable',
            'identityno' => 'nullable',
            'identityimage' => 'nullable',
            'hiredate' => 'date|required',
            'lastdate' => 'nullable',
            'status' => 'required',
            'photo' => 'nullable|file|mimes:jpg,jpeg,bmp,png',
            'identityimage' => 'nullable|file|mimes:jpg,jpeg,bmp,png',
            'bankname' => 'nullable',
            'accountno' => 'nullable',

        ]);
        $password = $request->input('password');
        $oldpassword = $request->input('oldpassword');
        if($oldpassword !== $password){
            $updateData['password'] = bcrypt($updateData['password']);
        }
        if ($request->has('photo')) {
            $fileName = time().'.'.$request->photo->extension();
            $request->photo->move(public_path('upload'), $fileName);
            $updateData['photo'] = $fileName;
            $old_photo = $request->input('old_photo');
            if($old_photo){
                $image_path = public_path('upload').'/'.$old_photo;
                if (file_exists($image_path)) {
                     File::delete($image_path);
                }
            }
        }
        if ($request->has('identityimage')) {
            $fileName = time().'_im.'.$request->identityimage->extension();
            $request->identityimage->move(public_path('upload'), $fileName);
            $updateData['identityimage'] = $fileName;
            $old_identityimage = $request->input('old_identityimage');
            if($old_identityimage){
                $image_path = public_path('upload').'/'.$old_identityimage;
                if (file_exists($image_path)) {
                    File::delete($image_path);
                }
            }
        }
        Usermaster::whereId($id)->update($updateData);
        Session(['employee' => $id]);
        return redirect()->route('employeedesignation',['id'=>$id]);

    }
    public function addEmployeedesignation($userid)
    {
        $heading = $this->head;
        $name = "Add Employee Details";
        $icon = $this->icon;
        $department = Department::get(["id","department"]);
        $designation = Designation::get(["id","designation"]);
        return view('employee_designation_add', compact('heading', 'icon', 'name', 'department', 'designation', 'userid'));
    }

    public function createEmployeedesignation(Request $request)
    {
        $validatedData = $this->validate($request, [
            'employee' => 'required',
            'organization' => 'nullable',
            'department' => 'required',
            'designation' => 'required',
            'fromdate' => 'date|required',
        ]);
        Userdesignation::create($validatedData);
        return redirect()->route('employeeShift');
    }

    public function employeedesignation($userid)
    {
        if(Userdesignation::where('employee', '=', $userid)->exists()) {
            return redirect()->route('editEmployeedesignation',['id'=>$userid]);
        }else{
            return redirect()->route('addEmployeedesignation',['id'=>$userid]);
        }
    }


    public function editEmployeedesignation($userid)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Employee Designation";
        $department = Department::get(["id","department"]);
        $designation = Designation::get(["id","designation"]);
        $data = Userdesignation::where('employee','=', $userid)
            ->orderBy('id','DESC')->first();
        return view('employee_designation_edit', compact('heading', 'icon', 'name', 'department', 'designation', 'userid', 'data'));
    }

    public function upddateEmployeedesignation(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'employee' => 'required',
            'organization' => 'nullable',
            'department' => 'required',
            'designation' => 'required',
            'fromdate' => 'date|required',
        ]);
        if( ($request->department<>$request->olddepartment) || ($request->designation<>$request->olddesignation))
        {
            Userdesignation::create($updateData);
        }else{
            Userdesignation::whereId($id)->update($updateData);
        }
        return redirect()->route('employeeShift');
    }

    public function employeeShift()
    {
        $userid = Session::get('employee');
        if(Usershift::where('eid', '=', $userid)->exists()) {
            return redirect()->route('editEmployeeShift',['id'=>$userid]);
        }else{
            return redirect()->route('addEmployeeShift',['id'=>$userid]);
        }
    }
    public function addEmployeeShift()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Employee Shift";
        $userid = Session::get('employee');
        $shift = Shift::get(["id","shiftname"]);
        return view('employee_shift_add', compact('heading', 'icon', 'name', 'userid', 'shift'));
    }

    public function createEmployeeShift(Request $request)
    {
        $validatedData = $this->validate($request, [
            'eid' => 'required',
            'sid' => 'required',
        ]);
        Usershift::create($validatedData);
        return redirect()->route('employeeSalary');
    }

    public function editEmployeeShift()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Employee Shift";
        $userid = Session::get('employee');
        $data = Usershift::where('eid','=', $userid)
            ->orderBy('id','DESC')->first();
        $shift = Shift::get(["id","shiftname"]);
        return view('employee_shift_edit', compact('heading', 'icon', 'name', 'userid','data', 'shift'));
    }

    public function updateEmployeeShift(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'eid' => 'required',
            'sid' => 'required',
        ]);
        if($request->sid === $request->oldshiftid)
        {
            Usershift::whereId($id)->update($updateData);
        }else{
            Usershift::create($updateData);
        }
        return redirect()->route('employeeSalary');
    }

    public function employeeSalary()
    {
        $userid = Session::get('employee');
        if(Salary::where('employee', '=', $userid)->exists()) {
            return redirect()->route('editEmployeesalary');
        }else{
            return redirect()->route('addEmployeesalary');
        }
    }

    public function addEmployeesalary()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Add Employee Salary";
        $userid = Session::get('employee');
        return view('employee_salary_add', compact('heading', 'icon', 'name', 'userid'));
    }

    public function createEmployeesalary(Request $request)
    {
        $validatedData = $this->validate($request, [
            'employee' => 'required',
            'basicsalary' => 'required',
            'fromdate' => 'date|required',
        ]);
        Salary::create($validatedData);
        $userid = Session::get('employee');
        return redirect()->route('viewEmployee', ['id'=>$userid]);
    }

    public function editEmployeesalary()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Edit Employee Salary";
        $userid = Session::get('employee');
        $data = Salary::where('employee','=', $userid)
            ->orderBy('id','DESC')->first();
        return view('employee_salary_edit', compact('heading', 'icon', 'name', 'userid','data'));
    }

    public function updateEmployeesalary(Request $request, $id)
    {
        $updateData = $this->validate($request, [
            'employee' => 'required',
            'basicsalary' => 'required',
            'fromdate' => 'date|required',
        ]);
        if($request->basicsalary === $request->oldbasicsalary)
        {
            Salary::whereId($id)->update($updateData);
        }else{
            Salary::create($updateData);
        }
        $userid = Session::get('employee');
        return redirect()->route('viewEmployee', ['id'=>$userid]);
    }

    public function viewEmployee($id)
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Employee Details";
        $data = Usermaster::where('id', $id)->get();
//        dd($data->toArray());
        return view('employee_view', compact('heading', 'icon', 'name', 'data'));
    }


    public function employeesSuspend()
    {
        $heading = $this->head;
        $icon = $this->icon;
        $name = "Suspend Employee List";
        $data = Usermaster::where('status', '0')
            ->select('id', 'firstname', 'secondname', 'email', 'hiredate', 'lastdate')
            ->paginate($this->pageno);
        return view('employees_suspend', compact('heading', 'icon', 'name', 'data'));
    }

    public function employees_delete($id)
    {
        if( Userlog::where('employee', '=', $id)->exists()) {
            $msg = 'Sorry, You cannot delete this record because it is already in use';
            $msgType='error';
        }else{
            $data = Usermaster::findOrFail($id);
            $data->delete();
            Userdesignation::where('employee', $id)->delete();
            Usershift::where('eid', $id)->delete();
            Salary::where('employee', $id)->delete();
            $msg = 'Congratulations, You have deleted a Employee successfully';
            $msgType='warning';
        }
        return redirect('/employees')
            ->with($msgType, $msg);
    }
}
