<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shiftstars extends Model
{
    protected $table = "shiftstars";

    use HasFactory;

    protected $fillable = [
        'sid', 'startype', 'lstarmin', 'lstarpoints',
    ];

}
