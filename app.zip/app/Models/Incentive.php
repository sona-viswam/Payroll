<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Incentive extends Model
{
    protected $table = "incentive";

    use HasFactory;

    protected $fillable = [
        'employee', 'amount', 'title', 'idate'
    ];

    public function remployee(){
        return $this->belongsTo(Usermaster::class, 'employee');
    }
}
