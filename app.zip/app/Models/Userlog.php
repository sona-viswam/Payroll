<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Userlog extends Model
{
    protected $table = "userlog";

    use HasFactory;

    protected $fillable = [
        'employee',
        'logtime',
        'status',
        'source',
    ];

    public function remployee(){
        return $this->belongsTo(Usermaster::class, 'employee');
    }
}
