<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobCard extends Model
{
    use HasFactory;

    protected $table = "jobcard";

    protected $fillable = [
        'employee','jobdate','status', 'source',
    ];
    public function remployee(){
        return $this->belongsTo(Usermaster::class, 'employee');
    }

}
