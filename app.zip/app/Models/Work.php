<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Work extends Model
{
    use HasFactory;

    protected $table = "work";

    protected $fillable = [
        'employee','jobcardid','activity','client','type1','type2','type3','description','timetaken',
        'cost','starttime','endtime','status',
    ];
    public function rjobcard(){
        return $this->belongsTo(JobCard::class, 'jobcardid');
    }
    public function ractivity(){
        return $this->belongsTo(Activity::class, 'activity');
    }
    public function jemployee(){
        return $this->belongsTo(Usermaster::class, 'employee');
    }

    public function rclient(){
        return $this->belongsTo(Client::class, 'client');
    }
    public function rproject(){
        return $this->belongsTo(Project::class, 'type1');
    }
    public function rmodule(){
        return $this->belongsTo(Module::class, 'type2');
    }
    public function rsubmodule(){
        return $this->belongsTo(Module::class, 'type3');
    }
}
