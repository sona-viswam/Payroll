<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Salaryrecordtmp extends Model
{
    protected $table = "salaryrecord_tmp";

    use HasFactory;

    protected $fillable = [
        'employee', 'salary',
    ];

    public function remployee()
    {
        return $this->belongsTo(Usermaster::class, 'employee');
    }

}
