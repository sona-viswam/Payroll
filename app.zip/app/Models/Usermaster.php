<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Usermaster extends Model
{
    use HasFactory;

    protected $table = "usermaster";

    public $fillable = [
        'firstname',
        'secondname',
        'username',
        'password',
        'gender',
        'dob',
        'qualification',
        'email',
        'permanentaddress',
        'temporaryaddress',
        'city',
        'country',
        'pin',
        'phone',
        'mobile',
        'photo',
        'identityno',
        'identityimage',
        'hiredate',
        'lastdate',
        'status',
        'bankname',
        'accountno',
    ];
    public function getFullNameAttribute()
    {
        return ucfirst($this->firstname) . ' ' . ucfirst($this->secondname);
    }

    public function rcountry(){
        return $this->belongsTo(Country::class, 'country');
    }
    public function designations()
    {
        return $this->belongsToMany(Designation::class, 'userdesignation', 'employee', 'designation');
    }
    public function departments()
    {
        return $this->belongsToMany(Department::class, 'userdesignation', 'employee', 'department');
    }
    public function salarys()
    {
        return $this->hasMany(Salary::class, 'employee', 'id');
    }
    public function shifts()
    {
        return $this->belongsToMany(Shift::class, 'usershift', 'eid', 'sid');
    }
}
