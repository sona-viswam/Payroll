<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Module extends Model
{
    protected $table = "module";

    use HasFactory;

    protected $fillable = [
        'modulename', 'product', 'type', 'parent'
    ];

    public function rparent(){
        return $this->belongsTo(self::class, 'parent');
    }

    public function children(){
        return $this->hasMany(self::class, 'parent');
    }
}
