<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Leaves extends Model
{
    use HasFactory;

    protected $fillable = [
        'ldate',
        'ldate2',
        'type',
        'employee',
        'bemployee',
        'daytype',
        'subject',
        'content',
        'status',
        'batch',
    ];

    public function remployee(){
        return $this->belongsTo(Usermaster::class, 'employee');
    }

    public function rbemployee(){
        return $this->belongsTo(Usermaster::class, 'bemployee');
    }
}
