<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shift extends Model
{
    protected $table = "shift";

    use HasFactory;

    protected $fillable = [
        'shiftname', 'starttime', 'endtime', 'breakstart', 'breakend'
    ];

//    public function rshiftstars()
//    {
//        return $this->belongsTo(Shiftstars::class, 'sid', 'id');
//    }

    public function stars()
    {
        return $this->hasMany(Shiftstars::class, 'sid', 'id');
    }

}
