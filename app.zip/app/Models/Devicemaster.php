<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Devicemaster extends Model
{
    use HasFactory;

    protected $table = "devicemaster";


    protected $fillable = [
        'name', 'serailno', 'ip', 'port', 'status', 'type'
    ];
}
