<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Usershift extends Model
{
    protected $table = "usershift";

    use HasFactory;

    protected $fillable = [
        'eid', 'sid',
    ];

    public function rshift(){
        return $this->belongsTo(Shift::class, 'sid', 'id');
    }



}
