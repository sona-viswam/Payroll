<?php

namespace App\Rules;

use App\Models\Leaves;
use Illuminate\Contracts\Validation\Rule;

class CheckEmployeeLeaveRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    protected $ldate;
    public function __construct($ldate)
    {
        $this->ldate = $ldate;
    }


    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $isExist = Leaves::where('bemployee', $value)->where('ldate', $this->ldate)->exists();
        if ($isExist) {
//            dd('Record is available.');
            return false;
        }else{
//            dd('Record is not available.');
            return true;
        }

    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'Sorry, You cannot take leave beacause You are backup employee on same day.';
    }
}
