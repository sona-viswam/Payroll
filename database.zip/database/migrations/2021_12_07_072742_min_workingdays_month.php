<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class MinWorkingdaysMonth extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION min_workingdays_month()
        RETURNS int(11)
        BEGIN
           DECLARE minDay INT DEFAULT 0;
           SELECT VALUE FROM configuration WHERE caption = 'min_working_days' INTO minDay;
           RETURN minDay;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS min_workingdays_month');
    }
}
