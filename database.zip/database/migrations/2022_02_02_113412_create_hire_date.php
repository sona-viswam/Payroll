<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHireDate extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */

    public function up()
    {
        DB::unprepared("CREATE FUNCTION `hireDate`()
        RETURNS DATE
        BEGIN
            DECLARE hdate DATE;
            SELECT  hiredate FROM usermaster WHERE id = userid INTO hdate;
            RETURN IFNULL(hdate, CURDATE());
        END");
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS hireDate');
    }
}
