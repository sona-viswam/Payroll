<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class InsertSalary extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE PROCEDURE `SP_insertSalary`()
        BEGIN
            INSERT INTO salaryrecord (employee, basic_salary, holiday, working_days,
				  tot_cl, tot_el, used_cl, used_el, cf_cl, cf_el, absent,
				  total_leave,  blackstar, blackstar_lop, leave_lop, total_lop_days, lop_amount, salary,
				  incentive, deductions, net_salary,
				  salary_date, created_at)
            SELECT employee, basic_salary, holiday, working_days,
				  tot_cl, tot_el, used_cl, used_el, cf_cl, cf_el, absent,
				  total_leave,  blackstar, blackstar_lop, leave_lop, total_lop_days, lop_amount, salary,
				  incentive, deductions, net_salary,
				  salary_date, NOW() FROM salaryrecord_tmp;
            DELETE FROM salaryrecord_tmp;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS SP_insertSalary');
    }
}
