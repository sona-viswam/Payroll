<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDeduction extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `deduction`(`userid` int,
            `startdate` DATE,
            `enddate` DATE)
        RETURNS decimal(10,2)
        BEGIN
            DECLARE totDeduction DECIMAL(10,2) DEFAULT 0.0;
            SELECT SUM(amount) INTO totDeduction FROM deduction WHERE employee = userid AND (ddate BETWEEN startdate and enddate);
            RETURN ifnull(totDeduction,0);
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS deduction');
    }
}
