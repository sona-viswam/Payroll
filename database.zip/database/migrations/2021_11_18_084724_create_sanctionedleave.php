<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSanctionedleave extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `sanctionedleave`(`userid` INT,
            `start_date` DATE,
            `end_date` DATE)
        RETURNS INT(11)
        BEGIN
            DECLARE ldays INT DEFAULT 0;
            SELECT SUM(daytype) INTO ldays FROM leaves WHERE employee = userid AND STATUS = '1' AND (ldate BETWEEN start_date and end_date);
            RETURN ldays;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS sanctionedleave');
    }
}
