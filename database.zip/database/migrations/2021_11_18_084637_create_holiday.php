<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHoliday extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `holiday`(`startdate` DATE,
            `enddate` DATE)
        RETURNS int(11)
        BEGIN
            DECLARE holidayCount INT DEFAULT 0;
            SELECT count(id) INTO holidayCount FROM holiday WHERE hdate BETWEEN startdate AND enddate;
            RETURN holidayCount;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS holiday');
    }
}
