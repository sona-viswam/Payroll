<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBasicsalary extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `basicsalary`(`userid` INT)
        RETURNS INT(11)
        BEGIN
            DECLARE basicSalary INT DEFAULT 0;
            SELECT salary.basicsalary INTO basicSalary FROM salary WHERE employee = userid ORDER BY id DESC LIMIT 1 ;
            RETURN basicSalary;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS basicsalary');
    }
}
