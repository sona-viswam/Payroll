<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCalcstar extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `calcstar`(
            `userid` INT,
            `typeio` int,
            `logdate` DATE,
            `in_out_time` time
            )
        RETURNS int(11)
        BEGIN
            DECLARE totalstar INT DEFAULT 0;
            DECLARE exit_loop INT DEFAULT FALSE;
            DECLARE checkVal INT DEFAULT 0;

            DECLARE calcst CURSOR FOR
                SELECT MAX(lstarpoints) totalstar FROM shiftstars ss
                INNER JOIN shift s ON s.id=ss.sid AND ss.startype=typeio
                INNER JOIN usershift u ON u.sid=s.id
                WHERE u.eid=userid AND
                ( ((TIME_TO_SEC(TIMEDIFF(in_out_time,s.starttime))/60)>=ss.lstarmin AND ss.startype=0)
                or ((  TIME_TO_SEC(TIMEDIFF(s.endtime,in_out_time))/60)>ss.lstarmin AND ss.startype=1)  );

            DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = TRUE;
            OPEN calcst;
            calc_loop: LOOP
                FETCH  calcst INTO totalstar;
                IF totalstar IS NULL OR exit_loop THEN
                    CLOSE calcst;
                    LEAVE calc_loop;
                END IF;


            IF ((typeio = 0 AND totalstar >=11) OR (typeio= 1 AND totalstar >= 3)) THEN
                SELECT EXISTS(SELECT 1 FROM leaves  WHERE employee = userid AND ldate = logdate)  INTO checkVal;
                IF(checkVal <1) THEN
                    SET totalstar = halfdaystar();
                ELSE
                    SET totalstar = 0;
                END IF;
            END IF;
            END LOOP calc_loop;
            RETURN ifnull(totalstar,0);
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS calcstar');
    }
}
