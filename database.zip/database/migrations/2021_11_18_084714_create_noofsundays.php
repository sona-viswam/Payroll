<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNoofsundays extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `noofsundays`(`startdate` DATE,
            `enddate` DATE)
        RETURNS INT(11)
        BEGIN
            DECLARE numberOfSundays INT DEFAULT 0;
            -- SET enddate = DATE_ADD(enddate, INTERVAL -1 DAY);
            SET enddate = DATE_ADD(enddate, INTERVAL 0 day);
            WHILE (startdate <= enddate) DO
                IF DAYNAME(startdate) = 'Sunday' THEN
                    SET numberOfSundays = numberOfSundays + 1;
                END IF;
                SET startdate = DATE_ADD(startdate, INTERVAL 1 day);
            END WHILE;
            RETURN numberOfSundays;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS noofsundays');
    }
}
