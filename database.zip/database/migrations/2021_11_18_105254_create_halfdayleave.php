<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHalfdayleave extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `halfdayleave`(	`userid` INT,
            `start_date` DATE,
            `end_date` DATE)
        RETURNS decimal(10,2)
        BEGIN
            DECLARE tot_halfday DECIMAL(10,2) DEFAULT 0.0;
            SELECT SUM(daytype) INTO tot_halfday FROM leaves WHERE employee = userid AND daytype = '0.5' AND  (ldate BETWEEN start_date AND end_date);
            RETURN ifnull(tot_halfday,0.0);
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS halfdayleave');
    }
}
