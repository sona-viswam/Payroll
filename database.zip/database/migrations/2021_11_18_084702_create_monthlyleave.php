<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMonthlyleave extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `monthlyleave`(`userid` INT)
        RETURNS INT(11)
        BEGIN
            DECLARE hdate DATE;
            DECLARE today DATE DEFAULT current_date();
            DECLARE emptype INT DEFAULT 0;
            DECLARE monDIFF INT DEFAULT 0;
            DECLARE monthleave INT DEFAULT 0;
            DECLARE mleave INT DEFAULT 0;
            SELECT value  FROM configuration WHERE caption = 'monthly_leave' INTO monthleave;
            SELECT employee_type, hiredate FROM usermaster WHERE id = userid INTO emptype, hdate;
            IF (hdate ='0000-00-00') THEN
                SET hdate = today;
            END IF;
            SELECT TIMESTAMPDIFF(MONTH, hdate, today) INTO monDIFF;
            IF monDIFF > 4 THEN
                SET mleave = monthleave;
           ELSEIF (monDIFF <= 4 AND monDIFF > 3) THEN
                SET mleave = monthleave * 4;
            ELSE
                SET mleave = 0;
            END IF;
           RETURN mleave;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS monthlyleave');
    }
}
