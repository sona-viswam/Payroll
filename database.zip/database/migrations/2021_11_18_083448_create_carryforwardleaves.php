<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCarryforwardleaves extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `carryforwardleaves`(`userid` INT,
            `amonth` INT,
            `ayear` INT)
        RETURNS int(11)
        BEGIN
            DECLARE firstyear INT DEFAULT 0;
            DECLARE secondyear INT DEFAULT 0;
            DECLARE cleave INT DEFAULT 0;
            DECLARE startdate DATE;
            DECLARE enddate DATE;

            IF (amonth <> 4) THEN
                IF (amonth > 4) THEN
                    SET firstyear = ayear;
                    SET secondyear = ayear + 1;
                ELSE
                    SET firstyear = ayear - 1;
                    SET secondyear = ayear;
                END IF;
                SET startdate = CONCAT(firstyear,'-04-01');
                SET enddate = CONCAT(secondyear,'-03-31');
                SELECT SUM(monthly_allowed_leave) - SUM(used_casualleave) FROM salaryrecord
                WHERE employee = userid AND (salary_date BETWEEN startdate AND enddate) GROUP BY employee INTO cleave;
            END IF;
           RETURN cleave;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('carryforwardleaves');
    }
}
