<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHalfdaystar extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `halfdaystar`()
        RETURNS int(11)
        BEGIN
           DECLARE countStar INT DEFAULT 0;
           SELECT VALUE FROM configuration WHERE caption = 'halfday' INTO countStar;
           RETURN countStar;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS halfdaystar');
    }
}
