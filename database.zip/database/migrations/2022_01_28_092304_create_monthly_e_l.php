<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMonthlyEL extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `monthlyEL`(`userid` INT)
        RETURNS INT(11)
        BEGIN
            DECLARE monDIFF INT DEFAULT 0;
            DECLARE monthEl INT DEFAULT 0;
            DECLARE el INT DEFAULT 0;
            SELECT SUM(VALUE) INTO monthEl FROM configuration WHERE caption = 'EL';
            SET monDIFF = monthDifference(userid);
            IF monDIFF > 4 THEN
                SET el = monthEl;
            ELSEIF (monDIFF <= 4 AND monDIFF > 3) THEN
                SET el = monthEl * 4;
            ELSE
                SET el = 0;
            END IF;
           RETURN el;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS monthlyEL');
    }
}
