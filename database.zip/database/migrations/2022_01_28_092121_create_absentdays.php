<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAbsentdays extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `absentdays`()
        RETURNS INT(11)
        BEGIN
            DECLARE absentVal INT DEFAULT 0;
            SELECT VALUE INTO absentVal FROM configuration WHERE caption = 'absent';
            RETURN ifnull(absentVal,0);
        END");
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS absentdays');
    }
}
