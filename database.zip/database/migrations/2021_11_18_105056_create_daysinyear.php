<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDaysinyear extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `daysinyear`(`ayear` INT)
        RETURNS int(11)
        BEGIN
           DECLARE NofDays INT DEFAULT 0;
           SELECT 365 + IFNULL(CASE WHEN ayear%400=0 THEN 1
                     WHEN ayear%4=0 THEN 1
                     WHEN ayear%100=0 THEN 0
                     END,0) INTO NofDays;
           RETURN NofDays;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS daysinyear');
    }
}
