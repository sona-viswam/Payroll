<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWorkeddays extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `workeddays`(`userid` INT,
            `start_date` DATE,
            `end_date` DATE)
        RETURNS INT(11)
        BEGIN
            DECLARE wdays INT DEFAULT 0;
            SELECT COUNT(*) FROM (
                SELECT employee, DATE(logtime) AS mydate FROM userlog
                WHERE employee = userid AND (DATE(logtime) BETWEEN start_date AND end_date) GROUP BY employee, mydate)
                AS X INTO wdays;
            RETURN wdays;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS workeddays');
    }
}
