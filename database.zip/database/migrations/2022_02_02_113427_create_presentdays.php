<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePresentdays extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */

    public function up()
    {
        DB::unprepared("CREATE FUNCTION `presentdays`()
        RETURNS INT(11)
        BEGIN
            DECLARE present INT DEFAULT 0;
            DECLARE hdate DATE;
				SET hdate = hireDate(userid);
				SELECT DATEDIFF(end_date, hdate) +1  INTO present;
            RETURN IFNULL(present, 0);
        END");
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS presentdays');
    }
}
