<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIncentive extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `incentive`(`userid` int,
            `startdate` DATE,
            `enddate` DATE)
        RETURNS decimal(10,2)
        BEGIN
            DECLARE totIncentive DECIMAL(10,2) DEFAULT 0.0;
            SELECT SUM(amount) INTO totIncentive FROM incentive WHERE employee = userid AND (idate BETWEEN startdate and enddate);
            RETURN ifnull(totIncentive,0);
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS incentive');
    }
}
