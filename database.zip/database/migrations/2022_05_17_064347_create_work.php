<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWork extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('work', function (Blueprint $table) {
            $table->id();
            $table->integer('employee');
            $table->integer('jobcardid');
            $table->integer('activity');
            $table->integer('client')->nullable();
            $table->integer('type1')->nullable();
            $table->integer('type2')->nullable();
            $table->integer('type3')->nullable();
            $table->string('description');
            $table->integer('timetaken');
            $table->double('cost', 10, 2);
            $table->dateTime('starttime', $precision = 0);
            $table->dateTime('endtime', $precision = 0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('work');
    }
}
