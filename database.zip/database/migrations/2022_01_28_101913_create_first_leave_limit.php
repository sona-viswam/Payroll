<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFirstLeaveLimit extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `first_leave_limit`()
        RETURNS INT(11)
        BEGIN
            DECLARE mlimit INT DEFAULT 0;
            SELECT value FROM configuration WHERE caption = 'first_leave_limit' INTO mlimit;
            RETURN mlimit;
        END");
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS first_leave_limit');
    }
}
