<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMonthlyCL extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `monthlyCL`(`userid` INT)
        RETURNS INT(11)
        BEGIN
                    DECLARE monDIFF INT DEFAULT 0;
                    DECLARE monthCl INT DEFAULT 0;
                    DECLARE cl INT DEFAULT 0;
                    SELECT VALUE INTO monthCl FROM configuration WHERE caption = 'CL';
                    SET monDIFF = monthDifference(userid);

                    IF monDIFF > 4 THEN
                        SET cl = monthCl;
                    ELSEIF (monDIFF <= 4 AND monDIFF > 3) THEN
                        SET cl = monthCl * 4;
                    ELSE
                        SET cl = 0;
                    END IF;
                   RETURN cl;
        END");
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS monthlyCL');
    }
}
