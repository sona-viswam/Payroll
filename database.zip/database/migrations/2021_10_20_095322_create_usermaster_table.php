<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsermasterTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usermaster', function (Blueprint $table) {

            $table->increments('id');
            $table->string('firstname');
            $table->string('secondname');
            $table->string('username','50')->unique();
            $table->string('password');
            $table->enum('gender', ['1', '2', '3']);
            $table->date('dob')->nullable();
            $table->string('qualification')->nullable();
            $table->string('permanentaddress')->nullable();
            $table->string('city')->nullable();
            $table->integer('country');
            $table->integer('pin')->nullable();
            $table->string('phone')->nullable();
            $table->string('temporaryaddress')->nullable();
            $table->string('mobile')->nullable();
            $table->string('email', '64')->unique();
            $table->date('hiredate');
            $table->date('lastdate')->nullable();
            $table->string('photo')->nullable();
            $table->string('identityno')->nullable();
            $table->string('identityimage')->nullable();
            $table->enum('role', ['user','admin'])->default('user');
            $table->integer('organization')->default('1');
            $table->string('resetcode')->nullable();
            $table->integer('createduser')->nullable();
            $table->integer('modifieduser')->nullable();
            $table->enum('status', ['1', '0']);
            $table->string('bankname')->nullable();
            $table->string('accountno')->nullable();
            $table->timestamps();
        });

        Artisan::call('db:seed', [
            '--class' => 'UsermasterSeeder',
            '--force' => true // <--- add this line
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usermaster');
    }
}
