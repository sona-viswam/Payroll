<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMonthDifference extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `monthDifference`()
        RETURNS INT(11)
BEGIN
            DECLARE hdate DATE;
            DECLARE today DATE DEFAULT current_date();
            DECLARE monDIFF INT DEFAULT 0;

            SELECT  hiredate FROM usermaster WHERE id = userid INTO hdate;
            IF (hdate ='0000-00-00') THEN
                SET hdate = today;
            END IF;
            SELECT TIMESTAMPDIFF(MONTH, hdate, today) INTO monDIFF;
			   RETURN IFNULL(monDIFF,0);

END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS monthDifference');
    }
}
