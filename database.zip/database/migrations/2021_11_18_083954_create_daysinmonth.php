<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDaysinmonth extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE FUNCTION `daysinmonth`(`startdate` DATE)
        RETURNS int(11)
        BEGIN
            DECLARE NofDays INT DEFAULT 0;
            SELECT day(LAST_DAY(startdate)) INTO NofDays;
            RETURN NofDays;
        END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS daysinmonth');
    }
}
