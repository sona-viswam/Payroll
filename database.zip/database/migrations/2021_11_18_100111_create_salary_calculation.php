<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSalaryCalculation extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared("CREATE PROCEDURE `SP_salaryCalculation`(IN amonth INT,
            IN ayear INT)

BEGIN
            DECLARE fl, ll, md  Date;
            DECLARE emp, lstar, estar INT;
            DECLARE exit_loop INT DEFAULT FALSE;

            DECLARE start_date DATE DEFAULT CONCAT(ayear,'-', amonth,'-01');
            DECLARE end_date DATE DEFAULT date(LAST_DAY(start_date));

            DECLARE no_of_days_in_year INT DEFAULT daysinyear (ayear);
            DECLARE no_of_days_in_month INT DEFAULT daysinmonth (start_date);
            DECLARE no_holidays INT DEFAULT holiday(start_date, end_date);
            DECLARE no_sundays INT DEFAULT noofsundays(start_date, end_date);
            DECLARE no_workingdays_per_month INT DEFAULT no_of_days_in_month - (no_holidays + no_sundays);
            DECLARE min_workingdaysmonth INT DEFAULT min_workingdays_month();
            DECLARE incents DECIMAL(10,2) DEFAULT 0.0;
            DECLARE deduct DECIMAL(10,2) DEFAULT 0.0;
            DECLARE llimit INT DEFAULT first_leave_limit();

            DECLARE basic_salary DECIMAL(10,2) DEFAULT 0.0;
            DECLARE tot_salary_per_annum DECIMAL(10,2) DEFAULT 0.0;
            DECLARE per_day_salary DECIMAL(10,2) DEFAULT 0.0;

        		DECLARE leavestr VARCHAR(255);
       		DECLARE carryforwardstr VARCHAR(255) DEFAULT '';
				DECLARE monthly_cl DECIMAL(5,2) DEFAULT 0.0;
				DECLARE monthly_el DECIMAL(5,2) DEFAULT 0.0;
            DECLARE cf_cl DECIMAL(5,2) DEFAULT 0.0;
            DECLARE cf_el DECIMAL(5,2) DEFAULT 0.0;
            DECLARE total_cl DECIMAL(5,2) DEFAULT 0.0;
            DECLARE total_el DECIMAL(5,2) DEFAULT 0.0;
          	DECLARE mysanctioned_cl DECIMAL(5,2) DEFAULT 0.0;
           	DECLARE mysanctioned_el DECIMAL(5,2) DEFAULT 0.0;
           	DECLARE used_cl DECIMAL(5,2) DEFAULT 0.0;
          	DECLARE used_el DECIMAL(5,2) DEFAULT 0.0;
          	DECLARE balancce_cl DECIMAL(5,2) DEFAULT 0.0;
          	DECLARE balancce_el DECIMAL(5,2) DEFAULT 0.0;
          	DECLARE lop_cl DECIMAL(5,2) DEFAULT 0.0;
          	DECLARE lop_el DECIMAL(5,2) DEFAULT 0.0;

				DECLARE absent DECIMAL(5,2) DEFAULT 0.0;

            DECLARE my_working_days INT DEFAULT 0;
            DECLARE leave_taken DECIMAL(10,1) DEFAULT 0.0;
           	DECLARE total_lop_days DECIMAL(5,2) DEFAULT 0.0;


            DECLARE blackstar INT DEFAULT 0;
            DECLARE blackstar_lop DECIMAL(10,1) DEFAULT 0.0;
            DECLARE leave_lop DECIMAL(8,2) DEFAULT 0.0;
            DECLARE absent_lop DECIMAL(8,2) DEFAULT 0.0;
            DECLARE total_leave_lop DECIMAL(8,2) DEFAULT 0.0;

            DECLARE tot_lop DECIMAL(10,2) DEFAULT 0.0;
            DECLARE salary_eligible_days INT DEFAULT 0;
            DECLARE lop_amount DECIMAL(10,2) DEFAULT 0.0;

            DECLARE monthDiff INT DEFAULT 0;
            DECLARE no_working_days INT DEFAULT 0;
            DECLARE no_leave INT DEFAULT 0;

            DECLARE msalary DECIMAL(10,2) DEFAULT 0.0;
            DECLARE net_salary DECIMAL(10,2) DEFAULT 0.0;



            DECLARE calSal CURSOR  FOR
            SELECT employee, SUM(calcstar(employee, 0, logdate, lstartime)), SUM(calcstar(employee, 1, logdate, estartime)) FROM (
                SELECT employee,
                CAST(userlog.logtime AS DATE) AS logdate,
                CAST(MIN((CASE WHEN (userlog.status = 1) THEN userlog.logtime END)) AS TIME ) lstartime,
                CAST(MAX((CASE WHEN (userlog.status = 2) THEN userlog.logtime END)) AS TIME ) estartime
                FROM userlog WHERE (CAST(userlog.logtime AS date) BETWEEN start_date AND end_date)
                GROUP BY logdate, employee)
                a GROUP BY employee;


        DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = TRUE;
        DELETE FROM salaryrecord_tmp;

        OPEN calSal;
            calc_loop: LOOP
            SET emp=NULL;
            FETCH  calSal INTO emp,lstar,estar;
            IF emp is null THEN
                CLOSE calSal;
            LEAVE calc_loop;
            END IF;

        SET basic_salary = ifnull(basicsalary (emp),0);
        SET incents = incentive(emp, start_date, end_date);
        SET deduct = deduction(emp, start_date, end_date);
        SET tot_salary_per_annum = 12 * basic_salary;
        SET per_day_salary = tot_salary_per_annum / no_of_days_in_year;

        SET monthly_cl = monthlyCL(emp);
        SET monthly_el = monthlyEL(emp);

        SET carryforwardstr = carryforwardleaves(emp, amonth, ayear);

        SET cf_cl = SPLIT_STR(carryforwardstr, '|', 1);
        SET cf_el = SPLIT_STR(carryforwardstr, '|', 2);

        SET total_cl = monthly_cl + cf_cl;
        SET total_el = monthly_el + cf_el;

        SET my_working_days = ifnull(workeddays(emp, start_date, end_date),0);
        SET leave_taken = (no_workingdays_per_month - my_working_days) + halfdayleave(emp, start_date, end_date);

        SET leavestr = sanctionedleave(emp, start_date, end_date);
        SET mysanctioned_cl = SPLIT_STR(leavestr, '|', 1);
        SET mysanctioned_el = SPLIT_STR(leavestr, '|', 2);


        SET absent = leave_taken - (mysanctioned_cl + mysanctioned_el);
		  IF(absent <= 0)THEN
		  		SET absent = 0;
		  END IF;

        IF(leave_taken > 0)THEN

            IF(mysanctioned_cl >= total_cl)THEN
            	SET lop_cl = mysanctioned_cl - total_cl;
            	SET cf_cl = 0;
            	SET used_cl = total_cl;
            ELSE
            	SET lop_cl = 0;
            	SET cf_cl = total_cl - mysanctioned_cl;
            	SET used_cl = mysanctioned_cl;
            END IF;
            IF(mysanctioned_el >= total_el)THEN
            	SET lop_el = mysanctioned_el - total_el;
            	SET cf_el = 0;
            	SET used_el = total_el;
            ELSE
            	SET lop_el = 0;
            	SET cf_el = total_el - mysanctioned_el;
            	SET used_el = mysanctioned_el;
            END IF;
            SET leave_lop = lop_cl + lop_el;

        ELSE
            SET used_cl = 0;
            SET used_cl = 0;
        END IF;

        SET absent_lop = absent * absentdays();
        SET total_leave_lop = leave_lop + absent_lop;

        SET blackstar = lstar + estar;
        SET blackstar_lop = (blackstar / halfdaystar()) * 0.5;
        SET blackstar_lop = FLOOR(blackstar_lop/0.5) * 0.5;

        SET tot_lop = blackstar_lop + total_leave_lop;

        SET salary_eligible_days = no_workingdays_per_month - tot_lop;

        SET lop_amount = per_day_salary * tot_lop;
        SET monthDiff =  monthDifference(emp);
        IF(monthDiff = 0)THEN
        			SET no_working_days = presentdays(emp, end_date);
        			SET no_leave = mysanctioned_cl + mysanctioned_el;
        			SET msalary = (no_working_days - no_leave - blackstar_lop) * per_day_salary;
        ELSE
        			IF(my_working_days < min_workingdaysmonth) THEN
        				IF(my_working_days >= llimit)THEN
        					SET my_working_days = my_working_days + 1;
        				END IF;
        				SET msalary = (my_working_days - blackstar_lop) * per_day_salary;
        			ELSE
        				SET msalary = basic_salary - lop_amount;
        			END IF;
        END IF;



        IF(incents > 0) THEN
            SET msalary = msalary + incents;
        END IF;

         IF(deduct > 0) THEN
            SET msalary = msalary - deduct;
        END IF;

        SET net_salary = ROUND(msalary);
        SET net_salary = CEIL(net_salary/10) * 10;


        INSERT INTO salaryrecord_tmp (employee, basic_salary, holiday, working_days,
		  tot_cl, tot_el, used_cl, used_el, cf_cl, cf_el, absent,
		  total_leave,  blackstar, blackstar_lop, leave_lop, total_lop_days, lop_amount, salary,
		  incentive, deductions, net_salary,
		  salary_date, created_at)
        VALUES (emp, basic_salary, no_holidays, my_working_days,
		  total_cl, total_el, used_cl, used_el, cf_cl, cf_el, absent,
		  leave_taken, blackstar, blackstar_lop, leave_lop, tot_lop, lop_amount, msalary,
		  incents, deduct, net_salary, end_date, NOW());

        END LOOP calc_loop;
END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS SP_salaryCalculation');
    }
}
