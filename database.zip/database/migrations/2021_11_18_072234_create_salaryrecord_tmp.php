<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSalaryrecordTmp extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('salaryrecord_tmp', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('employee');
            $table->integer('basic_salary');
            $table->double('per_day_salary', 10, 2);
            $table->integer('holiday');
            $table->integer('working_days');
            $table->double('tot_cl', 4, 2);
            $table->double('tot_el', 4, 2);
            $table->double('used_cl', 4, 2);
            $table->double('used_el', 4, 2);
            $table->double('cf_el', 4, 2);
            $table->double('cf_cl', 4, 2);
            $table->double('absent', 4, 2);
            $table->double('total_leave', 4, 2);
            $table->integer('blackstar');
            $table->double('blackstar_lop', 4, 2);
            $table->double('leave_lop', 4, 2);
            $table->double('total_lop_days', 4, 2);
            $table->double('lop_amount', 10, 2);
            $table->double('salary', 10, 3);
            $table->double('incentive', 10, 2);
            $table->double('deductions', 10, 2);
            $table->double('net_salary', 10, 2);
            $table->date('salary_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('salaryrecord_tmp');
    }
}
