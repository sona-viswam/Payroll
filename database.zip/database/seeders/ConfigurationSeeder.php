<?php

namespace Database\Seeders;

use App\Models\Configuration;
use Illuminate\Database\Seeder;

class ConfigurationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Configuration::create(['caption' => 'halfday', 'value' => '18'],
            ['caption' => 'EL', 'value' => '1'],
            ['caption' => 'CL', 'value' => '1'],
            ['caption' => 'EL_limit', 'value' => '4'],
            ['caption' => 'absent', 'value' => '1'],
            ['caption' => 'monthly_leave', 'value' => '4'],
            ['caption' => 'min_working_days', 'value' => '5'],
            ['caption' => 'first_leave_limit', 'value' => '10'],
            ['caption' => 'second_leave_limit', 'value' => '20'],
        );

    }
}
