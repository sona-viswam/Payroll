<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ShiftstarSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('shiftstar')->insert([
            ['sid'=>1,	'startype'=>0,	'lstarmin'=>11,	'lstarpoints'=>6],
            ['sid'=>1,	'startype'=>0,	'lstarmin'=>60,	'lstarpoints'=>9],
            ['sid'=>1,	'startype'=>0,	'lstarmin'=>120,	'lstarpoints'=>10],
            ['sid'=>1,	'startype'=>0,	'lstarmin'=>180,	'lstarpoints'=>11],
            ['sid'=>1,	'startype'=>0,	'lstarmin'=>240,	'lstarpoints'=>0],
            ['sid'=>1,	'startype'=>1,	'lstarmin'=>120,	'lstarpoints'=>3],
            ['sid'=>1,	'startype'=>1,	'lstarmin'=>60,	'lstarpoints'=>2],
            ['sid'=>1,	'startype'=>1,	'lstarmin'=>0,	'lstarpoints'=>1]
        ]);
    }
}
