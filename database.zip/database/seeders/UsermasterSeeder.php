<?php

namespace Database\Seeders;

use App\Models\Usermaster;
use Illuminate\Database\Seeder;

class UsermasterSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Usermaster::create([
            'firstname' => 'admin',
            'secondname' => 'admin',
            'username' => 'admin',
            'password' => 'admin',
            'country' => '1',
            'email' => 'admin@email.com',
            'hiredate' => '2000-01-01',
            'role' => 'admin',
        ]);
    }
}
