<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <p class="card-description">

                            @php
                                if($data[0]->shifts()->exists())
                                {
                                  $myshift =  $data[0]->shifts()->orderByDesc('id')->first();
                                  $shiftname = $myshift->shiftname;
                                  $starttime = date('g:i A', strtotime($myshift->starttime));
                                  $endtime = date('g:i A', strtotime($myshift->endtime));
                                  $breakstart = date('g:i A', strtotime($myshift->breakstart));
                                  $breakend = date('g:i A', strtotime($myshift->breakend));
                              }
                              else
                              {
                                  $shiftname = $starttime = $endtime = $breakstart = $breakend = '';
                              }


                            @endphp
                            <ul class="list-star">
                                <li class="text-dark bold">Current Shift is {{ $shiftname }}</li>
                                <li class="text-dark bold">Shift Starts at  {{ $starttime }}</li>
                                <li class="text-dark bold">Shift Ends at  {{ $endtime }}</li>
                                <li class="text-dark bold">Break from  {{ $breakstart }} to {{$breakend}}</li>

                            </ul></p>

                            <ul class="list-arrow">
                                <li>Late Marks: Weightage Marks given to 1st hour is 6, 2nd hour is 3 and from 3rd hour onwards it is 1.</li>
                                <li>Early Marks: Each hour has one Mark</li>
                                <li>Salary is affected according to the proportion of black marks in daily payroll.</li>
                                <li>18 black marks is equivalent to half day of salary</li>
                                <li>36 black marks is equivalent to one day salary</li>
                            </ul>

                        </div>
                    </div>

                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
