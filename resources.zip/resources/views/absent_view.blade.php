<!DOCTYPE html>
<html lang="en">
@include('header')
@include('myjobcard_js')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <p class="card-description">
                            @if ( Auth::user()->isAdmin() )
                            <table class="table table-bordered">
                                <tr><td>Balance CL</td><td>{{ $balanceCL }}</td><td>Balance EL</td><td>{{ $balanceEL }}</td></tr>
                            </table>
                            @endif
                            </p>
{{--                            <table class="table table-striped">--}}
{{--                                <thead>--}}
{{--                                </thead>--}}
{{--                                <tr>--}}
{{--                                    <td class="font-weight-bold"> Employee </td><td>{{ $data[0]->remployee->fullname }}</td>--}}
{{--                                    <td class="font-weight-bold"> Backup Employee </td>--}}
{{--                                    <td>{{ isset($data[0]->bemployee) ? $data[0]->rbemployee->fullname : '' }}</td>--}}
{{--                                </tr>--}}
{{--                                <tr>--}}
{{--                                    <td class="font-weight-bold"> Applied Date </td>--}}
{{--                                    <td>{{ date('d-m-Y', strtotime($data[0]->created_at)) }}</td>--}}
{{--                                    <td class="font-weight-bold"></td>--}}
{{--                                    <td></td>--}}
{{--                                </tr>--}}
{{--                                <tr>--}}
{{--                                    <td class="font-weight-bold">Start Date </td>--}}
{{--                                    <td>{{ date('d-m-Y', strtotime($data[0]->ldate)) }}</td>--}}
{{--                                    <td class="font-weight-bold"> End Date </td>--}}
{{--                                    <td>{{ isset($data[0]->ldate2) ? date('d-m-Y', strtotime($data[0]->ldate2)) : '' }} </td>--}}
{{--                                </tr>--}}
{{--                                <tr>--}}
{{--                                    <td class="font-weight-bold">Subject</td>--}}
{{--                                    <td colspan="4">{{ $data[0]->subject }}</td>--}}
{{--                                </tr>--}}
{{--                                <tr>--}}
{{--                                    <td class="font-weight-bold">Content</td>--}}
{{--                                    <td colspan="4">{{ $data[0]->content }}</td>--}}
{{--                                </tr>--}}
{{--                                <tr>--}}
{{--                                    <td class="font-weight-bold"> Status </td>--}}
{{--                                    <td rowspan="3">--}}
{{--                                        @php $status = $data[0]->status @endphp--}}
{{--                                            @switch($status)--}}
{{--                                                @case('1')--}}
{{--                                                <label class="badge badge-gradient-warning">PROGRESS</label>--}}
{{--                                                @break--}}
{{--                                                @case('2')--}}
{{--                                                <label class="badge badge-gradient-success">APPROVED</label>--}}
{{--                                                @break--}}
{{--                                                @case('5')--}}
{{--                                                <label class="badge badge-gradient-danger">REJECTED</label>--}}
{{--                                                @break--}}
{{--                                                @default--}}
{{--                                                <label class="badge badge-gradient-info">ON HOLD</label>--}}
{{--                                            @endswitch--}}
{{--                                    </td>--}}
{{--                                    @php--}}
{{--                                    $reasonValue = $data[0]->reason;--}}
{{--                                    if(($status ==5) && isset($reasonValue)){--}}
{{--                                        $reason =1;--}}
{{--                                    }else{--}}
{{--                                        $reason =0;--}}
{{--                                    }--}}
{{--                                    @endphp--}}
{{--                                    <td class="font-weight-bold">--}}
{{--                                        {{ ($reason ==1) ? 'Reason' : '' }}--}}
{{--                                    </td>--}}
{{--                                    <td>--}}
{{--                                        {{ ($reason ==1) ? $reasonValue : '' }}--}}
{{--                                    </td>--}}
{{--                                </tr>--}}
{{--                            </table>--}}

                        </div>
                    </div>
                </div>
            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
