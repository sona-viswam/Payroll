<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            @if ($count>0)
                            <div style="position: absolute;right:200px;top:25px;">
                                <a class="btn btn-gradient-success mr-2" href="{{url('salary_calculation_view')}}">* Calculated</a>
                            </div>
                            @endif
                            <div style="position: absolute;right:10px;top:25px;">
                                <a class="btn btn-gradient-primary mr-2" href="{{url('salary_calculate')}}">+ Calculate</a>
                            </div>
                            <p class="card-description">
                                {{--                                Add class <code>.table-striped</code>--}}

                            </p>
                            @php
                                    $now = \Carbon\Carbon::now();
                                    $currentyear = $now->year;
                                    $currentmonth = $now->month;
                            @endphp
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span> #</th>
                                    <th> Name </th>
                                    <th> Salary </th>
                                    <th> Date </th>
                                    <th> Tools </th>
                                </tr>
                                </thead>
                                <tbody>
                                @php $i = $data->perPage() * ($data->currentPage() - 1); @endphp
                                @foreach ($data as $key => $value)
                                    @php
                                        $created_date = $value->created_at;
                                        $created_month = date('m', strtotime($created_date));
                                        $created_year = date('Y', strtotime($created_date));
                                    @endphp
                                    <tr class="{{ ( ($currentyear == $created_year) && ($currentmonth == $created_month))? 'table-warning' : '' }}">
                                        <td class="py-1"> {{ ++ $i}}</td>
                                        <td>{{ $value->remployee->fullname }} </td>
                                        <td> {{ $value->net_salary }} </td>
                                        <td> {{ date('M d, Y', strtotime($value->salary_date)) }} </td>
                                       <td>
                                            <a title="Detailed Salary" href="{{ route('salary_detailed', ['id' => $value->id]);}}" title="Detailed Salary">
                                            <span class="page-title-icon bg-gradient-info text-white mr-2">
                                              <i class="mdi mdi-eye"></i>
                                            </span>
                                            </a>

                                            <a title="Attendance" href="{{ route('attendance_bymonth', ['id' => $value->employee, 'sdate' => $value->salary_date]);}}" title="Attendance">
                                            <span class="page-title-icon bg-gradient-primary text-white mr-2">
                                              <i class="mdi mdi-view-module"></i>
                                            </span>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                                 </tbody>
                            </table>
                            <table class="table">
                                <tr><td>{!! $data->links() !!} </td></tr>
                            </table>
                        </div>
                    </div>

                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
