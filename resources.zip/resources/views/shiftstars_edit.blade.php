<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <form class="form-sample" action="{{ route('shiftstar_update',  $data[0]->id) }}" method="post">@csrf
                                <p class="card-description">
                                    @switch($data[0]->startype)
                                        @case(1)
                                        Logout
                                        @break
                                        @default
                                        Login
                                    @endswitch
                                </p>
                                @include('message')
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Minutes</label>
                                            <div class="col-sm-8">
                                                <input name="sid" type="hidden" class="form-control" value="{{ $data[0]->sid }}"  />
                                                <input name="lstarmin" type="hidden" class="form-control" value="{{ $data[0]->lstarmin }}"  />
                                                <input name="lstarmin_1" type="text" class="form-control" value="{{ $data[0]->lstarmin }}" readonly  />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Star<i class="mdi mdi-star icon-sm text-danger"></i></label>
                                            <div class="col-sm-8">
                                                <input name="lstarpoints" type="text" class="form-control" value="{{ $data[0]->lstarpoints }}"  />
                                                @if ($errors->has('lstarpoints'))
                                                    <span class="text-danger">{{ $errors->first('lstarpoints') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label"></label>
                                        <div class="col-sm-9">
                                            <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                                            <a class="btn btn-light" href="{{url('shift')}}">Cancel</a>
                                        </div>
                                    </div>
                                </div>

                        </div>


                            </form>
                        </div>
                    </div>
                </div>




            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
