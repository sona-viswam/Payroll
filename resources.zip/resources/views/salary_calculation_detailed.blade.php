<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>

                            <p class="card-description">
{{--                                Add class <code>.table-striped</code>--}}
                            </p>
                            <table class="table table-striped">
                                <thead>
                                </thead>
                                <tr>
                                    <td class="font-weight-bold"> Employee Name </td><td>{{ $data[0]->remployee->fullname; }}</td>
                                    <td class="font-weight-bold"> Photo </td>
                                    <td>
                                        @php
                                            $photoName = $data[0]->remployee->photo;
                                            if($photoName){
                                                $photo = asset('upload/'.$photoName);
                                            }else{
                                                $photo =  asset('assets/images/faces-clipart/pic-1.png');
                                            }
                                        @endphp

                                        <img src="{{ $photo }}" alt="image" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Basic Salary </td><td>{{ $data[0]->basic_salary }}</td>
                                    <td class="font-weight-bold"> Per day </td><td>{{ $data[0]->per_day_salary }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Worked Days </td><td>{{ $data[0]->working_days }}</td>
                                    <td class="font-weight-bold"> Holiday </td><td>{{ $data[0]->holiday }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Total CL </td><td>{{ $data[0]->tot_cl }}</td>
                                    <td class="font-weight-bold"> Total EL </td><td>{{ $data[0]->tot_el }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Used CL </td><td>{{ $data[0]->used_cl }}</td>
                                    <td class="font-weight-bold"> Used EL </td><td>{{ $data[0]->used_el }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Absent </td><td>{{ $data[0]->absent }}</td>
                                    <td class="font-weight-bold"> Total Leave </td><td>{{ $data[0]->total_leave }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Blackstar</td><td>{{ $data[0]->blackstar }}</td>
                                    <td class="font-weight-bold"> Blackstar LOP Days</td><td>{{ $data[0]->blackstar_lop }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Total LOP Days </td><td>{{ $data[0]->total_lop_days }}</td>
                                    <td class="font-weight-bold"> LOP Amount </td><td>{{ $data[0]->lop_amount }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Incentive </td><td>{{ $data[0]->incentive }}</td>
                                    <td class="font-weight-bold"> Deductions </td><td>{{ $data[0]->deductions }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Salary </td><td>{{ $data[0]->salary }}</td>
                                    <td class="font-weight-bold">  </td><td></td>
                                </tr>

                                @php
                                    $digit = new NumberFormatter("en", NumberFormatter::SPELLOUT);
                                    $total = $data[0]->net_salary;
                                @endphp
                                <tr>
                                    <td class="font-weight-bold">Salary in Words </td><td class="font-weight-bold">{{ Str::ucfirst($digit->format($total)) }}  </td>
                                    <td class="font-weight-bold"></td><td></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Net Salary </td><td class="text-info font-weight-bold">{{ $data[0]->net_salary }}</td>
                                    <td class="font-weight-bold"></td><td></td>
                                </tr>

                            </table>
                        </div>
                    </div>
                </div>




            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
