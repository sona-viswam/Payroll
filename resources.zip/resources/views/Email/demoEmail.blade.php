@component('mail::message')
# MileStone Leave Application

Subject: {{ $mailData['subject'] }}
<br>
Date: {{ $mailData['leavedate'] }}
<br>
Backup Employee: {{ $mailData['bemployee'] }}
<br>
<br>
{{ $mailData['content'] }}

{{--@component('mail::button', ['url' => ''])--}}
{{--Button Text--}}
{{--@endcomponent--}}

Thanks,<br>
{{ Auth::user()->full_name }}
{{--{{ config('app.name') }}--}}
@endcomponent
