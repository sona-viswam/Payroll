<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <p class="card-description"> {{$today}} </p>
                            <div style="position: absolute;right:10px;top:25px;">
                                <a class="btn btn-gradient-primary mr-2" href="{{url('attendance_add')}}">+ Add Attendance</a>
                            </div>
                            <p class="card-description">
                                {{--                                Add class <code>.table-striped</code>--}}

                            </p>
                            @include('message')
                            <table class="table table-striped">
                                @if ($data->count() > 0 )
                                <thead>
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span>#</th>
                                    <th> Employee </th>
                                    <th> Log in </th>
                                    <th> Source </th>
                                    <th> Log out </th>
                                    <th> Source </th>
                                    <th> Attendance </th>
                                </tr>
                                </thead>
                                <tbody>
                                @php $i = 0; @endphp
                                @foreach ($data as $key => $value)
                                    @php
                                    if(isset($value->loggedout)){
                                        $logout = date('H:i', strtotime($value->loggedout));
                                        if($value->lastsource == '1'){
                                            $lastsource = 'Website';
                                        }else{
                                            $lastsource = 'Machine';
                                        }
                                    }else{
                                        $logout = $lastsource = '-';
                                    }
                                    @endphp
                                    <tr>
                                        <td class="py-1"> {{ ++ $i}}</td>
                                        <td> {{ $value->fullname }}</td>
                                        <td> {{ date('H:i', strtotime($value->firstlogin)) }}</td>
                                        <td>{{ ($value->firstsource == '1') ? 'Website': 'Machine' }}</td>
                                        <td> {{  $logout }}</td>
                                        <td>{{ $lastsource }}</td>
                                        <td>
                                            <a title="Daily" href="{{ route('attendance_daily', ['id' => $value->id]);}}">
                                            <span class="page-title-icon bg-gradient-primary text-white mr-2">
                                            <i class="mdi mdi-login"></i>
                                            </span>
                                            </a>

                                            <a title="Monthly" href="{{ route('attendance_monthly', ['id' => $value->id]);}}">
                                            <span class="page-title-icon bg-gradient-primary text-white mr-2">
                                            <i class="mdi mdi-logout-variant"></i>
                                            </span>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                                @else
                                    <tr>
                                        <td colspan="2" align="center">No Records</td>
                                    </tr>
                                @endif

                            </table>
                            <table class="table">
{{--                                <tr><td>{!! $data->links() !!} </td></tr>--}}
                            </table>
                        </div>
                    </div>

                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
