<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
@include('box')
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
{{--                            <div style="position: absolute;right:10px;top:25px;">--}}
{{--                                <a class="btn btn-gradient-primary mr-2" href="{{url('mywork_add')}}">+ Add</a>--}}
{{--                            </div>--}}
                            <p class="card-description"></p>
                            @include('message')
                            <table class="table table-striped">
                                @if ($data->count() > 0 )
                                <thead>
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span>#</th>

                                    <th> Activity </th>
                                    <th> Start Time </th>
                                    <th> End Time </th>
                                    <th> Time </th>
                                    <th> Tools </th>

                                </tr>
                                </thead>
                                <tbody>
                                @php $i = $tot =0;
                                @endphp
                                @foreach ($data as $key => $value)
{{--                                    @dd($value->Employee);--}}
@php
        $status = $value->rjobcard->status;
        $jobcardid = $value->jobcardid;
        $minutes = $value->timetaken;
        $hours = intdiv($minutes, 60).':'. ($minutes % 60);
        $tot = $tot + $minutes;
@endphp
                                    <tr>
                                        <td class="py-1"> {{ ++ $i}}</td>

                                        <td> {{  $value->ractivity->activity  }} </td>
                                        <td> {{ date('g i A', strtotime($value->starttime)) }}</td>
                                        <td> {{ date('g i A', strtotime($value->endtime)) }}</td>
                                        <td> {{  $hours  }} </td>

                                        <td>
                                            <a title="Details" href="{{ route('mywork_view', ['id' => $value->id]);}}">
                                                    <span class="page-title-icon bg-gradient-info text-white mr-2">
                                                    <i class="mdi mdi-eye"></i>
                                                    </span>
                                            </a>
                                            @if ($status <> 3)
                                            <a href="{{ route('mywork_edit', ['id' => $value->id]);}}" title="Edit">
                                                <span class="page-title-icon bg-gradient-success text-white mr-2">
                                                    <i class="mdi mdi-table-edit"></i>
                                                </span>
                                            </a>
                                            <a title="Delete" href="#" onclick="showBox(this,'{{ route('mywork_delete', ['id' => $value->id]);}}')">
                                                <span class="page-title-icon bg-gradient-danger text-white mr-2">
                                                    <i class="mdi mdi-delete-forever"></i>
                                                </span>
                                            </a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                                <tr>
                                    <td colspan="6"> </td>
                                </tr>
                                <tr>   <td></td>
                                    <td> Login: </td><td>{{ $login }} </td>
                                    <td> Logout: </td><td colspan="2"> {{ $logout }} </td>
                                </tr>
                                <tr>
                                <tr>   <td></td>
                                    <td> Work Period: </td><td class="font-weight-bold">
                                        {{ intdiv($workmin, 60).':'. ($workmin % 60) }} </td>
                                    <td> Total Time: </td><td colspan="2" class="font-weight-bold">
                                        {{ intdiv($tot, 60).':'. ($tot % 60) }} </td>
                                </tr>
                                <tr>
                                    @if ($status == 3)
                                        <th colspan="5"></th>
                                        <th>
                                            @switch($status)
                                                @case('1')
                                                <label class="badge badge-gradient-warning">&emsp;&emsp;DRAFT&emsp;&emsp;</label>                                                @break
                                                @case('2')
                                                <label class="badge badge-gradient-info">&emsp;&emsp;VERIFIED&emsp;&emsp;</label>
                                                @break
                                                @default
                                                <label class="badge badge-gradient-success">&emsp;&emsp;APPROVED&emsp;&emsp;</label>
                                            @endswitch
                                        </th>
                                    @else
                                        <th colspan="3"></th>
                                        <th> Status </th>
                                        <form class="form-sample" action="{{ route('jobcard_update', $jobcardid) }}" method="post">@csrf
                                            <input name="id" type="hidden" value = "{{ $jobcardid }}" />
                                        <th>
                                            <select class="form-control" name="status">
                                                    <option value="2" {{ ($status ==2) ? 'selected' : '' }}>Verified</option>
                                                    <option value="3" {{ ($status ==3) ? 'selected' : '' }}>Approved</option>
                                            </select>
                                        </th><th>
                                                <button type="submit" class="btn-sm btn-gradient-primary mr-2">Submit</button>
                                        </th>
                                        </form>
                                    @endif
                                </tr>
                                @else
                                    <tr>
                                        <td colspan="2" align="center">No Records</td>
                                    </tr>
                                @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
