<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <p class="card-description">
{{--                                Add class <code>.table-striped</code>--}}
                            </p>
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th> Employee </th>
                                    <th> Name </th>
                                    <th> Email </th>
                                    <th> Hire Date </th>
                                    <th> Last Date </th>
                                    <th> Tools </th>
                                       </tr>
                                </thead>
                                <tbody>
                                @foreach ($data as $key => $value)
                                <tr>
                                    <td class="py-1">
                                        @php
                                            $photoName = $value->photo;
                                            if($photoName){
                                                $photo = asset('upload/'.$photoName);
                                            }else{
                                                $photo =  asset('assets/images/faces-clipart/pic-1.png');
                                            }
                                        @endphp

                                        <img src="{{ $photo }}" alt="image" />
                                    </td>
                                    <td> {{ $value->fullname }} </td>

                                    <td> {{ $value->email }}  </td>
                                    <td>
                                        @if(empty($value->hiredate ))

                                        @else
                                            {{date('d-M-Y', strtotime($value->hiredate))}}
                                        @endif
                                    </td>
                                    <td>
                                        @if(empty($value->lastdate ))

                                        @else
                                            {{date('d-M-Y', strtotime($value->lastdate))}}
                                        @endif
                                    </td>
                                    <td>
                                        <a href="{{ route('viewEmployee', ['id' => $value->id]);}}" title="View">
                                        <span class="page-title-icon bg-gradient-info text-white mr-2">
                                          <i class="mdi mdi mdi-eye"></i>
                                        </span>
                                        </a>
                                        <a href="{{ route('editEmployee', ['id' => $value->id]);}}" title="Edit">
                                        <span class="page-title-icon bg-gradient-success text-white mr-2">
                                          <i class="mdi mdi-table-edit"></i>
                                        </span>
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                            <table class="table">
                                <tr><td>{!! $data->links() !!} </td></tr>
                            </table>

                        </div>
                    </div>

                </div>




            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
