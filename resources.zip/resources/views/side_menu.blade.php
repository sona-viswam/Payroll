<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item nav-profile">
            <a href="#" class="nav-link">
                <div class="nav-profile-image">
                    @php
                        $photoName = Auth::user()->photo;
                        if($photoName){
                            $photo = asset('upload/'.$photoName);
                        }else{
                            $photo =  asset('assets/images/faces-clipart/pic-1.png');
                        }
                    @endphp
                    <img src="{{ $photo }}" alt="profile">
                    <span class="login-status online"></span>
                    <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column">
                    <span class="font-weight-bold mb-2">{{ Auth::user()->full_name; }}</span>
                    <span class="text-secondary text-small">
                        @php
                            if(Auth::user()->designations()->exists())
                            {
                                $user_designation = Auth::user()->designations()->orderByDesc('id')->first()->designation;
                            }
                            else
                            {
                                $user_designation = ucfirst(Auth::user()->role);
                            }
                         @endphp
                        {{ $user_designation }}
                    </span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{url('dashboard')}}">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
            </a>
        </li>
        @if ( Auth::user()->isAdmin() )

        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#ui-basic2" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Attendance</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-human-greeting menu-icon"></i>
            </a>
            <div class="collapse" id="ui-basic2">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{url('attendance')}}">Attendance</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{url('absent')}}">Absent</a></li>
                </ul>
            </div>
        </li>


        <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ui-basic3" aria-expanded="false" aria-controls="ui-basic">
                    <span class="menu-title">Leave</span>
                    <i class="menu-arrow"></i>
                    <i class="mdi mdi-account-convert menu-icon"></i>
                </a>
                <div class="collapse" id="ui-basic3">
                    <ul class="nav flex-column sub-menu">
                        <li class="nav-item"> <a class="nav-link" href="{{url('leave')}}">Leave</a></li>
                        <li class="nav-item"> <a class="nav-link" href="{{url('request')}}">Requests</a></li>
                        <li class="nav-item"> <a class="nav-link" href="{{url('holiday')}}">Holiday <i class="mdi mdi-emoticon-happy menu-icon"></i></a></li>
                    </ul>
                </div>
        </li>

        <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ui-basic4" aria-expanded="false" aria-controls="ui-basic">
                    <span class="menu-title">Salary</span>
                    <i class="menu-arrow"></i>
                    <i class="mdi mdi mdi-cash-usd menu-icon"></i>
                </a>
                <div class="collapse" id="ui-basic4">
                    <ul class="nav flex-column sub-menu">
                        <li class="nav-item"> <a class="nav-link" href="{{url('salary')}}">Salary</a></li>
                        <li class="nav-item"> <a class="nav-link" href="{{url('incentive')}}">Incentive</a></li>
                        <li class="nav-item"> <a class="nav-link" href="{{url('deduction')}}">Deduction</a></li>
                    </ul>
                </div>
        </li>
        <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ui-basic1" aria-expanded="false" aria-controls="ui-basic">
                    <span class="menu-title">Employees</span>
                    <i class="menu-arrow"></i>
                    <i class="mdi mdi-account-multiple menu-icon"></i>
                </a>
                <div class="collapse" id="ui-basic1">
                    <ul class="nav flex-column sub-menu">
                        <li class="nav-item"> <a class="nav-link" href="{{url('employees')}}">Current Employees</a></li>
                        <li class="nav-item"> <a class="nav-link" href="{{url('employeesSuspend')}}">Previous Employees</a></li>
                    </ul>
                </div>
        </li>
        <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ui-basic5" aria-expanded="false" aria-controls="ui-basic">
                    <span class="menu-title">JobCard</span>
                    <i class="menu-arrow"></i>
                    <i class="mdi mdi-account-network menu-icon"></i>
                </a>
                <div class="collapse" id="ui-basic5">
                    <ul class="nav flex-column sub-menu">
                        <li class="nav-item"> <a class="nav-link" href="{{url('jobcard')}}">Jobs</a></li>
                        <li class="nav-item"> <a class="nav-link" href="{{url('job_calculate')}}">Calculations</a></li>
                    </ul>
                </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{url('department')}}">
                <span class="menu-title">Department</span>
                <i class="mdi mdi-apps-box menu-icon"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{url('designation')}}">
                <span class="menu-title">Designation</span>
                <i class="mdi mdi-apps menu-icon"></i>
            </a>
        </li>
        <li class="nav-item">
                <a class="nav-link" href="{{url('client')}}">
                    <span class="menu-title">Client</span>
                    <i class="mdi mdi-account-box-outline menu-icon"></i>
                </a>
        </li>
            <li class="nav-item">
                <a class="nav-link" href="{{url('project')}}">
                    <span class="menu-title">Project</span>
                    <i class="mdi mdi-laptop-chromebook menu-icon"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{url('activity')}}">
                    <span class="menu-title">Activity</span>
                    <i class="mdi mdi mdi-wunderlist menu-icon"></i>
                </a>
            </li>

        <li class="nav-item">
            <a class="nav-link" href="{{url('shift')}}">
                <span class="menu-title">Shift</span>
                <i class="mdi mdi-timetable menu-icon"></i>
            </a>
        </li>


        <li class="nav-item">
                <a class="nav-link" href="{{url('device')}}">
                    <span class="menu-title">Device</span>
                    <i class="mdi mdi-settings-box menu-icon"></i>
                </a>
        </li>

        <li class="nav-item">
                <a class="nav-link" href="{{url('settings')}}">
                    <span class="menu-title">Settings</span>
                    <i class="mdi mdi-settings menu-icon"></i>
                </a>
        </li>
        @endif




        @if ( Auth::user()->isUser() )
            <li class="nav-item">
                <a class="nav-link" href="{{url('myjobcard')}}">
                    <span class="menu-title">JobCard</span>
                    <i class="mdi mdi-account-network menu-icon"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{url('myattendance')}}">
                    <span class="menu-title">Attendance</span>
                    <i class="mdi mdi-human-handsup menu-icon"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ui-basic3" aria-expanded="false" aria-controls="ui-basic">
                    <span class="menu-title">Leave</span>
                    <i class="menu-arrow"></i>
                    <i class="mdi mdi-contacts menu-icon"></i>
                </a>
                <div class="collapse" id="ui-basic3">
                    <ul class="nav flex-column sub-menu">
                        <li class="nav-item"> <a class="nav-link" href="{{url('myleave')}}">My Leave</a></li>
                        <li class="nav-item"> <a class="nav-link" href="{{url('myrequest')}}">Requests</a></li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{url('mysalary')}}">
                    <span class="menu-title">Salary</span>
                    <i class="mdi mdi-cash-usd menu-icon"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{url('myshift_details')}}">
                    <span class="menu-title">Shift</span>
                    <i class="mdi mdi-timetable menu-icon"></i>
                </a>
            </li>
        @endif
    </ul>
</nav>
