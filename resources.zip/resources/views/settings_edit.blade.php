<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <form class="form-sample" action="{{ route('settings_update', $data[0]->id) }}" method="post">@csrf
                                <p class="card-description"> Configuration changes will get affect the behaviour of existing software. </p>
                                @include('message')
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Title<span class="mdi mdi-star icon-sm text-danger"></span></label>
                                            <div class="col-sm-8">
                                                <input name="caption" type="text" class="form-control" value="{{ $data[0]->caption }}" {{ ($data[0]->id <= 6) ? 'readonly' : '' }}/>
                                                @if ($errors->has('caption'))
                                                    <span class="text-danger">{{ $errors->first('caption') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Value<span class="mdi mdi-star icon-sm text-danger"></label>
                                            <div class="col-sm-8">
                                                <input name="value" type="number" class="form-control" value="{{ $data[0]->value }}" />
                                                @if ($errors->has('value'))
                                                    <span class="text-danger">{{ $errors->first('value') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label"></label>
                                        <div class="col-sm-9">
                                            <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                                            <a class="btn btn-light" href="{{url('settings')}}">Cancel</a>
                                        </div>
                                    </div>
                                </div>

                        </div>


                            </form>
                        </div>
                    </div>
                </div>
            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
