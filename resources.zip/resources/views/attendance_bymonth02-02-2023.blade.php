<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <p class="card-description"> {{$today}} </p>
                            <p class="card-description">
                            </p>
{{--@dd($leave->toArray())--}}

@php
    $leaveArr = $leave->toArray();
    $holidayArr = $holiday->toArray();
    $logsArr = $logs->toArray();
    $yearmonth = $theYear.'-'.$theMonth;
/*    if(array_key_exists("2021-11-01", $logsArr)) {
        echo ($logsArr['2021-11-01']['employee'] );
    }*/
@endphp
{{--                            @dd($logsArr)--}}




                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span>#</th>
                                    <th> Date </th>
                                    <th> Log in </th>
                                    <th> Late Star</th>
                                    <th> Log out </th>
                                    <th> Early Star</th>
                                </tr>
                                </thead>
                                <tbody>
                                @for ($i =1; $i <= $lastDayofMonth; $i++)
                                        @php
                                            if($i<10){
                                                $day = '0'.$i;
                                            }else{
                                                $day = $i;
                                            }
                                            $checkdate = $yearmonth.'-'.$day;
                                            $thisday = date('l', strtotime($checkdate));
                                            if($thisday == 'Sunday'){
                                        @endphp
                                        <tr class="table-danger">
                                            <td class="py-1"> {{ $i}}</td>
                                            <td colspan="5" align="center" class="font-weight-bold">Sunday</td>
                                        </tr>
                                        @php
                                        }else{
                                            if(array_key_exists($checkdate, $logsArr)) {
                                        @endphp
                                        <tr>
                                            <td class="py-1"> {{ $i }}</td>
                                            <td> {{ date('d-M-Y', strtotime($logsArr[$checkdate]['logdate']))}}</td>
                                            <td> {{ date('g:i', strtotime( $logsArr[$checkdate]['firstlogin'])) }} </td>
                                            <td> {{ $logsArr[$checkdate]['latestar'] }}
                                                @php if($logsArr[$checkdate]['latestar'] > 0){
                                                @endphp
                                                <label class="badge badge-gradient-danger">LATE</label>
                                                @php } @endphp
                                            </td>
                                            <td> {{ date('g:i', strtotime($logsArr[$checkdate]['lastlogout'])) }} </td>
                                            <td> {{ $logsArr[$checkdate]['earlystar'] }}
                                                @php if($logsArr[$checkdate]['earlystar'] > 0){
                                                @endphp
                                                <label class="badge badge-gradient-success">EARLY</label>
                                                @php } @endphp
                                            </td>
                                        </tr>

                                       @php
                                           }else{
                                                    if(array_key_exists($checkdate, $leaveArr)) {
                                       @endphp
                                        <tr class="table-info">
                                            <td class="py-1"> {{ $i}}</td>
                                            <td colspan="5" align="center" class="font-weight-bold"> Leave </td>
                                        </tr>
                                        @php
                                            }else{
                                                if(array_key_exists($checkdate, $holidayArr)) {
                                        @endphp
                                        <tr class="table-primary">
                                            <td class="py-1"> {{ $i}}</td>
                                            <td colspan="5" align="center" class="font-weight-bold"> Holiday </td>
                                        </tr>
                                        @php
                                            }else{
                                        @endphp
                                        <tr class="table-success">
                                            <td class="py-1"> {{ $i}}</td>
                                            <td colspan="5" align="center" class="font-weight-bold"> Absent </td>
                                        </tr>
                                        @php
                                        }
                                        }
                                        }
                                        }

                                       @endphp

                                @endfor
                                 </tbody>
                            </table>

                        </div>
                    </div>

                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
