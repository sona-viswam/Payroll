<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>

                            <p class="card-description">
                                {{--                                Add class <code>.table-striped</code>--}}
                            </p>
                            <table class="table table-striped">
                                <thead>
                                </thead>
                                <tr>
                                    <td class="font-weight-bold"> Activity </td><td>{{ $data[0]->ractivity->activity }}</td>
                                    <td class="font-weight-bold"> Client </td><td>
                                        @php
                                            if(($data[0]->client) >0){
                                                $client = $data[0]->rclient->client;
                                            }else{
                                                $client = '';
                                            }
                                        @endphp
                                        {{ $client }}
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Project </td><td>
                                        @php
                                            if(($data[0]->type1) >0){
                                                $project = $data[0]->rproject->project;
                                            }else{
                                                $project = '';
                                            }
                                        @endphp
                                        {{ $project }}
                                    </td>
                                    <td class="font-weight-bold"> Module </td><td>
                                        @php
                                            if(($data[0]->type2) >0){
                                                $module = $data[0]->rmodule->modulename;
                                            }else{
                                                $module = '';
                                            }
                                        @endphp
                                        {{ $module }}
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> SubModule </td><td>
                                        @php
                                            if(($data[0]->type3) >0){
                                                $submodule = $data[0]->rsubmodule->modulename;
                                            }else{
                                                $submodule = '';
                                            }
                                        @endphp
                                        {{ $submodule }}
                                    </td>
                                    <td class="font-weight-bold"> Date </td>
                                    <td>{{ date('M d, Y', strtotime($data[0]->starttime)) }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Start Time </td>
                                    <td>
                                        @php
                                            if(($data[0]->starttime) >0){
                                                $starttime = date('g i A', strtotime($data[0]->starttime));
                                            }else{
                                                $starttime = '';
                                            }
                                        @endphp
                                        {{ $starttime }}
                                    </td>
                                    <td class="font-weight-bold"> End Time </td>
                                    <td>
                                        @php
                                            if(($data[0]->endttime) >0){
                                                $endttime = date('g i A', strtotime($data[0]->endttime));
                                            }else{
                                                $endttime = '';
                                            }
                                        @endphp
                                        {{ $endttime }}
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Description </td>
                                    <td colspan = "3">{{ $data[0]->description }}</td>
                                </tr>
                                @php $tot = $data[0]->timetaken @endphp
                                <tr>
                                    <td class="font-weight-bold"> Total Time </td>
                                    <td>{{ intdiv($tot, 60).':'. ($tot % 60)  }}</td>
                                    <td class="font-weight-bold"> Status </td>
                                    <td>
                                        @switch($status)
                                            @case('1')
                                            <label class="badge badge-gradient-warning">DRAFT</label>                                                @break
                                            @case('2')
                                            <label class="badge badge-gradient-info">VERIFIED</label>
                                            @break
                                            @default
                                            <label class="badge badge-gradient-success">APPROVED</label>
                                        @endswitch
                                    </td>
                                </tr>
                           </table>
                        </div>
                    </div>
                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
