<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <p class="card-description"> {{$today}} </p>
                            <p class="card-description">
                            </p>
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span>#</th>
                                    <th> Date </th>
                                    <th> Day </th>
                                    <th> Log in </th>
                                    <th> Late Mark</th>
                                    <th> Log out </th>
                                    <th> Early Mark</th>
                                    <th></th>

                                </tr>
                                </thead>
                                <tbody>
                                @php $totstar = $earlystar = $latestar = $i = 0;  @endphp
                                @foreach ($data as $key => $value)
                                    @php $logdate = $value->logdate;  @endphp
                                    <tr>
                                        <td class="py-1"> {{ ++ $i}}</td>
                                        <td> {{ date('d-M-Y', strtotime($logdate))}} </td>
                                        <td> {{ date('l', strtotime($logdate));  }} </td>
                                        <td> {{ date('g:i', strtotime($value->firstlogin)) }}
                                        <td>
                                            @php if($value->latestar > 0){
                                                  $latestar = $latestar + $value->latestar;
                                            @endphp
                                                    <i class="mdi mdi-star icon-sm text-info"></i>{{ $value->latestar }}
                                            @php } @endphp

                                        </td>
                                        <td> {{ isset($value->lastlogout) ? date('g:i', strtotime($value->lastlogout)) : '' }} </td>
                                        <td>
                                            @php if($value->earlystar > 0){
                                              $earlystar = $earlystar + $value->earlystar;
                                            @endphp
                                                <i class="mdi mdi-star icon-sm text-danger"></i>{{ $value->earlystar }}
                                            @php } @endphp
                                        </td>
                                        <td>
                                            @php if($value->latestar > 0){
                                               @endphp
                                            <label class="badge badge-gradient-danger">LATE</label>
                                            @php } @endphp
                                            @php if($value->earlystar > 0){
                                            @endphp
                                            <label class="badge badge-gradient-success">EARLY</label>
                                            @php } @endphp
                                        </td>
                                    </tr>
                                @endforeach
                                <tr class="table-warning">
                                    <th></th>
                                    <th rowspan="3">Total Marks<i class="mdi mdi-star icon-sm text-success"></i></th>
                                    <th rowspan="2">{{$latestar + $earlystar}}</th>
                                    <th>Late Marks<i class="mdi mdi-star icon-sm text-info"></i></th>
                                    <td>{{ $latestar }}</td>
                                    <th>Early Marks<i class="mdi mdi-star icon-sm text-danger"></i></th>
                                    <td>{{ $earlystar }}</td>
                                    <td></td>
                                </tr>
                                 </tbody>
                            </table>
                        </div>
                    </div>

                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
