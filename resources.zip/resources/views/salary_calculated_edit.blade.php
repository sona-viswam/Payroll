<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <form class="form-sample" action="{{ route('calculated_salary_update', $data[0]->id) }}" enctype="multipart/form-data" method="post">@csrf
{{--                                <p class="card-description"> Personal info </p>--}}
                                @include('message')
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Employee Name</label>
                                            <div class="col-sm-8">
                                                <input name="employeename" type="text" class="form-control" value="{{$data[0]->remployee->firstname." ".$data[0]->remployee->secondname}}" readonly="readonly" />
                                                <input type="hidden" name="employee" value="{{ $data[0]->employee }}">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Basic Salary</label>
                                            <div class="col-sm-8">
                                                <input name="basic_salary" type="number" class="form-control" value="{{ $data[0]->basic_salary }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Holiday</label>
                                            <div class="col-sm-8">
                                                <input name="holiday" type="number" class="form-control" value="{{ $data[0]->holiday }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Monthly Allowed Leave</label>
                                            <div class="col-sm-8">
                                                <input name="monthly_allowed_leave" type="number" class="form-control" value="{{ $data[0]->monthly_allowed_leave }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Carry Forward Leave</label>
                                            <div class="col-sm-8">
                                                <input name="carryforward_leave" type="number" class="form-control" value="{{ $data[0]->carryforward_leave }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Total Leave</label>
                                            <div class="col-sm-8">
                                                <input name="total_leave" type="number" class="form-control" value="{{ $data[0]->total_leave }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Leave Taken</label>
                                            <div class="col-sm-8">
                                                <input name="leave_taken" type="number" class="form-control" value="{{ $data[0]->leave_taken }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Used Casual Leave</label>
                                            <div class="col-sm-8">
                                                <input name="used_casualleave" type="number" class="form-control" value="{{ $data[0]->used_casualleave }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Blackstar</label>
                                            <div class="col-sm-8">
                                                <input name="blackstar" type="number" class="form-control" value="{{ $data[0]->blackstar }}" readonly="readonly"  />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Blackstar Lop</label>
                                            <div class="col-sm-8">
                                                <input name="blackstar_lop" type="number" class="form-control" value="{{ $data[0]->blackstar_lop }}"  readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Leave Lop</label>
                                            <div class="col-sm-8">
                                                <input name="leave_lop" type="number" class="form-control" value="{{ $data[0]->leave_lop }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Total Lop Days</label>
                                            <div class="col-sm-8">
                                                <input name="total_lop_days" type="number" class="form-control" value="{{ $data[0]->total_lop_days }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Lop Amount</label>
                                            <div class="col-sm-8">
                                                <input name="lop_amount" type="number" class="form-control" value="{{ $data[0]->lop_amount }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Salary</label>
                                            <div class="col-sm-8">
                                                <input name="salary" type="number" class="form-control" value="{{ $data[0]->salary }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Incentive</label>
                                            <div class="col-sm-8">
                                                <input name="other" type="number" class="form-control" value="{{ $data[0]->other }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Net Salary</label>
                                            <div class="col-sm-8">
                                                <input name="net_salary" type="number" class="form-control" value="{{ $data[0]->net_salary }}" readonly="readonly" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                <div class="col-md-10">
                                    <div class="form-group row">
                                        <div class="col-sm-4"></div>
                                        <div class="col-sm-5">
                                            <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                                            <button class="btn btn-light">Cancel</button>
                                        </div>
                                    </div>
                                </div>

                        </div>


                            </form>
                        </div>
                    </div>
                </div>




            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
