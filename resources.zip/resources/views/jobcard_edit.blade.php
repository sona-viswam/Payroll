<!DOCTYPE html>
<html lang="en">
@include('header')
@include('myjobcard_js')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <form class="form-sample" action="{{ route('jobcard_update', $data[0]->id) }}" method="post">@csrf
                                <p class="card-description">
                                </p>
                                @include('message')
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Activity</label>
                                            <div class="col-sm-9">
                                                <input name="activity" type="text" value = "{{ $data[0]->ractivity->activity }}"
                                                       class="form-control" readonly />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Activity</label>
                                            <div class="col-sm-9">
                                                <input name="employee" type="text" value = "{{ $data[0]->remployee->fullname }}"
                                                       class="form-control" readonly />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Client</label>
                                            <div class="col-sm-9">
                                                <input name="employee" type="text" value = "{{ $data[0]->rclient->client }}"
                                                       class="form-control" readonly />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Project</label>
                                            <div class="col-sm-9">
                                                <input name="type1" type="text" value = "{{ $data[0]->rproject->project }}"
                                                       class="form-control" readonly />
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                @php
                                if(($data[0]->type2) >0){
                                    $module = $data[0]->rmodule->modulename;
                                }else{
                                    $module = '';
                                }

                                if(($data[0]->type3) >0){
                                    $submodule = $data[0]->rsubmodule->modulename;
                                }else{
                                    $submodule = '';
                                }
                                @endphp

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Module</label>
                                            <div class="col-sm-9">
                                                <input name="type2" type="text" value = "{{ $module }}"
                                                       class="form-control" readonly />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">SubModule</label>
                                            <div class="col-sm-9">
                                                <input name="type3" type="text" value = "{{ $submodule }}"
                                                       class="form-control" readonly />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @php
                                    $yesterday = Carbon\Carbon::yesterday()->toDateString();
                                @endphp
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Start Time</label>
                                            <div class="col-sm-9">
                                                <input value="{{ date('Y-m-d\TH:i', strtotime($data[0]->starttime)) }}" name="starttime" id="starttime"
                                                       type="datetime-local" min ="{{$yesterday}}" class="form-control"
                                                       onchange ="timecalculation();"
                                                       readonly/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">End Time</label>
                                            <div class="col-sm-9">
                                                <input value="{{ date('Y-m-d\TH:i', strtotime($data[0]->endtime)) }}" name="endtime"  id="endtime"
                                                       type="datetime-local" min ="{{$yesterday}}" class="form-control"
                                                       onchange ="timecalculation();"
                                                       readonly/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @php
                                    function secondsToTime($minutes) {
                                        $d = floor ($minutes / 1440);
                                        $h = floor (($minutes - $d * 1440) / 60);
                                        $m = $minutes - ($d * 1440) - ($h * 60);
                                        return "$d days, $h hours, $m minutes";
                                    }
                                @endphp
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Time Taken</label>
                                            <div class="col-sm-9">
                                                <input name="timetaken" id="timetaken" type="text" value = "{{ $data[0]->timetaken }}"
                                                       class="form-control" readonly />
                                                <input name="oldtimetaken" type="hidden" value = "{{ $data[0]->timetaken }}" />
                                                <input name="cost" type="hidden" value = "{{ $data[0]->cost }}" />
                                                @if ($errors->has('timetaken'))
                                                    <span class="text-sm text-danger">{{ $errors->first('timetaken') }}</span>
                                                @endif
                                                <label class="col-sm-9 col-form-label" id="timelabel">{{ secondsToTime($data[0]->timetaken) }}</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Status</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="status">
                                                    <option value="2" {{ ($data[0]->status ==2) ? 'selected' : '' }}>Verified</option>
                                                    <option value="3" {{ ($data[0]->status ==3) ? 'selected' : '' }}>Approved</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="content">Description</label>
                                    <textarea id="description" name="description" rows="4" cols="50"
                                              class="form-control" readonly>{{ $data[0]->description }}</textarea>
                                </div>




                                <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label"></label>
                                        <div class="col-sm-9">
                                            <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                                            <a class="btn btn-light" href="{{url('jobcard')}}">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                        </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
