<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
@include('box')
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <div style="position: absolute;right:10px;top:25px;">
                                <a class="btn btn-gradient-primary mr-2" href="{{url('device_add')}}">+ Add</a>
                            </div>
                            <p class="card-description">
                                {{--                                Add class <code>.table-striped</code>--}}

                            </p>
                            @include('message')
                            <table class="table table-info">
                                <thead>
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span> #</th>
                                    <th> Name </th>
                                    <th> Serial No </th>
                                    <th> IP Address </th>
                                    <th> Port </th>
                                    <th> Status </th>
                                    <th> Type </th>
                                    <th> Tools </th>
                                </tr>
                                </thead>
                                <tbody>
                                @php $i = $data->perPage() * ($data->currentPage() - 1); @endphp
                                @foreach ($data as $key => $value)
                                    <tr>
                                        <td class="py-1"> {{ ++ $i}}</td>
                                        <td> {{ $value->name }} </td>
                                        <td> {{ $value->serialno }} </td>
                                        <td> {{ $value->ip }} </td>
                                        <td> {{ $value->port }} </td>
                                        <td> {{ $value->status }} </td>
                                        <td>
                                            @switch($value->type)
                                                @case('1')
                                                Login
                                                @break
                                                @case('2')
                                                Logout
                                                @break
                                                @default
                                                Both
                                            @endswitch
                                        </td>
                                        <td>
                                            @if($value->id > 2)
                                            <a href="{{ route('device_edit', ['id' => $value->id]);}}">
                                                    <span class="page-title-icon bg-gradient-success text-white mr-2">
                                                    <i class="mdi mdi-table-edit"></i>
                                                    </span>
                                            </a>
                                            @endif
                                            @if($value->id > 2)
                                            <a title="Delete" href="#" onclick="showBox(this,'{{ route('device_delete', ['id' => $value->id]);}}')">
                                                <span class="page-title-icon bg-gradient-danger text-white mr-2">
                                                    <i class="mdi mdi-delete-forever"></i>
                                                </span>
                                            </a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                                 </tbody>
                            </table>
                            <table class="table">
                                <tr><td>{!! $data->links() !!} </td></tr>
                            </table>
                        </div>
                    </div>

                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
