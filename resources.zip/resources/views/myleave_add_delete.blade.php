<!DOCTYPE html>
<html lang="en">
@include('header')
@include('leavedatechange_js')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <form class="form-sample" action="{{ route('sendEmail') }}" method="post">@csrf
                                <p class="card-description">
                                <ul class="list-star">
                                    <li class="text-dark bold">
                                        Application for Earned leave or EL shall be submitted at least {{ $el_limit }} days before
                                        the date from which leave is required.
                                    </li>
                                    <li>Your leaves can be accumulate upto to new financial year.</li>
                                    <li class="text-dark bold">
                                        Your balance CL is <span class="text-info bold">{{$balanceCL}}</span> days
                                        and EL is <span class="text-info bold">{{$balanceEL}}</span> days.
                                    </li>
                                </ul>
                                </p>
                                @include('message')
                                @if ($errors->has('employee'))
                                    <div class="alert alert-danger alert-block">
                                        <button type="button" class="close icon-sm" data-dismiss="alert">×</button>
                                        {{ $errors->first('employee') }}
                                    </div>
                                @endif
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Type</label>
                                            <div class="col-sm-4">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="type" id="type" value="1" {{ (old('type') == 1) ? 'checked' : '' }} onclick="cldate();"> CL <i class="input-helper"></i></label>
                                                </div>
                                            </div>
                                            <div class="col-sm-5">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="type" id="type" value="2" {{ (old('type') == 2) ? 'checked' : '' }}  onclick="eldate();"> EL <i class="input-helper"></i></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Start Date</label>
                                            <div class="col-sm-9">
                                                @php
                                                    $today = Carbon\Carbon::today()->toDateString();
                                                    $yesterday = Carbon\Carbon::yesterday()->toDateString();
                                                @endphp
                                                <input value="{{ old('ldate')}}" name="ldate"
                                                       id="ldate" type="date"
                                                       min ="{{$yesterday}}"
                                                       max ="{{$today}}"
                                                       class="form-control" />
                                                @if ($errors->has('ldate'))
                                                    <span class="text-sm text-danger">{{ $errors->first('ldate') }}</span>
                                                @endif
                                                <input type="hidden" id="employee" name="employee" value="{{auth()->id()}}">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
{{--                                    <div class="col-md-6">--}}
{{--                                        <div class="form-group row">--}}
{{--                                            <label class="col-sm-3 col-form-label">End Date</label>--}}
{{--                                            <div class="col-sm-9">--}}
{{--                                                <input name="ldate2" min ="{{$today}}"  type="date" class="form-control" />--}}
{{--                                                @if ($errors->has('ldate'))--}}
{{--                                                    <span class="text-danger">{{ $errors->first('ldate2') }}</span>--}}
{{--                                                @endif--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Day</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="daytype">
                                                    <option value="1.0" {{ (old('daytype') == 1.0 ) ? 'selected' : '' }}>Full Day</option>
                                                    <option value="0.5" {{ (old('daytype') == 0.5 ) ? 'selected' : '' }}>Half Day</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6" id="bemployeeDiv" style="display:none">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Backup Employee</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="bemployee">
                                                    @foreach ($user as $key => $value)
                                                        <option value="{{ $value->id }}" {{ (old('bemployee') == $value->id ) ? 'selected' : '' }}>{{ $value->fullname }}</option>
                                                    @endforeach
                                                </select>
                                                @if ($errors->has('employee'))
                                                    <span class="text-sm text-danger">{{ $errors->first('bemployee') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="content">Subject</label>
                                    <input type="text" class="form-control" name="subject" value="{{ old('subject') }}">
                                    @if ($errors->has('subject'))
                                        <span class="text-sm text-danger">{{ $errors->first('subject') }}</span>
                                    @endif

                                </div>

                                <div class="form-group">
                                    <label for="content">Reason for Leave</label>
                                    <textarea id="w3review" name="content" rows="4" cols="50" class="form-control">{{ old('content')  }}</textarea>
                                    @if ($errors->has('content'))
                                        <span class="text-sm text-danger ">{{ $errors->first('content') }}</span>
                                    @endif
                                </div>

                                <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label"></label>
                                        <div class="col-sm-9">
                                            <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                                            <a class="btn btn-light" href="{{url('myleave')}}">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                        </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
