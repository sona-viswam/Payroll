
<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        @include('side_menu')
        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                   <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span>  {{ isset($heading) ? $heading : '' }}
                    </h3>
                    @php
                        $today = Carbon\Carbon::now();
                    @endphp
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item active" aria-current="page">
                                <span></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="row">

                    <div class="col-md-4 stretch-card grid-margin">
                        <div class="card bg-gradient-primary card-img-holder text-white">
                            <div class="card-body">
                                <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                                <h4 class="font-weight-normal mb-3">Current Employees <i class="mdi mdi-bookmark-outline mdi-24px float-right"></i>
                                </h4>
                                <h2 class="mb-5">{{ isset($total) ? $total : '' }}</h2>
                                <h6 class="card-text">Cent Percentage 100%</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 stretch-card grid-margin">
                        <div class="card bg-gradient-success card-img-holder text-white">
                            <div class="card-body">
                                <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                                <h4 class="font-weight-normal mb-3">Present <i class="mdi mdi-diamond mdi-24px float-right"></i>
                                </h4>
                                <h2 class="mb-5">{{ isset($present) ? $present : '' }}</h2>
                                @php
                                    if (!empty($total)){
                                        $percentage = round(($present/$total) * 100);
                                        if($present === $total){
                                            $presentTxt =   "Increased by " .$percentage." %";
                                        }else{
                                            $presentTxt =   "Decreased to " .$percentage." %";
                                        }
                                        $absentpercentage = round(($absent/$total) * 100) ;
                                    }else{
                                        $presentTxt = "Decreased to 0%";
                                        $absentpercentage =  0;
                                    }
                                @endphp
                                <h6 class="card-text"> {{ $presentTxt }}</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 stretch-card grid-margin">
                        <div class="card bg-gradient-danger card-img-holder text-white">
                            <div class="card-body">
                                <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                                <h4 class="font-weight-normal mb-3">Absent / Leave<i class="mdi mdi-chart-line mdi-24px float-right"></i>
                                </h4>
                                <h2 class="mb-5">{{ isset($absent) ? $absent : '' }}</h2>
                                <h6 class="card-text">Increased by  {{ $absentpercentage }}%</h6>
                            </div>
                        </div>
                    </div>
                </div>
                @if ( Auth::user()->isAdmin() )
                    @if(!empty($data) && $data->count())
                        <div class="row">
                            <div class="col-12 grid-margin">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                                        <div class="table-responsive">
                                            <table class="table">
                                                @if(!empty($data) && $data->count())
                                                    <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th> Employee </th>
                                                        <th> Designation </th>
                                                        <th> Details </th>
                                                        <th> Status </th>
                                                        <th></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                     @foreach ($data as $key => $value)
                                                        <tr>
                                                            <td>{{ $key +1}}</td>
                                                            <td>
                                                                @php
                                                                    $photoName = $value->photo;
                                                                    if($photoName){
                                                                        $photo = asset('upload/'.$photoName);
                                                                    }else{
                                                                        $photo =  asset('assets/images/faces-clipart/pic-1.png');
                                                                    }
                                                                @endphp
                                                                <img src="{{ $photo }}" class="mr-2" alt="image" />
                                                                {{ $value->fullname }}
                                                            </td>
                                                            <td>
                                                                @if( $value->designations()->exists() )
                                                                    {{ $value->designations()->orderByDesc('id')->first()->designation }}
                                                                @endif

                                                            </td>
                                                            <td>
                                                                <a href="{{ route('viewEmployee', ['id' => $value->id]);}}" title="Employee Details">
                                                            <span class="page-title-icon bg-gradient-success text-white mr-2">
                                                              <i class="mdi mdi-account-card-details"></i>
                                                            </span>
                                                                </a>
                                                            </td>
                                                            <td>
                                                                <label class="badge badge-gradient-danger">ABSENT</label>
                                                            </td>
                                                            <td>
                                                                <a href="{{ route('absent_view', ['id' => $value->id]);}}" title="Details">
                                                            <span class="page-title-icon bg-gradient-info text-white mr-2">
                                                              <i class="mdi mdi mdi-eye"></i>
                                                            </span>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                    </tbody>
                                                @else
                                                    <tr>
                                                        <td colspan="2" align="center">No Absent</td>
                                                    </tr>
                                                @endif
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                    @if(!empty($data4) && $data4->count())
                        <div class="row">
                            <div class="col-12 grid-margin">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Leave Today</h4>
                                        <div class="table-responsive">
                                            <table class="table">
                                                @if(!empty($data4) && $data4->count())
                                                    <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th> Employee </th>
                                                        <th> Designation </th>
                                                        <th> Details </th>
                                                        <th> Status </th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    @foreach ($data4 as $key => $value)
                                                        <tr>
                                                            <td>{{ $key +1}}</td>
                                                            <td>
                                                                @php
                                                                    $photoName = $value->remployee->photo;
                                                                    if($photoName){
                                                                        $photo = asset('upload/'.$photoName);
                                                                    }else{
                                                                        $photo =  asset('assets/images/faces-clipart/pic-1.png');
                                                                    }
                                                                @endphp
                                                                <img src="{{ $photo }}" class="mr-2" alt="image" />
                                                                {{ $value->remployee->fullname }}
                                                            </td>
                                                            <td>
                                                                @if( $value->remployee->designations()->exists() )
                                                                    {{ $value->remployee->designations()->orderByDesc('id')->first()->designation }}
                                                                @endif

                                                            </td>
                                                            <td>
                                                                <a href="{{ route('viewEmployee', ['id' => $value->id]);}}" title="Details">
                                                <span class="page-title-icon bg-gradient-success text-white mr-2">
                                                  <i class="mdi mdi mdi-eye"></i>
                                                </span>
                                                                </a>
                                                            </td>
                                                            <td>
                                                                <label class="badge badge-gradient-danger">LEAVE</label>
                                                            </td>
                                                            <td>
                                                                <a href="{{ route('leave_view', ['id' => $value->id]);}}" title="Details">
                                                            <span class="page-title-icon bg-gradient-info text-white mr-2">
                                                              <i class="mdi mdi mdi-eye"></i>
                                                            </span>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                    </tbody>
                                                @else
                                                    <tr>
                                                        <td colspan="2" align="center">No Leave</td>
                                                    </tr>
                                                @endif
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                    @if(!empty($data5) && $data5->count())
                        <div class="row">
                            <div class="col-12 grid-margin">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Upcoming Leaves</h4>
                                        <div class="table-responsive">
                                            <table class="table">
                                                @if(!empty($data5) && $data5->count())
                                                    <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th> Employee </th>
                                                        <th> Start Date </th>
                                                        <th> End Date </th>
                                                        <th> Type </th>
                                                        <th> Day </th>
                                                        <th> Applied On </th>
                                                        <th> Status </th>
                                                        <th></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    @foreach ($data5 as $key => $value)
                                                        <tr>
                                                            <td class="py-1"> {{ $key +1}}</td>
                                                            <td> {{ $value->remployee->fullname }} </td>
                                                            <td> {{ date('d-m-Y', strtotime($value->ldate)) }}</td>
                                                            <td>{{ isset($value->ldate2) ? date('d-m-Y', strtotime($value->ldate2)) : '' }}</td>
                                                            <td>
                                                                @if ($value->type == 1)
                                                                    CL
                                                                @else
                                                                    EL
                                                                @endif
                                                            </td>
                                                            <td>
                                                                @if ($value->daytype < 1)
                                                                    Half Day
                                                                @else
                                                                    Full Day
                                                                @endif
                                                            </td>
                                                            <td> {{ isset($value->created_at) ? date('d-m-Y', strtotime($value->created_at)) : '' }}</td>
                                                            <td>
                                                                @switch($value->status)
                                                                    @case('1')
                                                                    <label class="badge badge-gradient-warning">PROGRESS</label>
                                                                    @break
                                                                    @case('2')
                                                                    <label class="badge badge-gradient-success">APPROVED</label>
                                                                    @break
                                                                    @case('5')
                                                                    <label class="badge badge-gradient-danger" title="{{$value->reason}}">REJECTED</label>
                                                                    @break
                                                                    @default
                                                                    <label class="badge badge-gradient-info">ON HOLD</label>
                                                                @endswitch
                                                            </td>
                                                            <td>
                                                                <a href="{{ route('leave_view', ['id' => $value->id]);}}" title="Details">
                                                <span class="page-title-icon bg-gradient-info text-white mr-2">
                                                  <i class="mdi mdi mdi-eye"></i>
                                                </span>
                                                                </a>
                                                                @php $nowDate = Carbon\Carbon::now() @endphp
                                                                @if (($nowDate <= $value->ldate) || ($value->status <> 2) )
                                                                    <a href="{{ route('casualleave_edit', ['id' => $value->id]);}}" title="Edit">
                                                    <span class="page-title-icon bg-gradient-primary text-white mr-2">
                                                    <i class="mdi mdi-table-edit"></i>
                                                    </span>
                                                                    </a>
                                                                @endif
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                    </tbody>
                                                @else
                                                    <tr>
                                                        <td colspan="2" align="center">No Leave</td>
                                                    </tr>
                                                @endif
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                @endif

                @if ( Auth::user()->isUser() )
                    <canvas id="visit-sale-chart" style="display: none;"></canvas>
                    <div class="row">
                        <div class="col-md-5 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body"><div class="chartjs-size-monitor"><div class="chartjs-size-monitor-expand"><div class=""></div></div><div class="chartjs-size-monitor-shrink"><div class=""></div></div></div>
                                    <h4 class="card-title">Attendance</h4>


                                    <canvas id="traffic-chart" width="305" height="152" style="display: block; width: 305px; height: 152px;" class="chartjs-render-monitor"></canvas>
                                    <div id="traffic-chart-legend" class="rounded-legend legend-vertical legend-bottom-left pt-4">
                                        <ul>
                                            <li><span class="legend-dots" style="background:linear-gradient(to right, rgba(54, 215, 232, 1), rgba(177, 148, 250, 1))"></span>
                                                Month<span class="float-right" id="val1">{{ $month_percentage }}</span>%</li>
                                            <li><span class="legend-dots" style="background:linear-gradient(to right, rgba(6, 185, 157, 1), rgba(132, 217, 210, 1))"></span>
                                                Present<span class="float-right" id="val2">{{$present_percentage}}</span>%</li>
                                            <li><span class="legend-dots" style="background:linear-gradient(to right, rgba(255, 191, 150, 1), rgba(254, 112, 150, 1))"></span>
                                                Absent<span class="float-right" id="val3">{{$absent_percentage}}</span>%</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-7 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Holidays</h4>
                                    <div class="table-responsive">
                                        <table class="table">
                                            @if(!empty($array) && $array->count())
                                                <thead>
                                                <tr>
                                                    <th> # </th>
                                                    <th> Title </th>
                                                    <th> Date </th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                @foreach ($array as $key => $value)
                                                    @php
                                                        $hdate = $value->hdate;
                                                    @endphp
                                                    <tr class="{{ ($hdate < $today) ? 'text-secondary' : '' }}">
                                                        <td>{{ $key +1}} </td>
                                                        <td> {{ $value->hname }} </td>
                                                        <td>  {{ date('M d, Y', strtotime($hdate)); }} </td>
                                                    </tr>
                                                @endforeach
                                                </tbody>
                                            @else
                                                <tr>
                                                    <td colspan="2" align="center" class="text-secondary">No Holiday</td>
                                                </tr>
                                            @endif
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                @if ( Auth::user()->isAdmin() )
                    @php $colours = array('primary','success','danger','warning','info'); @endphp
                <div class="row">
                    @if(!empty($data6) && $data6->count())
                    <div class="col-md-6 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Yesterday' Project Status
                                    @if($yesterday_pending >0)
                                        <i class="mdi mdi-star icon-sm text-danger align-top"></i></td>
                                    @endif
                                    </h4>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th> # </th>
                                            <th> Name </th>
                                            <th> % </th>
                                            <th> Time Spent   {{ $data6->sum->total_time }}</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach ($data6 as $key => $value)
                                            @php $mycolour = $colours[array_rand($colours, 1)]; @endphp
                                        <tr>
                                            <td> {{ $key +1 }} </td>
                                            <td>
                                                @if(empty($value->type1))
                                                    Other
                                                @else
                                                    {{ $value->rproject->project }}
                                                @endif
                                            </td>
                                            <td>{{ $percent =  number_format((float)(($value->total_time/ $yesterday_totaltime)*100), 2, '.', '') }} </td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar bg-gradient-{{$mycolour}}" role="progressbar" style="width: {{$percent}}%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </td>
                                        </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                    @if(!empty($data7) && $data7->count())
                    <div class="col-md-6 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Last Week Project Status
                                    @if($lastweek_pending >0)
                                        <i class="mdi mdi-star icon-sm text-danger align-top"></i></td>
                                    @endif
                                </h4>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th> # </th>
                                            <th> Name </th>
                                            <th> % </th>
                                            <th> Time Spent </th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach ($data7 as $key => $value)
                                            @php $mycolour = $colours[array_rand($colours, 1)]; @endphp
                                            <tr>
                                                <td> {{ $key +1 }} </td>
                                                <td>
                                                    @if(empty($value->type1))
                                                        Other
                                                    @else
                                                        {{ $value->rproject->project }}
                                                    @endif
                                                </td>
                                                <td> {{ $percent =  number_format((float)(($value->total_time/ $lastweek_totaltime)*100), 2, '.', '') }} </td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar bg-gradient-{{$mycolour}}" role="progressbar" style="width: {{$percent}}%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" title="123"></div>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
                @endif
{{--                <div class="row">--}}
{{--                    <div class="col-md-7 grid-margin stretch-card">--}}
{{--                        <div class="card">--}}
{{--                            <div class="card-body">--}}
{{--                                <div class="clearfix">--}}
{{--                                    <h4 class="card-title float-left">Visit And Sales Statistics</h4>--}}
{{--                                    <div id="visit-sale-chart-legend" class="rounded-legend legend-horizontal legend-top-right float-right"></div>--}}
{{--                                </div>--}}
{{--                                <canvas id="visit-sale-chart" class="mt-4"></canvas>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}


            </div>
            <!-- content-wrapper ends -->
            <!-- partial:partials/_footer.html -->
            @include('footer')
            <!-- partial -->
        </div>
        <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<!-- plugins:js -->
@include('js')
</body>
</html>

