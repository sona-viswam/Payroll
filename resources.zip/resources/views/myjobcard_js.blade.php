<script type="text/javascript">
    function projects(){
        var val = $("#activity").val();
        if(val==1) {
            $("#type2").html('');
            $("#type3").html('');
            $("#client").val('');
            var url = '{{ route('fetch_project') }}';
            var resultid = 'type1';
            var inputKey = 'project';
            getValues(val, url, inputKey, resultid);
        }
    }
    function myprojects(){
        $("#type2").html('');
        $("#type3").html('');
        var val = $("#client").val();
        var url = '{{ route('fetch_clientproject') }}';
        var resultid = 'type1';
        var inputKey = 'project';
        getValues(val, url, inputKey, resultid);

    }
    function mymodules(){
        $("#type3").html('');
        var val = $("#type1").val();
        var url = '{{ route('fetch_module') }}';
        var resultid = 'type2';
        var inputKey = 'modulename';
        getValues(val, url, inputKey, resultid);
    }
    function mysubmodules(){
        var val = $("#type2").val();
        var url = '{{ route('fetch_submodule') }}';
        var resultid = 'type3';
        var inputKey = 'modulename';
        getValues(val, url, inputKey, resultid);
    }

    function getValues(val, url, inputKey, resultid){
        var valInput = $("input[name=_token]").val();
        var myresult = '<option value=""> --  Select  -- </option>';
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': valInput
            },
            type:'POST',
            url: url,
            data:{ input:val },
            dataType: 'json',
            success:function(result){
                $.each(result.module, function (key, value) {
                    myresult = myresult + '<option value="' + value.id + '">'
                          + value[inputKey] + '</option>';
                });
                $("#"+resultid).html(myresult);
            },
            error: function (data) {
                console.log(data);
            }
        });

    }

    function timecalculation(){
        var work_starttime = $('#work_starttime').val();
        var work_endtime = $('#work_endtime').val();
        if(Date.parse(work_endtime) > Date.parse(work_starttime) > true){
                $('#errorDiv').show();
                return false;
        }
        if (work_endtime !== '') {
            var diff = new Date(work_endtime) - new Date(work_starttime);
            var diffDays = Math.floor(diff / 86400000); // days
            var diffHrs = Math.floor((diff % 86400000) / 3600000); // hours
            var diffMins = Math.round(((diff % 86400000) % 3600000) / 60000); // minutes
            var showtime = diffDays + " days, " + diffHrs + " hours, " + diffMins +" minutes ";
            var minutes = Math.floor(diff/60000);
            $('#timetaken').val(minutes);
            $('#timelabel').html(showtime);
        }
    }

</script>
