<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>

                            <p class="card-description">
{{--                                Add class <code>.table-striped</code>--}}
                            </p>
                            <table class="table table-striped">
                                <thead>
                                </thead>
                                <tr>
                                    <td class="font-weight-bold"> First Name </td><td>{{ $data[0]->firstname }}</td>
                                    <td class="font-weight-bold"> Second Name </td><td>{{ $data[0]->secondname }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> UserName </td><td>{{ $data[0]->username }}</td>
                                    <td class="font-weight-bold"> Password </td><td>******</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Gender </td><td>
                                        @switch($data[0]->gender)
                                            @case(1)
                                                Male
                                                @break
                                            @case(2)
                                                Female
                                                @break
                                            @default
                                                Other
                                        @endswitch
                                    </td>
                                    <td class="font-weight-bold"> DOB </td><td>
                                        @if(empty($data[0]->dob ))

                                        @else
                                            {{date('d-M-Y', strtotime($data[0]->dob))}}
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Qualification </td><td>{{ $data[0]->qualification }}</td>
                                    <td class="font-weight-bold"> Email </td><td>{{ $data[0]->email }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Permanent Address </td><td>{{ $data[0]->permanentaddress }}</td>
                                    <td class="font-weight-bold"> Temporary Address </td><td>{{ $data[0]->temporaryaddress }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> City </td><td>{{ $data[0]->city }}</td>
                                    <td class="font-weight-bold"> Country </td><td>{{ $data[0]->rcountry->name }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Pin </td><td>{{ $data[0]->pin }}</td>
                                    <td class="font-weight-bold"> Phone </td><td>{{ $data[0]->phone }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Mobile </td><td>{{ $data[0]->mobile }}</td>
                                    <td class="font-weight-bold"> Identity No. </td><td>{{ $data[0]->identityno }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Photo </td>
                                    <td>
                                        @php
                                            $photoName = $data[0]->photo;
                                            if($photoName){
                                                $photo = asset('upload/'.$photoName);
                                            }else{
                                                $photo =  asset('assets/images/faces-clipart/pic-1.png');
                                            }
                                        @endphp

                                        <img src="{{ $photo }}" alt="image" />
                                    </td>
                                    <td class="font-weight-bold"> Identity Image </td>
                                    <td>
                                        @php
                                            $photoName = $data[0]->identityimage;
                                            if($photoName){
                                                $photo = asset('upload/'.$photoName);
                                            }else{
                                                $photo =  asset('assets/images/faces-clipart/pic-1.png');
                                            }
                                        @endphp

                                        <img src="{{ $photo }}" alt="image" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Hire Date </td><td> {{ date('d-M-Y', strtotime($data[0]->hiredate)); }}</td>
                                    <td class="font-weight-bold"> Last Date </td><td>
                                        @if(empty($data[0]->lastdate ))

                                        @else
                                           {{date('d-M-Y', strtotime($data[0]->lastdate))}}
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Status </td><td>{{ ($data[0]->status =='1') ? 'Active' : 'Suspend' }}</td>
                                    <td class="font-weight-bold"></td><td></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Designation</td><td>{{$data[0]->designations()->orderByDesc('id')->first()->designation}}</td>
                                    <td class="font-weight-bold">Department</td><td>{{$data[0]->departments()->orderByDesc('id')->first()->department}}</td>
                                </tr>

                                <tr>
                                    <td class="font-weight-bold">Basic Salary</td><td>{{$data[0]->salarys()->orderByDesc('id')->first()->basicsalary}}</td>
                                    <td class="font-weight-bold">Shift</td><td>{{$data[0]->shifts()->orderByDesc('id')->first()->shiftname }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>




            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
