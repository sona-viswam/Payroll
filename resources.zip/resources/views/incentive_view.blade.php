<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>

                            <p class="card-description">
{{--                                Add class <code>.table-striped</code>--}}
                            </p>
                            <table class="table table-striped">
                                <thead>
                                </thead>
                                <tr>
                                    <td class="font-weight-bold"> Employee Name </td><td>{{ $data[0]->remployee->fullname; }}</td>
                                    <td class="font-weight-bold"> Photo </td>
                                    <td>
                                        @php
                                            $photoName = $data[0]->remployee->photo;
                                            if($photoName){
                                                $photo = asset('upload/'.$photoName);
                                            }else{
                                                $photo =  asset('assets/images/faces-clipart/pic-1.png');
                                            }
                                        @endphp
                                        <img src="{{ $photo }}" alt="image" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Incentive </td><td>{{ $data[0]->amount }}</td>
                                    <td class="font-weight-bold"> Date </td><td>{{ date('d M Y', strtotime($data[0]->idate)) }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Title </td><td>{{ $data[0]->title }}</td>
                                    <td class="font-weight-bold">  </td><td></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>




            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
