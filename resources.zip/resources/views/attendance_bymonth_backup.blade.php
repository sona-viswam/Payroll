<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <p class="card-description"> {{$today}} </p>
                            <p class="card-description">
                            </p>
{{--@dd($leave->toArray())--}}
@php
$leaveArr = $leave->toArray();
$holidayArr = $holiday->toArray();

$searchkey = "2021-11-04";
    if(array_key_exists($searchkey, $leaveArr)) {
      echo "";
    }
@endphp
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span>#</th>
                                    <th> Date </th>
                                    <th> Log in </th>
                                    <th> Log out </th>
                                </tr>
                                </thead>
                                <tbody>
                                @php
                                    $totstar = $earlystar = $latestar = $i = 0;
                                    $checkVal = 1;
                                @endphp
                                @foreach ($data as $key => $value)
                                    @php
                                        $logdate = $value->logdate;
                                        $firstdate = date('d', strtotime($logdate));
                                        if($checkVal<10){
                                            $checkdate = date('Y-m', strtotime($logdate)).'-0'.$checkVal;
                                        }else{
                                            $checkdate = date('Y-m', strtotime($logdate)).'-'.$checkVal;
                                        }
                                        $thisday = date('l', strtotime($checkdate));
                                    @endphp
                                    @if($checkVal == $firstdate)
                                        <tr>
                                            <td class="py-1"> {{ ++ $i}}</td>
                                            <td> {{ date('d-M-Y', strtotime($logdate))}} </td>
                                            <td> {{ date('g:i', strtotime($value->firstlogin)) }} </td>
                                            <td> {{ date('g:i', strtotime($value->lastlogout)) }} </td>
                                        </tr>
                                    @elseif($thisday == 'Sunday')
                                        <tr class="table-danger">
                                            <td class="py-1"> {{ ++ $i}}</td>
                                            <td colspan=" 3" align="center"> Sunday </td>
                                        </tr>
                                    @elseif(array_key_exists($checkdate, $leaveArr))
                                        <tr class="table-info">
                                            <td class="py-1"> {{ ++ $i}}</td>
                                            <td colspan=" 3" align="center"> Leave </td>
                                        </tr>

                                    @elseif(array_key_exists($checkdate, $holidayArr))
                                        <tr class="table-warning">
                                            <td class="py-1"> {{ ++ $i}}</td>
                                            <td colspan=" 3" align="center"> Holiday </td>
                                        </tr>
                                    @else
                                        <tr>
                                            <td class="py-1"> {{ ++ $i}}</td>
                                            <td> Not correct </td>
                                            <td> LogDate: {{ $logdate }} </td>
                                            <td> CheckDate:{{ $checkdate }} </td>
                                        </tr>
                                    @endif
                                    @php  $checkVal++; @endphp
                                @endforeach
                                 </tbody>
                            </table>

                        </div>
                    </div>

                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
