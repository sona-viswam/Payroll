<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
@include('box')
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            @php
                            $today = Carbon\Carbon::now()->format('Y-m-d');
                            $jid = isset($jobcardid)?$jobcardid:0;
                            @endphp

                            @if ($status <> 3)
                            <div style="position: absolute;right:10px;top:25px;">
                                <a class="btn btn-gradient-primary mr-2" href="{{url('mywork_add', $jobcardid)}}">+ Add</a>
                            </div>
                            @endif
                            <p class="card-description"></p>
                            @include('message')
                            @php
                                $workmin = 0;
                                 if(($login != null) && ($logout != null)){
                                    $to = Carbon\Carbon::parse($login);
                                    $from = Carbon\Carbon::parse($logout);
                                    $workmin = $to->diffInMinutes($from);
                                }
                            @endphp

                            <table class="table table-bordered">
                                <thead>
                                </thead>
                                <tbody>
                                <tr>
                                    <td> Shift Start: </td>
                                    <td>{{ !empty($shiftstarttime) ? date('g:i A', strtotime($shiftstarttime)) : 'Not Updated' }}</td>
                                    <td> Shift End: </td>
                                    <td colspan="2">{{ !empty($shiftendtime) ? date('g:i A', strtotime($shiftendtime)) : 'Not Updated' }} </td>
                                </tr>
                                <tr>
                                    <td> Login: </td>
                                    <td>{{ !empty($login) ? date('g:i A', strtotime($login)) : 'Not Updated' }} </td>
                                    <td> Logout: </td>
                                    <td colspan="2">{{ !empty($logout) ? date('g:i A', strtotime($logout)) : 'Not Updated' }} </>
                                </tr>
                                <tr>
                                    <td> Work Period: </td>
                                    <td class="font-weight-bold" colspan="3">
                                        {{ isset($workmin) ? intdiv($workmin, 60).':'. ($workmin % 60) : 'Not Updated' }}</td>
                                </tr>
                                </tbody>
                            </table>
                            <br>
                            <p>
                                @if ($status == 1)
                                <ul class="list-arrow">
                                    <li>To verify your jobcard</li>
                                    <li>Login and Logout time must update</li>
                                    <li>Start time and End time should come in between login and logout time</li>
{{--                                    <li>Enter all works in between shift duration</li>--}}
                                </ul>
                                @endif
                            </p>
                            <table class="table table-striped">
                                @if ($data->count() > 0 )
                                <thead>
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span>#</th>
                                    <th> Activity </th>
                                    <th> Start Time </th>
                                    <th> End Time </th>
                                    <th> Time </th>
                                    <th> Tools </th>
                                </tr>
                                </thead>
                                <tbody>
                                @php
                                    $i = $tot =0;
                                    $flag = false;
                                    $divClass = '';
                                    $starttime =  \Carbon\Carbon::parse($data[0]->starttime)->format('Y-m-d h:i A');
                                @endphp
                                @foreach ($data as $key => $value)
{{--                                    @dd($value->Employee);--}}
@php

        $jobcardid = $value->jobcardid;
        $minutes = $value->timetaken;
        $hours = intdiv($minutes, 60).':'. ($minutes % 60);
        $tot = $tot + $minutes;
        $this_starttime = $value->starttime;
        if(isset($endtime)){
            if($this_starttime == $endtime){
                $divClass = '';
            }else{
                $flag = true;
                $divClass = 'table-danger';
            }
        }
        $endtime = $value->endtime;
@endphp
                                    <tr class="{{ $divClass }}">
                                        <td class="py-1"> {{ ++ $i}}</td>
                                        <td> {{  $value->ractivity->activity  }} </td>
                                        <td> {{ date('g i A', strtotime($this_starttime)) }}</td>
                                        <td> {{ date('g i A', strtotime($endtime)) }}</td>
                                        <td> {{  $hours  }} </td>
                                        <td>
                                            <a title="Details" href="{{ route('mywork_view', ['id' => $value->id]);}}">
                                                    <span class="page-title-icon bg-gradient-info text-white mr-2">
                                                    <i class="mdi mdi-eye"></i>
                                                    </span>
                                            </a>
                                            @if ($status <> 3)
                                            <a href="{{ route('mywork_edit', ['id' => $value->id]);}}" title="Edit">
                                                <span class="page-title-icon bg-gradient-success text-white mr-2">
                                                    <i class="mdi mdi-table-edit"></i>
                                                </span>
                                            </a>
                                            <a title="Delete" href="#" onclick="showBox(this,'{{ route('mywork_delete', ['id' => $value->id]);}}')">
                                                <span class="page-title-icon bg-gradient-danger text-white mr-2">
                                                    <i class="mdi mdi-delete-forever"></i>
                                                </span>
                                            </a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td class="font-weight-bold"></td>
                                    <td> Total Time: </td>
                                    <td colspan="2" class="font-weight-bold"> {{ intdiv($tot, 60).':'. ($tot % 60) }} </td>
                                </tr>
                                <tr>
                                    @if ($status <> 1)
                                        <th colspan="5"></th>
                                        <th>
                                            @switch($status)
                                                @case('1')
                                                <label class="badge badge-gradient-warning">&emsp;&emsp;DRAFT&emsp;&emsp;</label>                                                @break
                                                @case('2')
                                                <label class="badge badge-gradient-info">&emsp;&emsp;VERIFIED&emsp;&emsp;</label>
                                                @break
                                                @default
                                                <label class="badge badge-gradient-success">&emsp;&emsp;APPROVED&emsp;&emsp;</label>
                                            @endswitch
                                        </th>
                                    @else
@php
    $error = false;
    if($workmin > 0 ){
        $checktime = null;
        $endtime =  \Carbon\Carbon::parse($endtime)->format('Y-m-d h:i A');
        if($login <= $shiftstarttime){
            $checktime = $shiftstarttime;
        }else{
            $checktime = $login;
        }
        if($checktime < $starttime){
            $error = true;
        }

        if($logout < $shiftendtime){
            $checktime = $logout;
        }else{
            $checktime = $shiftendtime;
        }
        if($checktime < $endtime){
            $error = true;
        }
    }
@endphp



                                        <th colspan="3"></th>
                                        <th> Status </th>
                                        <form class="form-sample" action="{{ route('myjobcard_update', $jobcardid) }}" method="post">@csrf
                                            <input name="id" type="hidden" value = "{{ $jobcardid }}" />
                                            <input name="work_period" type="hidden" value = "{{ $workmin }}" />
                                            <input name="total_time" type="hidden" value = "{{ $tot }}" />
                                        <th>
                                            <select class="form-control" name="status">
                                                    <option value="1">Draft</option>
                                                @if(($workmin > 0) && ($starttime >= $login) && ($endtime <= $logout) && ($error == false) && ($flag == false))
                                                    <option value="2">Verified</option>
                                                @endif
                                                </select>
                                            </th><th>
                                                    <button type="submit" class="btn-sm btn-gradient-primary mr-2">Submit</button>
                                            </th>
                                            </form>
                                        @endif
                                    </tr>
                                    @else
                                        <tr>
                                            <td colspan="2" align="center">No Records</td>
                                        </tr>
                                    @endif
                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>

                </div>
                @include('footer')
            </div>
        </div>
    </div>
    @include('js')
    </body>
    </html>
