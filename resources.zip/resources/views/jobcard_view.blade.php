<!DOCTYPE html>
<html lang="en">
@include('header')
@include('myjobcard_js')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                                <p class="card-description">
                                </p>
                            @php
                                function secondsToTime($minutes) {
                                    $d = floor ($minutes / 1440);
                                    $h = floor (($minutes - $d * 1440) / 60);
                                    $m = $minutes - ($d * 1440) - ($h * 60);
                                    return "$d days, $h hours, $m minutes";
                                }
                            @endphp
                            <table class="table table-striped">
                                <thead>
                                </thead>
                                <tr>
                                    <td class="font-weight-bold"> Activity </td><td>{{ $data[0]->ractivity->activity }}</td>
                                    <td class="font-weight-bold"> Employee </td><td>{{ $data[0]->jemployee->fullname }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Client </td><td>
                                        @php
                                            if(($data[0]->client) >0){
                                                $client = $data[0]->rclient->client;
                                            }else{
                                                $client = '';
                                            }
                                        @endphp
                                        {{ $client }}
                                    </td>
                                    <td class="font-weight-bold"> Project </td><td>
                                        @php
                                            if(($data[0]->type1) >0){
                                                $project = $data[0]->rproject->project;
                                            }else{
                                                $project = '';
                                            }
                                        @endphp
                                        {{ $project }}
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Module </td><td>
                                        @php
                                        if(($data[0]->type2) >0){
                                            $module = $data[0]->rmodule->modulename;
                                        }else{
                                            $module = '';
                                        }
                                        @endphp
                                        {{ $module }}
                                    </td>
                                    <td class="font-weight-bold"> SubModule </td><td>
                                        @php
                                            if(($data[0]->type3) >0){
                                                $submodule = $data[0]->rsubmodule->modulename;
                                            }else{
                                                $submodule = '';
                                            }
                                        @endphp
                                        {{ $submodule }}
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Start Time </td><td>{{$data[0]->starttime }}</td>
                                    <td class="font-weight-bold"> End Time </td><td>{{$data[0]->endtime }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Time Taken </td><td>{{ $data[0]->timetaken }}</td>
                                    <td class="font-weight-bold"> Time </td><td>{{ secondsToTime($data[0]->timetaken) }}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Description</td><td>{{$data[0]->description }}</td>

                                </tr>
                                <tr>
                                    <td class="font-weight-bold"> Cost</td><td>Rs. {{ $data[0]->cost }}</td>
                                    <td class="font-weight-bold"> Status </td><td>
                                        @switch($data[0]->status)
                                            @case(1)
                                            Draft
                                            @break
                                            @case(2)
                                            Verified
                                            @break
                                            @default
                                            Approved
                                        @endswitch
                                    </td>
                                </tr>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
