<script type="text/javascript">
    function cldate(){
        var yesterday = addDays(-1);
        var today = addDays(0);
        document.getElementById("ldate").setAttribute("min", yesterday);
        document.getElementById("ldate").setAttribute("max", today);
        document.getElementById("ldate2").setAttribute("min", yesterday);
        document.getElementById("ldate2").setAttribute("max", today);
        document.getElementById('bemployeeDiv').style.display = 'none';
    }
    function eldate(){
        var nextday = addDays(4);
        document.getElementById("ldate").setAttribute("min", nextday);
        document.getElementById("ldate").setAttribute("max", "");
        document.getElementById("ldate2").setAttribute("min", nextday);
        document.getElementById("ldate2").setAttribute("max", "");
        document.getElementById('bemployeeDiv').style.display = 'block';
    }
    function addDays(n){
        var t = new Date();
        t.setDate(t.getDate() + n); 
        var month = "0"+(t.getMonth()+1);
        var date = "0"+t.getDate();
        month = month.slice(-2);
        date = date.slice(-2);
        var date =   t.getFullYear()+"-"+month+"-"+date;
        return date;
    }
</script>
