<script type="text/javascript">
    function module(){
        $("#moduleDiv").hide();
        $("#parent").val(' ');
    }
    function submodule(){
        $("#moduleDiv").show();
        getmodule();
    }
    function mymodules(){
        var type = $('input[name="type"]:checked').val();
        if(type == '1'){
            getmodule()
        }
    }
    function getmodule(){
        var valInput = $("input[name=_token]").val();
        var product = $("#product").val();
        var myresult = '';
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': valInput
            },
            type:'POST',
            url:"{{ route('fetch_module') }}",
            data:{ input:product },
            dataType: 'json',
            success:function(result){
                // $('#parent').html('<option value="">-- Select Module --</option>');
                $.each(result.module, function (key, value) {
                    // $("#parent").append('<option value="' + value
                    //     .id + '">' + value.modulename + '</option>');
                    myresult = myresult + '<option value="' + value.id + '">'
                          + value.modulename + '</option>';
                });
                $("#parent").html(myresult);
            },
            error: function (data) {
                console.log(data);
            }
        });

    }
</script>
