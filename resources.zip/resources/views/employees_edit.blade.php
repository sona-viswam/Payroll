<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <form class="form-sample" action="{{ route('updateEmployee', $data[0]->id) }}" enctype="multipart/form-data" method="post">@csrf
                                <p class="card-description"> Personal info </p>
                                @include('message')
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">First Name<span class="mdi mdi-star icon-sm text-success"></span></label>
                                            <div class="col-sm-8">
                                                <input name="firstname" type="text" class="form-control" value="{{ $data[0]->firstname }}" />
                                                @if ($errors->has('firstname'))
                                                    <span class="text-danger">{{ $errors->first('firstname') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Last Name</label>
                                            <div class="col-sm-8">
                                                <input name="secondname" type="text" class="form-control" value="{{ $data[0]->secondname }}" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">UserName</label>
                                            <div class="col-sm-9">
                                                <input name="username" type="text" class="form-control" value="{{ $data[0]->username }}" />
                                                @if ($errors->has('username'))
                                                    <span class="text-danger">{{ $errors->first('username') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Password</label>
                                            <div class="col-sm-9">
                                                <input name="password" type="password" class="form-control" value="{{ $data[0]->password }}" />
                                                @if ($errors->has('password'))
                                                    <span class="text-danger">{{ $errors->first('password') }}</span>
                                                @endif
                                                <input name="oldpassword" type="hidden" value="{{$data[0]->password}}">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Gender</label>
                                            <div class="col-sm-3">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="gender" id="membershipRadios1" value="2" {{ ($data[0]->gender=="2")? "checked" : "" }}> Female </label>
                                                </div>
                                            </div>
                                            <div class="col-sm-3">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="gender" id="membershipRadios2" value="1" {{ ($data[0]->gender=="1")? "checked" : "" }}> Male </label>
                                                </div>
                                            </div>
                                            <div class="col-sm-3">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="gender" id="membershipRadios2" value="3" {{ ($data[0]->gender=="3")? "checked" : "" }}> Other </label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">DOB</label>
                                            <div class="col-sm-9">
                                                <input name="dob" type="date" class="form-control" value="{{ $data[0]->dob }}" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Qualification</label>
                                            <div class="col-sm-9">
                                                <input name="qualification" type="text" class="form-control" value="{{ $data[0]->qualification }}" />

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">E-mail</label>
                                            <div class="col-sm-9">
                                                <input name="email" type="email" class="form-control" value="{{ $data[0]->email }}" />
                                                @if ($errors->has('email'))
                                                    <span class="text-danger">{{ $errors->first('email') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Permanent Address</label>
                                            <div class="col-sm-9">
                                                <textarea name="permanentaddress" class="form-control" id="exampleTextarea1" rows="4">{{ $data[0]->permanentaddress }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Temporary Address</label>
                                            <div class="col-sm-9">
                                                <textarea name="temporaryaddress" class="form-control" id="exampleTextarea1" rows="4">{{ $data[0]->temporaryaddress }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">City</label>
                                            <div class="col-sm-9">
                                                <input name="city" type="text" class="form-control" value="{{ $data[0]->city }}" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Country</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="country">
                                                    @foreach ($countries as $key => $value)
                                                        <option value="{{ $value->id }}" {{ ($value->id == $data[0]->country) ? 'selected' : '' }}>{{ $value->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Pin</label>
                                            <div class="col-sm-9">
                                                <input name="pin" type="number" class="form-control" value="{{ $data[0]->pin }}" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Phone</label>
                                            <div class="col-sm-9">
                                                <input name="phone" type="number" class="form-control" value="{{ $data[0]->phone }}" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Mobile</label>
                                            <div class="col-sm-9">
                                                <input name="mobile" type="number" class="form-control" value="{{ $data[0]->mobile }}" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Photo</label>
                                            <div class="input-group col-sm-9">
                                                @php
                                                $photoName = $data[0]->photo;
                                                if($photoName){
                                                 $photo = asset('upload/'.$photoName);
                                                 @endphp
                                                <div style="border-radius: 100%;width:45px; height:45px; !important">
                                                    <img src="{{ $photo }}" alt="image" />
                                                </div>
                                                @php
                                                }
                                                @endphp
                                                <input type="file" name="photo" class="form-control">
                                                @if ($errors->has('photo'))
                                                    <span class="text-danger">{{ $errors->first('photo') }}</span>
                                                @endif

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Identity No.</label>
                                            <div class="col-sm-9">
                                                <input name="identityno" type="text" class="form-control" value="{{ $data[0]->identityno }}" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Identity Image</label>
                                            <div class="input-group col-sm-9">
                                            @php
                                                $photoName = $data[0]->identityimage;
                                                if($photoName){
                                                 $photo = asset('upload/'.$photoName);
                                            @endphp
                                            <div style="border-radius: 100%;width:45px; height:45px; !important">
                                                <img src="{{ $photo }}" alt="image" />
                                            </div>
                                            @php
                                                }
                                            @endphp
                                            <input type="file" name="identityimage" class="form-control">
                                                <input name="old_identityimage" type="hidden" value="{{$data[0]->identityimage}}">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Bank Name</label>
                                            <div class="col-sm-9">
                                                <input name="bankname" type="text" class="form-control" value="{{ $data[0]->bankname }}" />
                                                @if ($errors->has('bankname'))
                                                    <span class="text-danger">{{ $errors->first('bankname') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Account No</label>
                                            <div class="col-sm-9">
                                                <input name="accountno" type="text" class="form-control" value="{{ $data[0]->accountno }}" />
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Hire Date</label>
                                            <div class="col-sm-9">
                                                <input name="hiredate" type="date" class="form-control" value="{{ $data[0]->hiredate }}" />
                                                @if ($errors->has('hiredate'))
                                                    <span class="text-danger">{{ $errors->first('hiredate') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Last Date</label>
                                            <div class="col-sm-9">
                                                <input name="lastdate" type="date" class="form-control" value="{{ $data[0]->lastdate }}" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Status</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="status">
                                                    <option value="1" {{ ($data[0]->status ==1) ? 'selected' : '' }}>Active</option>
                                                    <option value="0" {{ ($data[0]->status ==0) ? 'selected' : '' }}>Suspend</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label"></label>
                                        <div class="col-sm-9">
                                            <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                                            <a class="btn btn-light" href="{{url('employees')}}">Cancel</a>                                        </div>
                                    </div>
                                </div>

                        </div>


                            </form>
                        </div>
                    </div>
                </div>




            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
