<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
@include('box')
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <div style="position: absolute;right:10px;top:25px;">
                                <a title="Add {{ $heading }}" class="btn btn-gradient-primary mr-2" href="{{url('client_add')}}">+ Add</a>
                            </div>
                            <p class="card-description">
                                {{--                                Add class <code>.table-striped</code>--}}
                            </p>
                            @include('message')
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span>#</th>
                                    <th> Client </th>
                                    <th> Projects </th>
                                    <th> Tools </th>
                                </tr>
                                </thead>
                                <tbody>
                                @php $i = $data->perPage() * ($data->currentPage() - 1); @endphp
                                @foreach ($data as $key => $value)
                                    <tr>
                                        <td class="py-1"> {{ ++ $i}}</td>
                                        <td> {{ $value->client }} </td>
                                        <td>
                                            <a href="{{ route('clientproject', ['id' => $value->id]);}}" title="Project">
                                                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                                                    <i class="mdi mdi mdi-book"></i>
                                                </span>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="{{ route('client_edit', ['id' => $value->id]);}}" title="Edit">
                                                <span class="page-title-icon bg-gradient-success text-white mr-2">
                                                    <i class="mdi mdi-table-edit"></i>
                                                </span>
                                            </a>
                                            <a title="Delete" href="#" onclick="showBox(this,'{{ route('client_delete', ['id' => $value->id]);}}')">
                                                <span class="page-title-icon bg-gradient-danger text-white mr-2">
                                                    <i class="mdi mdi-delete-forever"></i>
                                                </span>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                                 </tbody>
                            </table>
                            <table class="table">
                                <tr><td>{!! $data->links() !!} </td></tr>
                            </table>
                        </div>
                    </div>

                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
