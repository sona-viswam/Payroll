<html>
<head>
    <style>
        table{
            width: 100%;
            border-collapse:collapse;
            border: 1px solid #f2f4f2;
        }
        table td{line-height:25px;padding-left:15px;}
        table th{color:#363636; text-align:left; padding:5px;}
        table.table1 {
            border-style: solid;
            border: 1px solid #f2f4f2;
        }
        table.table1 th {
            border-style: solid;
            border: 1px solid #f2f4f2;
        }
        table.table1 td {
            border-style: solid;
            border: 1px solid #f2f4f2;
        }
    </style>

</head>
<body>
@php
    $salaryDate = $data[0]->salary_date;
    $days = \Carbon\Carbon::parse($salaryDate)->daysInMonth;
    $salarydays = $days - $data[0]->total_lop_days;
    $basicsalary = $data[0]->basic_salary;
    $incentive = $data[0]->other;
    if($incentive >0){
        $myincentive = $incentive;
    }else{
        $myincentive = '';
    }
    $grossearnings =  $basicsalary + $incentive;
@endphp

<table border="0">
    <tr>
        <td rowspan="2" style="width:265px;"><img src="{{asset('assets/images/logo.jpg')}}"></td>
        <th colspan="2">
            <span style="font-size:24px;">Milestone Innovative Technologies</span>
            <br>
            <span style="font-size:10px;padding-left:80px;">Wisma Pam, Ovungal, Chavakkad - 680506</span>
        </th>
    </tr>
    <tr>
        <th>Salary Slip for the Month</th>
        <th style="text-align:center;">{{ date('F -Y', strtotime($salaryDate)); }}</th>
    </tr>
</table>
<br/>

<table class="table1">
    <tr>
        <th>Name</th>
        <td>{{ $data[0]->remployee->fullname; }}</td>
        <th>Payment Date</th>
        <td>{{ date('d-M-Y', strtotime($data[0]->created_at)); }}</td>
    </tr>
    <tr>
        <th>Employee Code</th>
        <td>{{str_pad($data[0]->remployee->id, 6, "0", STR_PAD_LEFT);}}</td>
        <th>Employee Status</th>
        <td>Permanent</td>
    </tr>
    <tr>
        <th>Bank Name</th>
        <td>{{ $data[0]->remployee->bankname }}</td>
        <th>Account No.</th>
        <td>{{ $data[0]->remployee->accountno }}</td>
    </tr>
    <tr>
        <th>Location</th>
        <td>{{$data[0]->remployee->rcountry()->orderByDesc('id')->first()->name}}</td>
        <th>Salary Days</th>
        <td>{{ $salarydays }}</td>
    </tr>
    <tr>
        <th>Department</th>
        <td>{{$data[0]->remployee->departments()->orderByDesc('id')->first()->department}}</td>
        <th>Designation</th>
        <td>{{$data[0]->remployee->designations()->orderByDesc('id')->first()->designation}}</td>
    </tr>
</table>
<br>
<table class="table1">
    <tr>
        <th colspan="2" style="text-align:center;">Allowances</th>
        <th colspan="2" style="text-align:center;">Deductions</th>
    </tr>
            <tr>
                <td>Basic</td>
                <td>{{ $data[0]->basic_salary }}</td>
                <td>LOP</td>
                <td>{{ $data[0]->lop_amount }}</td>
            </tr>
            <tr>
                <td>Incentive</td>
                <td>{{ $myincentive }}</td>
                <td>Tax</td>
                <td>-</td>
            </tr>

    <tr>
                <th>Gross Earnings</th>
                <td>{{ $grossearnings }}</td>
                <th>Gross Deductions</th>
                <td>{{ $data[0]->lop_amount }}</td>
    </tr>
</table>
<br>
@php
$digit = new NumberFormatter("en", NumberFormatter::SPELLOUT);
$total = $data[0]->net_salary;
@endphp
<table>
    <tr>        <th colspan="2">Rupees: {{ Str::upper($digit->format($total)) }} ONLY</th>
        <th>Net Salary</th>
        <td><strong>Rs. {{ $total }}</strong></td>
    </tr>
</table>

</body>
</html>
