<!DOCTYPE html>
<html lang="en">
@include('header')
@include('myjobcard_js')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <form class="form-sample" action="{{ route('myjobcard_update', $data[0]->id) }}" method="post">@csrf
                                <p class="card-description">
                                </p>
                                @include('message')
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Activity</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="activity">
                                                    @foreach ($activity as $key => $value)
                                                        <option value="{{ $value->id }}" {{ ($data[0]->activity == $value->id ) ? 'selected' : '' }}>{{ $value->activity }}</option>
                                                    @endforeach
                                                </select>
                                                @if ($errors->has('activity'))
                                                    <span class="text-sm text-danger ">{{ $errors->first('activity') }}</span>
                                                @endif
                                            </div>
                                             </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Client</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" id="client" name="client" onchange = "myprojects();">
                                                    <option value = ""> -- Select -- </option>
                                                    @foreach ($client as $key => $value)
                                                        <option value="{{ $value->id }}" {{ ($data[0]->client == $value->id ) ? 'selected' : '' }}>{{ $value->client }}</option>
                                                    @endforeach
                                                </select>
                                                @if ($errors->has('client'))
                                                    <span class="text-sm text-danger ">{{ $errors->first('client') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Project</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="type1" id="type1" onchange = "mymodules();">
                                                    <option value = ""> -- Select -- </option>
                                                    @foreach ($project as $key => $value)
                                                        <option value="{{ $value->id }}" {{ ($data[0]->type1 == $value->id ) ? 'selected' : '' }}>{{ $value->project }}</option>
                                                    @endforeach
                                                </select>
                                                @if ($errors->has('type1'))
                                                    <span class="text-sm text-danger ">{{ $errors->first('type1') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Module</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="type2"  id="type2" onchange = "mysubmodules();">
                                                    @if(count($module)>0)
                                                    @foreach ($module as $key => $value)
                                                        <option value="{{ $value->id }}" {{ ($data[0]->type2 == $value->id ) ? 'selected' : '' }}>{{ $value->modulename }}</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                                @if ($errors->has('type2'))
                                                    <span class="text-sm text-danger ">{{ $errors->first('type2') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">SubModule</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="type3"  id="type3">
                                                    @if(count($submodule)>0)
                                                    @foreach ($submodule as $key => $value)
                                                        <option value="{{ $value->id }}" {{ ($data[0]->type3 == $value->id ) ? 'selected' : '' }}>{{ $value->modulename }}</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                                @if ($errors->has('type3'))
                                                    <span class="text-sm text-danger ">{{ $errors->first('type3') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @php
                                    $today = Carbon\Carbon::today();
                                    $todaystart = $today->startOfDay()->format('Y-m-d\TH:i:s');
                                    $todayend = $today->endOfDay()->format('Y-m-d\TH:i:s');
                                @endphp
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Start Time</label>
                                            <div class="col-sm-9">
                                                <input value="{{ date('Y-m-d\TH:i', strtotime($data[0]->starttime)) }}"
                                                       name="starttime" id="starttime" type="datetime-local"
                                                       class="form-control" onchange ="timecalculation();"
                                                       readonly
                                                />
                                                @if ($errors->has('starttime'))
                                                    <span class="text-sm text-danger ">{{ $errors->first('starttime') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">End Time</label>
                                            <div class="col-sm-9">
                                                <input value="{{ date('Y-m-d\TH:i', strtotime($data[0]->endtime)) }}"
                                                       name="endtime"  id="endtime" type="datetime-local"
                                                       class="form-control" onchange ="timecalculation();"
                                                       readonly
                                                />
                                                @if ($errors->has('endtime'))
                                                    <span class="text-sm text-danger ">{{ $errors->first('endtime') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @php
                                    function secondsToTime($minutes) {
                                        $d = floor ($minutes / 1440);
                                        $h = floor (($minutes - $d * 1440) / 60);
                                        $m = $minutes - ($d * 1440) - ($h * 60);
                                        return "$d days, $h hours, $m minutes";
                                    }
                                @endphp
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Time Taken</label>
                                            <div class="col-sm-9">
                                                <input name="timetaken" id="timetaken" type="text" value = "{{ $data[0]->timetaken }}"
                                                       class="form-control" readonly />
                                                <input name="oldtimetaken" type="hidden" value = "{{ $data[0]->timetaken }}" />
                                                <input name="cost" type="hidden" value = "{{ $data[0]->cost }}" />
                                                @if ($errors->has('timetaken'))
                                                    <span class="text-sm text-danger">{{ $errors->first('timetaken') }}</span>
                                                @endif
                                                <label class="col-sm-9 col-form-label" id="timelabel">{{ secondsToTime($data[0]->timetaken) }}</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Status</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="status">
                                                    <option value="1" {{ ($data[0]->status ==1) ? 'selected' : '' }}>Draft</option>
                                                    <option value="2" {{ ($data[0]->status ==2) ? 'selected' : '' }}>Verified</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="content">Description</label>
                                    <textarea id="description" name="description" rows="4" cols="50"
                                              class="form-control">{{ $data[0]->description }}</textarea>
                                    @if ($errors->has('description'))
                                        <span class="text-sm text-danger ">{{ $errors->first('description') }}</span>
                                    @endif
                                </div>




                                <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label"></label>
                                        <div class="col-sm-9">
                                            <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                                            <a class="btn btn-light" href="{{url('myjobcard')}}">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                        </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
