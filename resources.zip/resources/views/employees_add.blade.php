<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
@include('upper_menu')
    <div class="container-fluid page-body-wrapper">
@include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <form class="form-sample" action="{{ route('createEmployee') }}" enctype="multipart/form-data" method="post">@csrf
                                <p class="card-description"> Personal info </p>
                                @include('message')
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">First Name<i class="mdi mdi-star icon-sm text-success"></i></label>
                                            <div class="col-sm-8">
                                                <input name="firstname" type="text" class="form-control" value="{{ old('firstname') }}" />
                                                @if ($errors->has('firstname'))
                                                    <span class="text-sm text-danger">{{ $errors->first('firstname') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Last Name</label>
                                            <div class="col-sm-8">
                                                <input name="secondname" type="text" class="form-control" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">UserName<i class="mdi mdi-star icon-sm text-success"></i></label>
                                            <div class="col-sm-8">
                                                <input name="username" type="text" class="form-control" />
                                                @if ($errors->has('username'))
                                                    <span class="text-sm text-danger">{{ $errors->first('username') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Password<i class="mdi mdi-star icon-sm text-success"></i></label>
                                            <div class="col-sm-8">
                                                <input name="password" type="password" class="form-control" />
                                                @if ($errors->has('password'))
                                                    <span class="text-sm text-danger">{{ $errors->first('password') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Gender</label>
                                            <div class="col-sm-3">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="gender" id="membershipRadios1" value="2" checked> Female </label>
                                                </div>
                                            </div>
                                            <div class="col-sm-3">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="gender" id="membershipRadios2" value="1"> Male </label>
                                                </div>
                                            </div>
                                            <div class="col-sm-3">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="gender" id="membershipRadios2" value="3"> Other </label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">DOB</label>
                                            <div class="col-sm-8">
                                                <input name="dob" type="date" class="form-control"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Qualification</label>
                                            <div class="col-sm-8">
                                                <input name="qualification" type="text" class="form-control" />

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">E-mail<i class="mdi mdi-star icon-sm text-success"></i></label>
                                            <div class="col-sm-8">
                                                <input name="email" type="email" class="form-control" />
                                                @if ($errors->has('email'))
                                                    <span class="text-sm text-danger">{{ $errors->first('email') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Permanent Address</label>
                                            <div class="col-sm-8">
                                                <textarea name="permanentaddress" class="form-control" id="exampleTextarea1" rows="4"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Temporary Address</label>
                                            <div class="col-sm-8">
                                                <textarea name="temporaryaddress" class="form-control" id="exampleTextarea1" rows="4"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">City</label>
                                            <div class="col-sm-8">
                                                <input name="city" type="text" class="form-control" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Country</label>
                                            <div class="col-sm-8">
                                                <select class="form-control" name="country">
                                                    @foreach ($countries as $key => $value)
                                                        <option value="{{ $value->id }}">{{ $value->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Pin</label>
                                            <div class="col-sm-8">
                                                <input name="pin" type="number" class="form-control" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Phone</label>
                                            <div class="col-sm-8">
                                                <input name="phone" type="number" class="form-control" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Mobile</label>
                                            <div class="col-sm-8">
                                                <input name="mobile" type="number" class="form-control" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Photo</label>
                                            <div class="input-group col-sm-8">
                                                <input type="file" name="photo" class="form-control">
                                                @if ($errors->has('photo'))
                                                    <span class="text-sm text-danger">{{ $errors->first('photo') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Identity No.</label>
                                            <div class="col-sm-8">
                                                <input name="identityno" type="text" class="form-control" />
                                            </div>
                                        </div>
                                    </div>
{{--                                    <div class="col-md-6">--}}
{{--                                        <div class="form-group row">--}}
{{--                                            <label class="col-sm-3 col-form-label">Identity Image</label>--}}
{{--                                            <input type="file" name="img[]" class="file-upload-default">--}}
{{--                                            <div class="input-group col-sm-9">--}}
{{--                                                <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">--}}
{{--                                                <span class="form-control-append">--}}
{{--                                                    <button class="file-upload-browse btn btn-gradient-primary" type="button">Upload</button>--}}
{{--                                                  </span>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Identity Image</label>
                                            <div class="input-group col-sm-8">
                                                <input type="file" name="identityimage" class="form-control">
                                                @if ($errors->has('identityimage'))
                                                    <span class="text-sm text-danger">{{ $errors->first('identityimage') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Bank Name</label>
                                            <div class="col-sm-8">
                                                <input name="bankname" type="text" class="form-control" />
                                                @if ($errors->has('bankname'))
                                                    <span class="text-sm text-danger">{{ $errors->first('bankname') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Account No</label>
                                            <div class="col-sm-9">
                                                <input name="accountno" type="text" class="form-control" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Hire Date<i class="mdi mdi-star icon-sm text-success"></i></label>
                                            <div class="col-sm-8">
                                                <input name="hiredate" type="date" class="form-control" />
                                                @if ($errors->has('hiredate'))
                                                    <span class="text-sm text-danger">{{ $errors->first('hiredate') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Last Date</label>
                                            <div class="col-sm-8">
                                                <input name="lastdate" type="date" class="form-control" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Status</label>
                                            <div class="col-sm-8">
                                                <select class="form-control" name="status">
                                                    <option value="1">Active</option>
                                                    <option value="0">Suspend</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label"></label>
                                        <div class="col-sm-9">
                                            <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                                            <a class="btn btn-light" href="{{url('employees')}}">Cancel</a>
                                        </div>
                                    </div>
                                </div>

                        </div>


                            </form>
                        </div>
                    </div>
                </div>




            </div>
@include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
