<div
    class="fixed hidden inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full"  id="popup" style="z-index:1000">
    <script type="text/javascript">
        function showBox(obj,lnk){
            $('#popup').attr('link',lnk).show();
        }
        function hideBox(){
            $('#popup').attr('link','').hide();
        }
        function deleteLink(){
            var p=document.createElement('a');
            $(p).attr('href',$('#popup').attr('link')).click();
            $('#popup').append(p);
            $(p).html('.');
            $(p)[0].click();
        }
    </script>
    <div
        class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white" id="box1">
        <div class="mt-3 text-center">
            <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
                <i class="mdi mdi-close icon-md text-danger"></i>
            </div>
            <h3 class="text-lg leading-6 font-medium text-gray-900">Delete</h3>
            <div class="mt-2 px-7 py-3">
                <p class="text-sm text-gray-500">
                    Are you sure you want to delete?
                </p>
            </div>
            <div class="items-center px-4 py-1">
                <button type="button" class="btn btn-gradient-danger btn-sm" id="delete" onclick="deleteLink()">OK</button>
                <button type="button" class="btn btn-light btn-sm" onclick="hideBox()">Cancel</button>
            </div>
        </div>
    </div>

</div>
