<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
@include('box')
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="row">
                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                                <div class="card-description" style="float: right;">
                                    <a class="btn btn-gradient-primary" href="{{url('myleave_add')}}">+ Apply Leave</a>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        @if ($data->count() > 0 )
                                            <thead>
                                            <tr>
                                                <th><span class="gradient-bullet-list mt-4"> </span>#</th>
                                                <th> Start Date </th>
                                                <th> End Date </th>
                                                <th> Type </th>
                                                <th> Day </th>
                                                <th> Backup Employee </th>
                                                <th> Status </th>
                                                <th> Tools </th>

                                            </tr>
                                            </thead>
                                            <tbody>
                                            @php $i = $data->perPage() * ($data->currentPage() - 1); @endphp
                                            @foreach ($data as $key => $value)
                                                {{--                                    @dd($value->Employee);--}}
                                                <tr>
                                                    <td class="py-1"> {{ ++ $i}}</td>
                                                    <td> {{ date('M d,Y', strtotime($value->ldate)) }}</td>
                                                    <td>
                                                        {{ isset($value->ldate2) ? date('M d,Y', strtotime($value->ldate2)) : '' }}
                                                    </td>
                                                    <td>
                                                        @if ($value->type == 1)
                                                            CL
                                                        @else
                                                            EL
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if ($value->daytype < 1)
                                                            Half Day
                                                        @else
                                                            Full Day
                                                        @endif
                                                    </td>
                                                    <td> @if (($value->bemployee >0) && ($value->type <> 1))
                                                            {{$value->rbemployee->fullname }}
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @switch($value->status)
                                                            @case('1')
                                                            <label class="badge badge-gradient-warning">PROGRESS</label>                                                @break
                                                            @case('2')
                                                            <label class="badge badge-gradient-success">APPROVED</label>
                                                            @break
                                                            @case('5')
                                                            <label class="badge badge-gradient-danger" title="{{$value->reason}}">REJECTED</label>
                                                            @break
                                                            @default
                                                            <label class="badge badge-gradient-info">ON HOLD</label>
                                                        @endswitch
                                                    </td>
                                                    <td>
                                                        <a href="{{ route('myleave_view', ['id' => $value->id]);}}" title="Details">
                                                <span class="page-title-icon bg-gradient-info text-white mr-2">
                                                  <i class="mdi mdi mdi-eye"></i>
                                                </span>
                                                        </a>
                                                        @php $nowDate = Carbon\Carbon::now()->format('Y-m-d') @endphp
                                                        @if (($nowDate <= $value->ldate) && ($value->status <> 2)  && ($value->status <> 5) )
                                                            <a title="Edit" href="{{ route('myleave_edit', ['id' => $value->id]);}}">
                                                    <span class="page-title-icon bg-gradient-success text-white mr-2">
                                                    <i class="mdi mdi-table-edit"></i>
                                                    </span>
                                                            </a>
                                                        @endif

                                                        @if ($nowDate <= $value->ldate)
                                                            <a title="Delete" href="#" onclick="showBox(this,'{{ route('myleave_delete', ['id' => $value->id]);}}')">
                                                <span class="page-title-icon bg-gradient-danger text-white mr-2">
                                                    <i class="mdi mdi-delete-forever"></i>
                                                </span>
                                                            </a>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        @else
                                            <tr>
                                                <td colspan="2" align="center">No Records</td>
                                            </tr>
                                        @endif
                                    </table>
                                    <table class="table">
                                        <tr><td>{!! $data->links() !!} </td></tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
