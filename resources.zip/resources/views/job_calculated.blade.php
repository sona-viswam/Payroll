<!DOCTYPE html>
<html lang="en">
@include('header')
<body>
<div class="container-scroller">
    @include('upper_menu')
    <div class="container-fluid page-body-wrapper">
        @include('side_menu')

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="{{ isset($icon) ? $icon : '' }} menu-icon"></i>
                </span> {{ isset($heading) ? $heading : '' }}
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">{{ isset($heading) ? $heading : '' }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ isset($name) ? $name : '' }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">{{ isset($name) ? $name : '' }}</h4>
                            <p class="card-description">
                                {{--                                Add class <code>.table-striped</code>--}}
                            </p>
                            @include('message')
                            @php
                            if(session('job'))
                                $job = session('job');
                                $type = $job['type'];
                            @endphp
                            <table class="table table-striped">
                                <thead>
{{--                                @dd($data->toArray())--}}
                                @if(!empty($data) && $data->count())
                                <tr>
                                    <th><span class="gradient-bullet-list mt-4"> </span>#</th>
                                    <th>
                                        @if ($type == 'Activity')
                                            Activity
                                        @else
                                            Project
                                        @endif
                                    </th>
                                    <th> Total Time </th>
                                    <th> Total Cost </th>
                                    <th> Tools </th>
                                </tr>
                                </thead>
                                <tbody>
                                @php $i = $id = 0; @endphp
                                @foreach ($data as $key => $value)
                                    <tr>
                                        <td class="py-1"> {{ ++ $i}}</td>
                                        @if ($type == 'type1')
                                            @php $id = $value->type1;
                                                if($id =='')
                                                    $id =0;
                                            @endphp

                                        <td>
                                            @if ($value->type1 >0)
                                            {{ $value->rproject->project }}
                                            @endif
                                        </td>
                                        @endif
                                        @if ($type == 'Activity')
                                            @php $id = $value->activity @endphp
                                        <td> {{ $value->ractivity->activity }} </td>
                                        @endif
                                        <td>
                                            @php
                                            $minutes = $value->total_time;
                                            $hours = intdiv($minutes, 60).':'. ($minutes % 60);
                                            @endphp
                                            {{ $minutes }} -
                                            {{ $hours }} </td>
                                        <td>Rs. {{ $value->total_cost }} </td>
                                        <td>
                                            <a title="Details" href="{{ route('job_calculation_detailed', ['id' => $id]) }}">
                                                    <span class="page-title-icon bg-gradient-info text-white mr-2">
                                                    <i class="mdi mdi-eye"></i>
                                                    </span>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                                @else
                                    <tr>
                                        <td colspan="2" align="center">No Records</td>
                                    </tr>
                                @endif
                                 </tbody>
                            </table>
                        </div>
                    </div>

                </div>




            </div>
            @include('footer')
        </div>
    </div>
</div>
@include('js')
</body>
</html>
